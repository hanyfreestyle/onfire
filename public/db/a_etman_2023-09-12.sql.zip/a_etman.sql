-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2023 at 03:36 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a_etman`
--

-- --------------------------------------------------------

--
-- Table structure for table `attribute_tables`
--

CREATE TABLE `attribute_tables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attribute_tables`
--

INSERT INTO `attribute_tables` (`id`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, '2023-08-21 17:12:44', '2023-08-21 17:12:44'),
(2, 1, NULL, '2023-08-21 17:12:56', '2023-08-21 17:12:56'),
(3, 1, NULL, '2023-08-21 17:13:11', '2023-08-21 17:13:11'),
(4, 1, NULL, '2023-08-21 17:13:28', '2023-08-21 17:13:28'),
(5, 1, NULL, '2023-08-21 17:13:39', '2023-08-21 17:13:39'),
(6, 1, NULL, '2023-08-21 17:19:50', '2023-08-21 17:19:50'),
(7, 1, NULL, '2023-08-21 17:25:22', '2023-08-21 17:25:22'),
(8, 1, NULL, '2023-08-21 17:27:58', '2023-08-21 17:27:58'),
(9, 1, NULL, '2023-08-21 17:28:18', '2023-08-21 17:28:18'),
(10, 1, NULL, '2023-08-21 17:29:58', '2023-08-21 17:29:58'),
(11, 1, NULL, '2023-08-26 08:32:54', '2023-08-26 08:32:54'),
(12, 1, NULL, '2023-08-26 08:33:12', '2023-08-26 08:33:12'),
(13, 1, NULL, '2023-08-26 08:36:34', '2023-08-26 08:36:34');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_table_translations`
--

CREATE TABLE `attribute_table_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attribute_table_translations`
--

INSERT INTO `attribute_table_translations` (`id`, `attribute_id`, `locale`, `name`) VALUES
(1, 1, 'ar', 'نوع المادة اللاصقة'),
(2, 1, 'en', 'Type Of Adhesive'),
(3, 2, 'ar', 'الفيلم'),
(4, 2, 'en', 'Film'),
(5, 3, 'ar', 'العرض'),
(6, 3, 'en', 'Width'),
(7, 4, 'ar', 'الطول'),
(8, 4, 'en', 'Length'),
(9, 5, 'ar', 'سماكة'),
(10, 5, 'en', 'Thickness'),
(11, 6, 'ar', 'التغليف'),
(12, 6, 'en', 'Packaging'),
(13, 7, 'ar', 'الكور'),
(14, 7, 'en', 'Core'),
(15, 8, 'ar', 'سبيكة'),
(16, 8, 'en', 'Alloy'),
(17, 9, 'ar', 'السطح'),
(18, 9, 'en', 'Surface Finishing'),
(19, 10, 'ar', 'وحدة البيع'),
(20, 10, 'en', 'Sale Unit'),
(21, 11, 'ar', 'المادة الخام'),
(22, 11, 'en', 'Materials'),
(23, 12, 'ar', 'الالوان المتاحة'),
(24, 12, 'en', 'Color'),
(25, 13, 'ar', 'الوزن'),
(26, 13, 'en', 'Weight');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `text_view` int(11) NOT NULL DEFAULT 1,
  `url_type` int(11) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `category_id`, `photo`, `photo_thum_1`, `is_active`, `postion`, `text_view`, `url_type`, `deleted_at`, `created_at`, `updated_at`) VALUES
(4, 1, 'images/banner/4/01.webp', 'images/banner/4/01_1.webp', 1, 0, 1, 1, NULL, '2023-08-26 16:33:11', '2023-09-08 12:21:35'),
(5, 1, 'images/banner/5/pvc.webp', 'images/banner/5/pvc_1.webp', 1, 0, 1, 1, NULL, '2023-08-26 16:33:11', '2023-08-26 16:39:20'),
(6, 1, 'images/banner/6/offer.webp', 'images/banner/6/offer_1.webp', 1, 0, 1, 1, NULL, '2023-08-26 16:33:11', '2023-08-26 16:39:21'),
(7, 2, 'images/banner/7/01.webp', 'images/banner/7/01_1.webp', 1, 0, 1, 1, NULL, '2023-08-26 16:33:11', '2023-08-26 16:39:21'),
(8, 2, 'images/banner/8/02.webp', 'images/banner/8/02_1.webp', 1, 0, 1, 1, NULL, '2023-08-26 16:33:11', '2023-08-26 16:39:21'),
(9, 2, 'images/banner/9/03.webp', 'images/banner/9/03_1.webp', 1, 0, 1, 1, NULL, '2023-08-26 16:33:11', '2023-08-26 16:39:21'),
(10, 4, 'images/banner/10/dark.webp', 'images/banner/10/dark_1.webp', 1, 0, 1, 1, NULL, '2023-08-26 16:33:11', '2023-09-11 11:26:03'),
(11, 4, 'images/banner/11/الشركة-u2ZAlBKvX5.webp', 'images/banner/11/الشركة-q4UlIgJXgq.webp', 1, 0, 1, 0, NULL, '2023-09-11 09:39:12', '2023-09-11 10:04:55'),
(12, 4, 'images/banner/12/عروض-kWjPGJm1CP.webp', 'images/banner/12/عروض-4YYrIG6xAf.webp', 1, 0, 1, 0, NULL, '2023-09-11 11:40:00', '2023-09-11 11:40:01');

-- --------------------------------------------------------

--
-- Table structure for table `banner_categories`
--

CREATE TABLE `banner_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banner_categories`
--

INSERT INTO `banner_categories` (`id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, NULL, '2023-08-26 16:00:57', '2023-08-26 16:00:57'),
(2, NULL, '2023-08-26 16:01:18', '2023-08-26 16:01:18'),
(3, NULL, '2023-08-26 16:01:43', '2023-08-26 16:01:43'),
(4, NULL, '2023-09-11 09:38:34', '2023-09-11 09:38:34');

-- --------------------------------------------------------

--
-- Table structure for table `banner_category_translations`
--

CREATE TABLE `banner_category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banner_category_translations`
--

INSERT INTO `banner_category_translations` (`id`, `category_id`, `locale`, `name`) VALUES
(1, 1, 'ar', 'الصفحة الرئيسية'),
(2, 1, 'en', 'الصفحة الرئيسية'),
(3, 2, 'ar', 'سلايد 2'),
(4, 2, 'en', 'سلايد 2'),
(5, 3, 'ar', 'Dark'),
(6, 3, 'en', 'Dark'),
(7, 4, 'ar', 'رئيسية الموقع'),
(8, 4, 'en', 'رئيسية الموقع');

-- --------------------------------------------------------

--
-- Table structure for table `banner_translations`
--

CREATE TABLE `banner_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `banner_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_but` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banner_translations`
--

INSERT INTO `banner_translations` (`id`, `banner_id`, `locale`, `name`, `des`, `other`, `url`, `url_but`) VALUES
(1, 4, 'ar', '01', NULL, NULL, NULL, NULL),
(2, 4, 'en', '01', NULL, NULL, NULL, NULL),
(3, 5, 'ar', 'PVC', '', '', NULL, NULL),
(4, 5, 'en', 'PVC', '', '', NULL, NULL),
(5, 6, 'ar', 'offer', '', '', NULL, NULL),
(6, 6, 'en', 'offer', '', '', NULL, NULL),
(7, 7, 'ar', '01', '', '', NULL, NULL),
(8, 7, 'en', '01', '', '', NULL, NULL),
(9, 8, 'ar', '02', '', '', 'https://g.page/Etman-Group&#63;share', NULL),
(10, 8, 'en', '02', '', '', 'https://g.page/Etman-Group&#63;share', NULL),
(11, 9, 'ar', '03', '', '', 'http://etman-group.com/ContactUs.html', NULL),
(12, 9, 'en', '03', '', '', 'http://etman-group.com/ContactUs.html', NULL),
(13, 10, 'ar', 'Dark', 'Dark', NULL, NULL, NULL),
(14, 10, 'en', 'Dark', 'Dark', NULL, NULL, NULL),
(15, 11, 'ar', 'الشركة', NULL, NULL, NULL, NULL),
(16, 11, 'en', 'الشركة', NULL, NULL, NULL, NULL),
(17, 12, 'ar', 'عروض', NULL, NULL, NULL, NULL),
(18, 12, 'en', 'عروض', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_posts`
--

CREATE TABLE `blog_posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_posts`
--

INSERT INTO `blog_posts` (`id`, `youtube`, `photo`, `photo_thum_1`, `is_active`, `deleted_at`, `published_at`, `created_at`, `updated_at`) VALUES
(1, NULL, 'images/blog/1/launching-the-trial-version-of-the-etman-group-website-www-etman-group-com.webp', 'images/blog/1/launching-the-trial-version-of-the-etman-group-website-www-etman-group-com_1.webp', 1, NULL, '2023-09-05 00:00:00', '2023-08-26 12:34:43', '2023-09-07 11:06:11'),
(2, NULL, 'images/blog/2/etman-group-account-on-the-social-networking-instagram.webp', 'images/blog/2/etman-group-account-on-the-social-networking-instagram_1.webp', 1, NULL, '2023-08-01 00:00:00', '2023-08-26 12:34:43', '2023-09-07 11:03:06'),
(3, NULL, 'images/blog/3/best-wishes-to-you-on-the-occasion-of-the-new-year-2022.webp', 'images/blog/3/best-wishes-to-you-on-the-occasion-of-the-new-year-2022_1.webp', 1, NULL, '2023-08-26 15:34:43', '2023-08-26 12:34:43', '2023-08-26 12:45:13'),
(4, NULL, NULL, NULL, 1, NULL, '2023-09-27 00:00:00', '2023-09-07 10:56:32', '2023-09-11 12:15:49');

-- --------------------------------------------------------

--
-- Table structure for table `blog_post_photos`
--

CREATE TABLE `blog_post_photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `blog_id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `file_h` int(11) DEFAULT NULL,
  `file_w` int(11) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `is_default` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_post_translations`
--

CREATE TABLE `blog_post_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `blog_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_post_translations`
--

INSERT INTO `blog_post_translations` (`id`, `blog_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 1, 'ar', 'اطلاق-النسخة-التجريبية-لموقع-عتمان-جروب', 'اطلاق النسخة التجريبية لموقع عتمان جروب www.etman-group.com', '<p>السادة عملاء عتمان جروب نحيط سيادتكم علما باطلاق النسخة التجريبية لموقعنا مع بداية العام الجديد<br />\r\nايمانا منا باهمية التواجد والمضى قدما نحو التطوير ومواكبة التحول الرقمى الذى نشهده الان يتطور اكثر واكثر</p>\r\n\r\n<h2>روابط هامة</h2>\r\n\r\n<p>صفحتنا على Faecbook<br />\r\n<a href=\"https://www.facebook.com/Etman.Group\">https://www.facebook.com/Etman.Group</a></p>\r\n\r\n<p>حسابنا على Instagram<br />\r\n<a href=\"https://www.instagram.com/etmangroup.eg\">https://www.instagram.com/etmangroup.eg</a></p>\r\n\r\n<p>حسابنا على Linkedin<br />\r\n<a href=\"https://www.linkedin.com/company/etman-group\">https://www.linkedin.com/company/etman-group</a></p>\r\n\r\n<p>كيف تصل الينا<br />\r\n<a href=\"https://g.page/Etman-Group?share\">https://g.page/Etman-Group?share</a></p>\r\n\r\n<p>Whatsapp<br />\r\n<strong>0100-6180-117</strong></p>', 'اطلاق النسخة التجريبية لموقع عتمان جروب', 'عملاء عتمان جروب الكرام نحيط سيادتكم علما باطلاق النسخة التجريبية لموقعنا ايمانا منا بأهمية التواجد والمضى قدما نحو التطوير ومواكبة التحول الرقمى'),
(2, 1, 'en', 'launching-the-trial-version-of-the-etman-group-website', 'Launching the trial version of the Etman Group website www.etman-group.com', '<p>Dear customers of Etman Group, we inform you about the launch of the trial version of our website at the beginning of the new year<br />\r\nWe believe in the importance of being present and moving forward towards development and keeping pace with the digital transformation that we are witnessing now that is developing more and more.</p>', 'Launching the trial version of the Etman Group website', 'Dear customers, we launch our trial version of the site at the beginning of the new year, and we believe in the importance of digital transformation'),
(3, 2, 'ar', 'حساب-عتمان-جروب-على-موقع-التواصل-الاجتماعى-instagram', 'حساب عتمان جروب على موقع التواصل الاجتماعى Instagram', '<p>حساب عتمان جروب على موقع التواصل الاجتماعى Instagram</p>\r\n\r\n<p><a href=\"https://www.instagram.com/etmangroup.eg\">https://www.instagram.com/etmangroup.eg</a></p>\r\n\r\n<h2>روابط هامة</h2>\r\n\r\n<p>صفحتنا على Faecbook<br />\r\n<a href=\"https://www.facebook.com/Etman.Group\">https://www.facebook.com/Etman.Group</a></p>\r\n\r\n<p>حسابنا على Instagram<br />\r\n<a href=\"https://www.instagram.com/etmangroup.eg\">https://www.instagram.com/etmangroup.eg</a></p>\r\n\r\n<p>حسابنا على Linkedin<br />\r\n<a href=\"https://www.linkedin.com/company/etman-group\">https://www.linkedin.com/company/etman-group</a></p>\r\n\r\n<p>كيف تصل الينا<br />\r\n<a href=\"https://g.page/Etman-Group?share\">https://g.page/Etman-Group?share</a></p>\r\n\r\n<p>Whatsapp<br />\r\n<strong>0100-6180-117</strong></p>', 'حساب عتمان جروب على موقع التواصل الاجتماعى Instagram', 'حساب عتمان جروب على موقع التواصل الاجتماعى https://www.instagram.com/etmangroup.eg'),
(4, 2, 'en', 'etman-group-account-on-the-social-networking-instagram', 'Etman Group account on the social networking Instagram', '<p>Etman Group account on the social networking Instagram</p>\r\n\r\n<p><a href=\"https://www.instagram.com/etmangroup.eg\">https://www.instagram.com/etmangroup.eg</a></p>\r\n\r\n<h2>Important links</h2>\r\n\r\n<p>Faecbook<br />\r\n<a href=\"https://www.facebook.com/Etman.Group\">https://www.facebook.com/Etman.Group</a></p>\r\n\r\n<p>Instagram<br />\r\n<a href=\"https://www.instagram.com/etmangroup.eg\">https://www.instagram.com/etmangroup.eg</a></p>\r\n\r\n<p>Linkedin<br />\r\n<a href=\"https://www.linkedin.com/company/etman-group\">https://www.linkedin.com/company/etman-group</a></p>\r\n\r\n<p>Get Direction<br />\r\n<a href=\"https://g.page/Etman-Group?share\">https://g.page/Etman-Group?share</a></p>\r\n\r\n<p>Whatsapp<br />\r\n<strong>0100-6180-117</strong></p>', 'Etman Group account on the social networking Instagram', 'Etman Group account on the social networking Instagram ,https://www.instagram.com/etmangroup.eg'),
(5, 3, 'ar', 'ادارة-عتمان-جروب-والعاملين-بها-يتقدمون-لكم-بأطيب-التمنيات-بمناسبة-حلول-العام-الجديد-2022', 'ادارة عتمان جروب والعاملين بها يتقدمون لكم بأطيب التمنيات بمناسبة حلول العام الجديد 2022', '<p>ادارة عتمان جروب والعاملين بها يتقدمون لكم بأطيب التمنيات بمناسبة حلول العام الجديد 2022</p>\r\n\r\n<p>راجين من الله ان يجعل عامكمْ الجديد عاما تصنعون فيه البدايات الجديدة وتستمتعون بالإنجازات المميزة.</p>\r\n\r\n<p>كل عام وأنتم في صحة وعافية وسعادة دائمة.</p>\r\n\r\n<h2>روابط هامة</h2>\r\n\r\n<p>صفحتنا على Faecbook<br />\r\n<a href=\"https://www.facebook.com/Etman.Group\">https://www.facebook.com/Etman.Group</a></p>\r\n\r\n<p>حسابنا على Instagram<br />\r\n<a href=\"https://www.instagram.com/etmangroup.eg\">https://www.instagram.com/etmangroup.eg</a></p>\r\n\r\n<p>حسابنا على Linkedin<br />\r\n<a href=\"https://www.linkedin.com/company/etman-group\">https://www.linkedin.com/company/etman-group</a></p>\r\n\r\n<p>كيف تصل الينا<br />\r\n<a href=\"https://g.page/Etman-Group?share\">https://g.page/Etman-Group?share</a></p>\r\n\r\n<p>Whatsapp<br />\r\n<span style=\"font-size:16px\"><strong>0100-6180-117</strong></span></p>\r\n', 'ادارة عتمان جروب والعاملين بها يتقدمون لكم بأطيب التمنيات بمناسبة ', 'راجين من الله ان يجعل عامكمْ الجديد عاما تصنعون فيه البدايات الجديدة وتستمتعون بالإنجازات المميزة. كل عام وأنتم في صحة وعافية وسعادة دائمة.\r\n'),
(6, 3, 'en', 'best-wishes-to-you-on-the-occasion-of-the-new-year-2022', 'best wishes to you on the occasion of the new year 2022 ', '<p>Etman Group and its employees extend their best wishes to you on the occasion of the new year 2022</p>\r\n\r\n<p>We hope that God will make your new year a year in which you make new beginnings and enjoy distinguished achievements.</p>\r\n\r\n<p>Every year and you are in good health and happiness.</p>\r\n\r\n<p>Important links</p>\r\n\r\n<p>Faecbook<br />\r\n<a href=\"https://www.facebook.com/Etman.Group\">https://www.facebook.com/Etman.Group</a></p>\r\n\r\n<p>Instagram<br />\r\n<a href=\"https://www.instagram.com/etmangroup.eg\">https://www.instagram.com/etmangroup.eg</a></p>\r\n\r\n<p>Linkedin<br />\r\n<a href=\"https://www.linkedin.com/company/etman-group\">https://www.linkedin.com/company/etman-group</a></p>\r\n\r\n<p>Get Direction<br />\r\n<a href=\"https://g.page/Etman-Group?share\">https://g.page/Etman-Group?share</a></p>\r\n\r\n<p>Whatsapp<br />\r\n<span style=\"font-size:16px\"><strong>0100-6180-117</strong></span></p>\r\n', 'Best wishes to you on the occasion of the new year 2022 ', 'We hope that God will make your new year a year in which you make new beginnings and enjoy distinguished achievements.\r\n'),
(7, 4, 'ar', 'تجربة-اضافة-جديد', 'تجربة اضافة جديد', '<p>تجربة اضافة جديد</p>', 'تجربة اضافة جديد', 'تجربة اضافة جديد'),
(8, 4, 'en', 'test-to-add-new', 'Test To Add New', '<p>Test To Add New</p>', 'Test To Add New', 'Test To Add New');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `photo`, `photo_thum_1`, `icon`, `is_active`, `created_at`, `updated_at`) VALUES
(1, NULL, 'images/category/1/self-adhesive-tape.webp', 'images/category/1/self-adhesive-tape_0.webp', 'images/category/1/self-adhesive-tape-9gpZmGW9o0.webp', 1, '2023-08-20 13:21:00', '2023-09-07 15:43:43'),
(3, 1, 'images/category/3/self-adhesive-tape-packaging-tape.webp', 'images/category/3/self-adhesive-tape-packaging-tape_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:00'),
(6, 1, 'images/category/6/self-adhesive-tape-stationary-tape.webp', 'images/category/6/self-adhesive-tape-stationary-tape_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:07'),
(7, 1, 'images/category/7/self-adhesive-tape-masking-tape.webp', 'images/category/7/self-adhesive-tape-masking-tape_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:10'),
(10, 1, 'images/category/10/self-adhesive-tape-electrical-insulating-tape.webp', 'images/category/10/self-adhesive-tape-electrical-insulating-tape_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:13'),
(12, 1, 'images/category/12/self-adhesive-tape-double-sided-tape.webp', 'images/category/12/self-adhesive-tape-double-sided-tape_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:16'),
(13, 1, 'images/category/13/self-adhesive-color-tape.webp', 'images/category/13/self-adhesive-color-tape_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:18'),
(14, 1, 'images/category/14/printed-self-adhesive-tape.webp', 'images/category/14/printed-self-adhesive-tape_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:21'),
(15, NULL, 'images/category/15/aluminum-foil.webp', 'images/category/15/aluminum-foil_1.webp', 'images/category/15/aluminum-foil-AewbvUheG4.webp', 1, '2023-08-20 13:21:00', '2023-09-07 15:48:33'),
(16, 15, 'images/category/16/aluminium-foil-for-industry-use.webp', 'images/category/16/aluminium-foil-for-industry-use_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:27'),
(17, 15, 'images/category/17/aluminium-foil-for-house-hold.webp', 'images/category/17/aluminium-foil-for-house-hold_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:30'),
(18, NULL, 'images/category/18/food-and-beverage.webp', 'images/category/18/food-and-beverage_1.webp', 'images/category/18/food-and-beverage-USNV3PceRM.webp', 1, '2023-08-20 13:21:00', '2023-09-07 15:45:44'),
(19, 18, 'images/category/19/cling-warp.webp', 'images/category/19/cling-warp_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:35'),
(23, NULL, 'images/category/23/decorative-strips.webp', 'images/category/23/decorative-strips_1.webp', 'images/category/23/decorative-strips-mTc06N9TcV.webp', 1, '2023-08-20 13:21:00', '2023-09-07 15:43:25'),
(24, 23, 'images/category/24/gift-accessories-ribbon.webp', 'images/category/24/gift-accessories-ribbon_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:40'),
(25, 23, 'images/category/25/gift-accessories-gift-paper.webp', 'images/category/25/gift-accessories-gift-paper_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:43'),
(26, 23, 'images/category/26/gift-accessories-crepe-paper.webp', 'images/category/26/gift-accessories-crepe-paper_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:46'),
(36, 1, 'images/category/36/self-adhesive-tape-laser-tape.webp', 'images/category/36/self-adhesive-tape-laser-tape_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:49'),
(37, 1, 'images/category/37/jumbo-roll.webp', 'images/category/37/jumbo-roll_1.webp', NULL, 1, '2023-08-20 13:21:00', '2023-08-20 15:14:52'),
(38, NULL, 'images/category/38/stationary-LSf9eFzlLO.webp', 'images/category/38/stationary-s2AtrupIj3.webp', 'images/category/38/stationary-Y3SRRYgLJ9.webp', 1, '2023-09-03 15:42:03', '2023-09-09 08:15:29'),
(39, NULL, 'images/category/39/glue-gun-lqgSvBfiND.webp', 'images/category/39/glue-gun-VMr0U5SiOh.webp', 'images/category/39/glue-gun-07y8xnLwBp.webp', 1, '2023-09-07 15:55:59', '2023-09-09 07:58:57'),
(40, NULL, 'images/category/40/paper-cups-xd451a1MAj.webp', 'images/category/40/paper-cups-DsssGJh2az.webp', 'images/category/40/paper-cups-JWm1JaYCez.webp', 1, '2023-09-07 16:00:11', '2023-09-09 08:40:52'),
(41, NULL, 'images/category/41/cash-stick-VaTB5aLJHi.webp', 'images/category/41/cash-stick-SiCwhEuF0G.webp', NULL, 1, '2023-09-07 16:06:27', '2023-09-09 08:39:17'),
(42, NULL, 'images/category/42/birthday-supplies-dQl2qee3g7.webp', 'images/category/42/birthday-supplies-dGbjUbvFW0.webp', 'images/category/42/birthday-supplies-6ZaxAeFhMm.webp', 1, '2023-09-07 16:10:07', '2023-09-09 08:37:04'),
(43, NULL, 'images/category/43/photocopy-paper-gDw6TlkkkY.webp', 'images/category/43/photocopy-paper-H3eTuEfs25.webp', 'images/category/43/photocopy-paper-UvO32h4Hqf.webp', 1, '2023-09-07 16:18:33', '2023-09-09 08:07:35'),
(44, NULL, 'images/category/44/cutter-JJNb5LIhwh.webp', 'images/category/44/cutter-96ESreLAj4.webp', 'images/category/44/cutter-Uo6KScRpEf.webp', 1, '2023-09-07 16:19:43', '2023-09-09 08:34:43'),
(45, NULL, 'images/category/45/plastic-dishes-FvI5iLqFv4.webp', 'images/category/45/plastic-dishes-eXoZPJ4s32.webp', 'images/category/45/plastic-dishes-ViXVB2m2a6.webp', 1, '2023-09-07 16:29:48', '2023-09-09 08:36:27');

-- --------------------------------------------------------

--
-- Table structure for table `category_tables`
--

CREATE TABLE `category_tables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_tables`
--

INSERT INTO `category_tables` (`id`, `category_id`, `attribute_id`, `is_active`, `postion`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 6, 1, 1, 0, NULL, '2023-08-21 17:16:19', '2023-08-21 17:16:19'),
(2, 6, 2, 1, 0, NULL, '2023-08-21 17:16:36', '2023-08-21 17:16:36'),
(3, 6, 3, 1, 0, NULL, '2023-08-21 17:16:54', '2023-08-21 17:16:54'),
(4, 6, 4, 1, 0, NULL, '2023-08-21 17:17:06', '2023-08-21 17:17:06'),
(5, 6, 5, 1, 0, NULL, '2023-08-21 17:17:21', '2023-08-21 17:17:21'),
(6, 10, 1, 1, 0, NULL, '2023-08-21 17:18:40', '2023-08-21 17:18:40'),
(7, 10, 2, 1, 0, NULL, '2023-08-21 17:18:56', '2023-08-21 17:18:56'),
(8, 10, 3, 1, 0, NULL, '2023-08-21 17:19:09', '2023-08-21 17:19:09'),
(9, 10, 4, 1, 0, NULL, '2023-08-21 17:19:28', '2023-08-21 17:19:28'),
(10, 10, 6, 1, 0, NULL, '2023-08-21 17:20:10', '2023-08-21 17:20:10'),
(11, 12, 1, 1, 0, NULL, '2023-08-21 17:21:09', '2023-08-21 17:21:09'),
(12, 12, 2, 1, 0, NULL, '2023-08-21 17:21:19', '2023-08-21 17:21:19'),
(13, 12, 3, 1, 0, NULL, '2023-08-21 17:21:30', '2023-08-21 17:21:30'),
(14, 12, 4, 1, 0, NULL, '2023-08-21 17:22:06', '2023-08-21 17:22:06'),
(15, 12, 5, 1, 0, NULL, '2023-08-21 17:22:20', '2023-08-21 17:22:20'),
(16, 13, 1, 1, 0, NULL, '2023-08-21 17:23:28', '2023-08-21 17:23:28'),
(17, 13, 2, 1, 0, NULL, '2023-08-21 17:23:39', '2023-08-21 17:23:39'),
(18, 13, 3, 1, 0, NULL, '2023-08-21 17:23:50', '2023-08-21 17:23:50'),
(19, 13, 4, 1, 0, NULL, '2023-08-21 17:24:01', '2023-08-21 17:24:01'),
(20, 13, 5, 1, 0, NULL, '2023-08-21 17:24:15', '2023-08-21 17:24:15'),
(21, 14, 1, 1, 0, NULL, '2023-08-21 17:25:53', '2023-08-21 17:25:53'),
(22, 14, 2, 1, 0, NULL, '2023-08-21 17:26:05', '2023-08-21 17:26:05'),
(23, 14, 3, 1, 0, NULL, '2023-08-21 17:26:19', '2023-08-21 17:26:19'),
(24, 14, 4, 1, 0, NULL, '2023-08-21 17:26:31', '2023-08-21 17:26:31'),
(25, 14, 5, 1, 0, NULL, '2023-08-21 17:26:44', '2023-08-21 17:26:44'),
(26, 14, 7, 1, 0, NULL, '2023-08-21 17:26:57', '2023-08-21 17:26:57'),
(27, 16, 5, 1, 0, NULL, '2023-08-21 17:28:40', '2023-08-21 17:28:40'),
(28, 16, 8, 1, 0, NULL, '2023-08-21 17:28:55', '2023-08-21 17:28:55'),
(29, 16, 9, 1, 0, NULL, '2023-08-21 17:29:06', '2023-08-21 17:29:06'),
(30, 17, 5, 1, 0, NULL, '2023-08-21 17:30:28', '2023-08-21 17:30:28'),
(31, 17, 8, 1, 0, NULL, '2023-08-21 17:30:38', '2023-08-21 17:30:38'),
(32, 17, 9, 1, 0, NULL, '2023-08-21 17:30:52', '2023-08-21 17:30:52'),
(33, 17, 10, 1, 0, NULL, '2023-08-21 17:31:06', '2023-08-21 17:31:06'),
(34, 25, 5, 1, 0, NULL, '2023-08-21 17:31:55', '2023-08-21 17:31:55'),
(35, 25, 4, 1, 0, NULL, '2023-08-21 17:32:07', '2023-08-21 17:32:07'),
(36, 25, 3, 1, 0, NULL, '2023-08-21 17:32:23', '2023-08-21 17:32:23'),
(37, 36, 1, 1, 0, NULL, '2023-08-21 17:33:38', '2023-08-21 17:33:38'),
(38, 36, 2, 1, 0, NULL, '2023-08-21 17:33:49', '2023-08-21 17:33:49'),
(39, 36, 3, 1, 0, NULL, '2023-08-21 17:34:02', '2023-08-21 17:34:02'),
(40, 36, 4, 1, 0, NULL, '2023-08-21 17:34:15', '2023-08-21 17:34:15'),
(41, 36, 5, 1, 0, NULL, '2023-08-21 17:34:30', '2023-08-21 17:34:30'),
(42, 37, 1, 1, 1, NULL, '2023-08-21 17:35:10', '2023-09-09 12:48:23'),
(43, 37, 3, 1, 2, NULL, '2023-08-21 17:35:22', '2023-09-09 12:48:23'),
(44, 37, 4, 1, 3, NULL, '2023-08-21 17:35:34', '2023-09-09 12:48:23'),
(45, 37, 5, 1, 4, NULL, '2023-08-21 17:35:49', '2023-09-09 12:48:23'),
(46, 37, 7, 1, 5, NULL, '2023-08-21 17:36:03', '2023-09-09 12:48:23');

-- --------------------------------------------------------

--
-- Table structure for table `category_table_translations`
--

CREATE TABLE `category_table_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_table_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_table_translations`
--

INSERT INTO `category_table_translations` (`id`, `category_table_id`, `locale`, `des`) VALUES
(1, 1, 'ar', 'لاصق أكريليك ذو أساس مائي'),
(2, 1, 'en', 'Water based acrylic adhesive'),
(3, 2, 'ar', 'شفاف ، كريستال ، الوان ، ليزير'),
(4, 2, 'en', 'clear & crystal film & easy tear film & laser color'),
(5, 3, 'ar', '12مم ,15مم ,18مم ,24مم'),
(6, 3, 'en', '12mm ,15mm ,18mm ,24mm'),
(7, 4, 'ar', '10,12,13.5,25, 30 متر'),
(8, 4, 'en', '10,12,13.5,25, 30 meters'),
(9, 5, 'ar', '38 & 40 ميكرون'),
(10, 5, 'en', '38 & 40 Micron'),
(11, 6, 'ar', 'لاصق مطاطى'),
(12, 6, 'en', 'rubber adhesive'),
(13, 7, 'ar', 'شريط عازل'),
(14, 7, 'en', 'insulating tape'),
(15, 8, 'ar', '18 مم'),
(16, 8, 'en', '18mm'),
(17, 9, 'ar', '5,7,10,15,20 يارده'),
(18, 9, 'en', '5,7,10,15,20 yard'),
(19, 10, 'ar', '50 عبوة بالكرتونة'),
(20, 10, 'en', '50shrink/CTN'),
(21, 11, 'ar', 'لاصق مذيب'),
(22, 11, 'en', 'Solvent adhesive'),
(23, 12, 'ar', 'شريط ورقى'),
(24, 12, 'en', 'tissue tape'),
(25, 13, 'ar', '12-15-18-24-45 مم'),
(26, 13, 'en', '12-15-18-24-45mm'),
(27, 14, 'ar', '10 يارده'),
(28, 14, 'en', '10 yard'),
(29, 15, 'ar', '190 ميكرون'),
(30, 15, 'en', '190 mic'),
(31, 16, 'ar', 'لاصق أكريليك ذو أساس مائي'),
(32, 16, 'en', 'water based adhesive'),
(33, 17, 'ar', 'ملون'),
(34, 17, 'en', 'COLOR'),
(35, 18, 'ar', 'متاح تحت الطلب'),
(36, 18, 'en', 'available under request'),
(37, 19, 'ar', 'متاح تحت الطلب'),
(38, 19, 'en', 'available under request'),
(39, 20, 'ar', '45 ميكرون'),
(40, 20, 'en', '45 mic'),
(41, 21, 'ar', 'مادة لاصقة ذات أساس مائي'),
(42, 21, 'en', 'water based adhesive'),
(43, 22, 'ar', 'شفاف وأبيض'),
(44, 22, 'en', 'clear & white based'),
(45, 23, 'ar', 'متاح حسب الطلب'),
(46, 23, 'en', 'available under request'),
(47, 24, 'ar', 'متاح حسب الطلب'),
(48, 24, 'en', 'available under request'),
(49, 25, 'ar', 'متاح حسب الطلب'),
(50, 25, 'en', 'available under request'),
(51, 26, 'ar', 'حسب متطلبات العملاء'),
(52, 26, 'en', 'clients requirements'),
(53, 27, 'ar', '0.025 مم - 0.060 مم - 0.080 مم'),
(54, 27, 'en', '0.025 mm - 0.060 mm - 0.080 mm'),
(55, 28, 'ar', '8011/ H14'),
(56, 28, 'en', '8011/ H14'),
(57, 29, 'ar', 'جانب واحد لامع ، والاخر غير لامع'),
(58, 29, 'en', 'one side bright, one side matte'),
(59, 30, 'ar', '0.010 مم - 0.011 مم'),
(60, 30, 'en', '0.010 mm , 0.011 mm'),
(61, 31, 'ar', '8011/O'),
(62, 31, 'en', '8011/O'),
(63, 32, 'ar', 'جانب واحد لامع ، والاخر غير لامع'),
(64, 32, 'en', 'one side bright, one side matte'),
(65, 33, 'ar', 'معبأة في صندوق العرض أو أكياس'),
(66, 33, 'en', 'Packed in Display box or PP bag'),
(67, 34, 'ar', '20 ميكرون'),
(68, 34, 'en', '20 micron'),
(69, 35, 'ar', '70 سم'),
(70, 35, 'en', '70 cm'),
(71, 36, 'ar', '100 سم'),
(72, 36, 'en', '100 cm'),
(73, 37, 'ar', 'لاصق أكريليك ذو أساس مائي'),
(74, 37, 'en', 'water based adhesive'),
(75, 38, 'ar', 'ليزر'),
(76, 38, 'en', 'Laser'),
(77, 39, 'ar', '4.5 سم'),
(78, 39, 'en', '4.5 cm'),
(79, 40, 'ar', 'متاح حسب الطلب'),
(80, 40, 'en', 'as per request'),
(81, 41, 'ar', '40 ميكرون'),
(82, 41, 'en', '40 mic'),
(83, 42, 'ar', 'مادة لاصقة ذات أساس مذيب طبيعي'),
(84, 42, 'en', 'Water based acrylic adhesive'),
(85, 43, 'ar', '1280 ,1610 , 1620 mm'),
(86, 43, 'en', '1280 ,1610 , 1620 mm'),
(87, 44, 'ar', '4000, 4500, 4800, 7300, 7500 متر'),
(88, 44, 'en', '4000, 4500, 4800, 7300, 7500 Mtrs'),
(89, 45, 'ar', '36 ميكرون الى 50 ميكرون'),
(90, 45, 'en', '36 microns to 50 microns'),
(91, 46, 'ar', '760 mm'),
(92, 46, 'en', '760 mm');

-- --------------------------------------------------------

--
-- Table structure for table `category_translations`
--

CREATE TABLE `category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `breadcrumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_translations`
--

INSERT INTO `category_translations` (`id`, `category_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`, `body_h1`, `breadcrumb`) VALUES
(1, 1, 'ar', 'الأشرطة-ذاتية-اللصق', 'الأشرطة ذاتية اللصق', 'الأشرطة ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بغشاء BOPP.\r\nإنها مناسبة للاستخدامات المختلفة وفقًا لسمكها. \r\n\r\nإنه لزج (لزج) بدون أي حرارة أو مذيب للتنشيط ويلتصق بضغط خفيف. تتطلب هذه الأشرطة عادةً عامل تحرير على ظهرها أو بطانة تحرير لتغطية المادة اللاصقة.\r\n\r\nنحن ننتج مجموعة متنوعة من المنتجات لتلبية جميع الاحتياجات الخاصة بمتطلبات سوق التعبئة والتغليف للتغليف يمكن تزويده بـ (التصاق عالي ، قابل للطباعة ، مقاوم للعوامل الجوية وقوة شد عالية).\r\n\r\nمن ناحية أخرى ، لدينا قاعدة مذيب من المطاط الطبيعي ، تستخدم للثلاجات والأفران.\r\nوالتى يتم استخدمها  أثناء تصدير الفواكه والخضروات ، وكذلك يتم استخدمها مع درجات الحرارة العالية ودرجة الحرارة المنخفضة للغاية.', 'عتمان جروب متخصصون فى صناعة الأشرطة ذاتية اللصق بجميع انواعها', 'الأشرطة ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بغشاء BOPP. إنها مناسبة للاستخدامات المختلفة وفقًا لسمكها. إنه لزج (لزج) بدون أي حرارة أو مذيب', NULL, NULL),
(2, 1, 'en', 'self-adhesive-tape', 'Self Adhesive Tape', 'The packing adhesive tapes is made from water based adhesive coated on BOPP film .It suitable for different weight requirement according to its thickness.\r\n\r\nIt is sticky (tacky) without any heat or solvent for activation and adheres with light pressure. These tapes usually require a release agent on their backing or a release liner to cover the adhesive. \r\n\r\nWe produce variety of products to meet all special needs for economical general, medium heavy-duty and special heavy duty packing.\r\n \r\nIt can be provided with (high adhesion, printable, weather-resistance and high tensile strength).\r\n\r\nOn other hand we have Natural rubber solvent base , using for fridges and ovens . \r\nAs we have needs in sealing cartons go with the Refrigeration during export of fruits and vegetable , also use for seal in high temperature and very low temperature .', 'Etman Group specializes in the manufacture of self-adhesive tapes', 'The packing adhesive tapes is made from water based adhesive coated on BOPP film .It suitable for different weight requirement according to its thickness.', NULL, NULL),
(3, 3, 'ar', 'الأشرطة-ذاتية-اللصق-شرائط-التعبئة-والتغليف', 'شرائط التعبئة والتغليف', 'الأشرطة ذاتية اللصق المستخدمة للتغليف مصنوعة من مادة لاصقة ذات أساس مائي مطلية بغشاء BOPP.نحن فى عتمان جروب ننتج مجموعة متنوعة من المنتجات لتلبية جميع احتياجات السوق المحلى \r\nتستخدم في المستودعات والمخازن والمصانع وكذلك الاستخدام المنزلي والمكتبي. يمكن استخدام الاشرطة ذاتية اللصق في عمليات نقل الاثاث ، وشركات الشحن ، والبريد ،وكذلك تستخدم فى عمليات تخزين وتنظيم الأدوات المنزلية', 'الأشرطة ذاتية اللصق | شرائط التعبئة والتغليف', 'الأشرطة ذاتية اللصق المستخدمة للتغليف مصنوعة من مادة لاصقة ذات أساس مائي مطلية بغشاء BOPP.نحن ننتج مجموعة متنوعة من المنتجات لتلبية جميع احتياجات السوق المحلى ', NULL, NULL),
(4, 3, 'en', 'Self-Adhesive-Tape-Packaging-Tape', 'Packaging Tape', 'The self-adhesive tapes used for packing are made of a water-based adhesive that is coated with BOPP film. We produce a variety of products to meet all the needs of the local market. \r\n\r\nApply at the depot, home and office use. The tape could be used for home removals, shipping and mailing, for storing and organizing household items', 'Self Adhesive Tape | Packaging Tape', 'The self-adhesive tapes used for packing are made of a water-based adhesive that is coated with BOPP film. We produce a variety of products to meet all need', NULL, NULL),
(5, 6, 'ar', 'الأشرطة-ذاتية-اللصق-السوليتب-المكتبى', 'السوليتب المكتبى', 'السوليتب المكتبى مصنوع من مادة لاصقة أكريليك مائية مطلية بأفلام BOOP.\r\nإنه مناسب للاستخدام للصق الورق ، وتغليف الهدايا وتثبيتها ، وهو سهل الاستخدام كما انه يسهل تمزيقه بدون استخدام القطاعات المخصصة لذلك\r\nمتوفر بأحجام وعروض وتصاميم مختلفة لتلبية متطلبات العميل الخاصة.\r\nالاستعمال: تغليف الهدايا ، التعبئة الخفيفة ، والحرف الفنية ، الاستخدام المكتبي ، إصلاح الورق وتقوية المستندات.', 'الأشرطة ذاتية اللصق | السوليتب المكتبى', 'السوليتب المكتبى مصنوع من مادة لاصقة أكريليك مائية مطلية بأفلام BOOP.\r\nإنه مناسب للاستخدام للصق الورق ، وتغليف الهدايا وتثبيتها ، ', NULL, NULL),
(6, 6, 'en', 'Self-Adhesive-Tape-Stationary-Tape', 'Stationery Tape', 'Stationary tape is made with water based acrylic adhesive coated on BOOP films . \r\nIt’s suitable for paper mending , general sealing , gift wrapping and fixing , also it can be provided as an easy tear that use without dispensers . \r\nAvailable with different sizes, widths and designs to meet the client’s special requirements .\r\nUsage : gift wrapping , light packing , art craft , office use , paper mending and reinforcing documents .', 'Self Adhesive Tape | Stationary Tap', 'Stationary tape is made with water based acrylic adhesive coated on BOOP films . \r\nIt’s suitable for paper mending , general sealing , gift wrapping  ', NULL, NULL),
(7, 7, 'ar', 'الأشرطة-ذاتية-اللصق-ماسك-تيب', 'ماسك تيب', 'شرائط الماسك تيب مصنوع من خامات ورقية مغطى بمادة لاصقة مطاطية يمكن استخدامها في تطبيقات الحماية والتثبيت والأغراض العامة. إنه متوفر بأحجام مختلفة لتلبية متطلبات العميل الخاصة. تستخدم بدرجات حرارة مختلفة للدهان السيارات. وتغطية الأسطح أثناء الرش أو الطلاء. وكذلك حماية الأسطح المعدنية والبلاستيكية والزجاجية.', 'الأشرطة ذاتية اللصق | ماسك تيب تستخدم لاغراض الحماية والتثبيت', 'شرائط الماسك تيب مصنوع من خامات ورقية مغطى بمادة لاصقة مطاطية يمكن استخدامها في تطبيقات الحماية والتثبيت والأغراض العامة. إنه متوفر بأحجام مختلفة ', NULL, NULL),
(8, 7, 'en', 'Self-Adhesive-Tape-Masking-Tape', 'Masking Tape', 'Masking tape is made of crepe paper that coated with rubber adhesive that could use for sealing , holding and general purpose applications. It’s available in different sizes , widths and designs to meet client’s special requirements. It used in different temperature degrees for painting and car’s spray. and Covering surfaces during spraying or painting. and also Protection of metal , plastic and glasses surfaces .', 'Self Adhesive Tape | Masking Tape use for sealing and holding', 'Masking tape is made of crepe paper that coated with rubber adhesive that could use for sealing , holding and general purpose applications. ', NULL, NULL),
(9, 10, 'ar', 'الأشرطة-ذاتية-اللصق-شريط-العزل-الكهربائي', 'شرائط العزل الكهربائي', 'شرائط العزل الكهربائي PVC مصنوعة من البولي فينيل كلوريد (spvc) المطلي بمادة لاصقة حساسة للضغط، كما أنه يعتبر مقاومًا جيدًا لدرجات الحرارة والرطوبة والجهد العالي وتطبيقات الحماية. متوفر بأحجام مختلفة. يستخدم فى تطبيقات الاعمال الكهربائية', 'الأشرطة ذاتية اللصق | شريط العزل الكهربائي ', 'شرائط العزل الكهربائي PVC مصنوعة من البولي فينيل كلوريد (spvc) المطلي بمادة لاصقة حساسة للضغط، كما أنه يعتبر مقاومًا جيدًا لدرجات الحرارة والرطوبة والجهد', NULL, NULL),
(10, 10, 'en', 'Self-Adhesive-Tape-Electrical-Insulating-Tape', 'Electrical Insulating Tape', 'Electrical Insulating Tape PVC insulating tape is made from soft polyvinyl chloride (spvc) which is coated with rubber pressure -sensitive adhesive , it’s also considered good resistant to temperature , moisture , high voltage and protection applications .\r\nIt’s available in different sizes .Usage in Strong tensile strength use in electric work application .', 'Self Adhesive Tape | Electrical Insulating Tape', 'Electrical Insulating Tape PVC insulating tape is made from soft polyvinyl chloride (spvc) which is coated with rubber pressure -sensitive adhesive ', NULL, NULL),
(11, 12, 'ar', 'الأشرطة-ذاتية-اللصق-شرائط-مزدوجة-الوجهين', 'شرائط مزدوجة الوجهين', 'الشرائط مزدوجة الوجهين مصنوعه ومغلفه بمادة لاصقة مذيبة. يتم استخدامه للزينة والخدمات البريدية. متوفره بأحجام وعرض مختلفة لتلبية لمتطلبات العملاء الخاصة. الاستخدام ملاحظات عامة ، تثبيت العناصر والصور ، تغليف الهدايا والخدمات البريدية.', 'الأشرطة ذاتية اللصق | شرائط مزدوجة الوجهين', 'الشرائط مزدوجة الوجهين مصنوعه ومغلفه بمادة لاصقة مذيبة. يتم استخدامه للزينة والخدمات البريدية. متوفره بأحجام وعرض مختلفة لتلبية لمتطلبات العملاء الخاصة. ', NULL, NULL),
(12, 12, 'en', 'Self-Adhesive-Tape-Double-Sided-Tape', 'Double Sided Tape', 'Double side tissue tape is made and coated with solvent adhesive . It’s used for decoration and postal services. It’s available in different sizes , widths and designs to meet client’s special requirements. Usage Public notes , fixing items and photos , gift wrapping and postal services .', 'Self Adhesive Tape | Double Sided Tape', 'Double side tissue tape is made and coated with solvent adhesive . It’s used for decoration and postal services. It’s available in different sizes', NULL, NULL),
(13, 13, 'ar', 'شرائط-ذاتية-اللصق-ملونه', 'شرائط ذاتية اللصق ملونه', 'الشرائط ذاتية اللصق الملونه مصنوعه من أغشية BOPP اللاصقة المائية المصنوعة من الأكريليك ، ويمكن توفيره بألوان عديدة لمساعدة العملاء في عمليات تنظيم وفرز المنتجات اثناء التخزين او النقل متوفر بأحجام وعرض مختلفة لتلبية جميع احتياجات و متطلبات العملاء الخاصة', 'الأشرطة ذاتية اللصق | شرائط ذاتية اللصق ملونه', 'الشرائط ذاتية اللصق الملونه مصنوعه من أغشية BOPP اللاصقة المائية المصنوعة من الأكريليك، ويمكن توفيره بألوان عديدة لمساعدة العملاء في عمليات تنظيم وفرز المنتجات', NULL, NULL),
(14, 13, 'en', 'Self-Adhesive-Color-Tape', 'Color Tape', 'Color tape is made coated with water based acrylic adhesive BOPP films , its can provided in many colors to help customers in a well-organized operations , also in sorting products in the warehouse .\r\nIt’s available in different sizes &amp; width to meet client’s special requirements .\r\nIt can be used in controlling products and sorting different types in warehouses .', 'Self Adhesive Tape | Self Adhesive Color Tape ', 'Color tape is made coated with water based acrylic adhesive BOPP films , its can provided in many colors to help customers in a well-organized operations', NULL, NULL),
(15, 14, 'ar', 'الاشرطة-ذاتية-اللصق-المطبوعة', 'الاشرطة ذاتية اللصق المطبوعة', 'يعد استعدام الاشرطة ذاتية اللصق المطبوعة رائعًا لتغليف المنتجات كما انه يستخدم أيضًا كأداة تسويق فعالة منخفضة التكلفة.\r\nهناك العديد من المزايا المكتسبة من خلال استخدام الاشرطة ذاتية اللصق المطبوعة بصرف النظر عن مجرد اداة لتغليف الصناديق والطرود الخاصة بك بشكل آمن ، حيث يعمل التصميم المتسخدم كهوية بصرية تعزز علامتك التجارية أثناء النقل. إنه أيضًا منتج رائع لزيادة الوعي بعلامتك التجارية.', 'الاشرطة ذاتية اللصق | الاشرطة ذاتية اللصق المطبوعة ', 'يعد استعدام الاشرطة ذاتية اللصق المطبوعة رائعًا لتغليف المنتجات كما انه يستخدم أيضًا كأداة تسويق فعالة منخفضة التكلفة.وهناك العديد من المزايا المكتسبة ', NULL, NULL),
(16, 14, 'en', 'Printed-Self-Adhesive-Tape', 'Printed Self Adhesive Tape', 'Printed Self Adhesive Tape is great for sealing boxes and is also used as an effective low cost Marketing Tool. There are numerous advantages gained by utilizing a custom tape apart from just sealing your boxes securely, the continuous design acts as a visual tamper evident security measure and promotes your brand whilst in transit. It’s also a great product to increase your brand awareness.', 'Self Adhesive Tape | Printed Self Adhesive Tape', 'Printed Self Adhesive Tape is great for sealing boxes and is also used as an effective low cost Marketing Tool. There are numerous advantages ', NULL, NULL),
(17, 15, 'ar', 'ألومنيوم-فويل', 'الألومنيوم فويل', 'رقائق الألومنيوم أو ورق الألومنيوم هو الألومنيوم مُعد بورق رقيق، بسماكة أقل من 0.2 مل، قد تصل في بعض الأحيان إلى سماكة 6 ميكرومتر، يستخدم لتغليف الأطعمة، إن هذه الرقاقات تكون مرنةً وبسهولة يمكن ثنيها وجعلها تلتف حول الأشياء، تكون الرقاقات بعض الأحيان هشةً لذلك يقام بتدعيمها بمواد أخرى كالبلاستيك والورق العادي لجعلها أكثر فائدة. في القرن العشرين حلت رقاقات الألمنيوم محل الرقاقات القصديرية.', 'عتمان جروب متخصصون فى صناعة ألومنيوم فويل', 'رقائق الألومنيوم أو ورق الألومنيوم هو الألومنيوم مُعد بورق رقيق، بسماكة أقل من 0.2 مل، قد تصل في بعض الأحيان إلى سماكة 6 ميكرومتر، يستخدم لتغليف الأطعمة', NULL, NULL),
(18, 15, 'en', 'aluminum-foil', 'Aluminum Foil', 'Aluminium foil is aluminium prepared in thin metal leaves with a thickness less than 0.2 mm thinner gauges down to 6 micrometres (0.24 mils) are also commonly used. The foil is pliable, and can be readily bent or wrapped around objects. Thin foils are fragile and are sometimes laminated with other materials such as plastics or paper to make them stronger and more useful.', 'Atman Group specializes in the manufacture of aluminum foil', 'Aluminium foil is aluminium prepared in thin metal leaves with a thickness less than 0.2 mm thinner gauges down to 6 micrometres (0.24 mils) are also commonly', NULL, NULL),
(19, 16, 'ar', 'الومنيوم-فويل-للاستخدام-الصناعى', 'الومنيوم فويل للاستخدام الصناعى', 'يعد العزل أحد أهم مجالات تطبيق رقائق الألومنيوم. يتم استخدامه على سبيل المثال كطبقة عازلة للحرارة لعزل الأنابيب والقنوات.\r\n\r\nبدأ ظهور رقائق الألومنيوم في صناعة التعبئة والتغليف في وقت مبكر من بداية القرن العشرين. في وقت مبكر من عام 1910 ، كان من الممكن إنتاج ما يصل إلى 10 ميكرولتر (1/100 مم) رقائق ألمنيوم سميكة وتصفيحها بالورق. أدت التحسينات التكنولوجية إلى تطور سريع من استخدام الألمنيوم لتغليف الشوكولاتة إلى تصنيع علب المشروبات ، وكبسولات القهوة ، وصواني الشواء وأغطية الزجاجات.', 'الألومنيوم فويل | الومنيوم فويل للاستخدام الصناعى', 'يعد العزل أحد أهم مجالات تطبيق رقائق الألومنيوم. يتم استخدامه على سبيل المثال كطبقة عازلة للحرارة لعزل الأنابيب والقنوات.', NULL, NULL),
(20, 16, 'en', 'Aluminium-foil-for-Industry-Use', 'Aluminium foil for Industry Use', 'One of the most important fields of application of aluminum foil is insulation. It is used for example as a heat-insulating layer for the insulation of pipes and ducts.\r\n\r\nThe rise of aluminum foil in the packaging industry began as early as the beginning of the 20th century. As early as 1910, it was possible to produce up to 10 μ (1/100 mm) thick aluminum foils and laminate them with paper. Technological improvements have led to a rapid development from the use of aluminum as chocolate packaging to the manufacture of aluminum beverage cans, coffee capsules, grill trays and bottle caps.', 'Aluminium Foil | Aluminium foil for Industry Use', 'One of the most important fields of application of aluminum foil is insulation. It is used for example as a heat-insulating layer for the insulation of pipes ', NULL, NULL),
(21, 17, 'ar', 'الومنيوم-فويل-استخدام-منزلى', 'الومنيوم فويل استخدام منزلى', 'مثالي لاحتياجات الطهي اليومية وسهولة التنظيف آمن للطعام وخالي من أي مواد ضارة.يمكننا توفير علامات تجارية مختلفة للمنتجات النهائية لتلبية متطلبات جميع العملاء.\r\nالاستخدامات للمنزل والمقهى والمطعم. يمكن استخدامها في تغليف الوجبات السريعة.\r\nاستخدم أيضًا في تطبيق الطهي لحماية سطح الفرن.', 'الومنيوم فويل | الومنيوم فويل استخدام منزلى', 'مثالي لاحتياجات الطهي اليومية وسهولة التنظيف غلاف رقائق الطعام آمن للطعام وخالي من أي مواد ضارة.يمكننا توفير علامات تجارية مختلفة للمنتجات ', NULL, NULL),
(22, 17, 'en', 'Aluminium-foil-for-House-Hold', 'Aluminium foil for House Hold', 'Perfect for everyday cooking needs and easy clean up\r\nThe food grade foil wrap is food-safe, free of any harmful substances.\r\nwe can supply different brands for finished products to meet all clients requirement .\r\nUsages for house , cafe and restaurant . can use in fast food packing . \r\nAlso use in cook application for oven surface protection .', 'Aluminium Foil | Aluminium foil for House Hold', 'We can supply finish goods for aluminum foil for house and home use , as need in wrap food in homes.we can supply different brands for finished products to ', NULL, NULL),
(23, 18, 'ar', 'food-and-beverage', 'الأغذية والمشروبات', 'صناعة الأغذية والمشروبات كبيرة ومتنوعة ومليئة بالآلات المتخصصة. إنها واحدة من أقدم الصناعات على هذا الكوكب ، لكنها لا تزال مليئة بالابتكار.\r\n\r\nواستجابةً لحاجة الصناعة إلى هذا التطور السريع ، واهتمامها المتزايد بسلامة الأغذية وأمنها ، نقدم الحلول التي تلبي هذه الاحتياجات الحالية.\r\n\r\nتوفر شركة عتمان جروب مجموعة كبيرة من المنتجات التى تستخدم فى مجال الأطعمة والمشروبات المعبأة في حياتنا اليومية. وتستخدم هذه المنتجات في حياتنا اليومية ويمكننا العثور عليها في كل مكان الآن.', 'عتمان جروب قسم المنتجات الخاصة بالأغذية والمشروبات', 'صناعة الأغذية والمشروبات كبيرة ومتنوعة ومليئة بالآلات المتخصصة. إنها واحدة من أقدم الصناعات على هذا الكوكب ، لكنها لا تزال مليئة بالابتكار.', NULL, NULL),
(24, 18, 'en', 'food-and-beverage', 'Food And Beverage', 'The Food and Beverage Industry is large, diverse, and full of specialized machinery. It’s one of the oldest industries on the planet, but still full of innovation. \r\n\r\nIn response to industry’s need to comply with regulations of all sorts, and an increasing concern for food safety and security, we provide the solutions that meet current needs.\r\n\r\nItems used in smart solution for packed food and beverage in our daily life .These items use in our daily life we can find them every where now a day .', 'Etman Group Food and Beverage Products Division', 'The Food and Beverage Industry is large, diverse, and full of specialized machinery. It’s one of the oldest industries on the planet, but still full', NULL, NULL),
(25, 19, 'ar', 'الاسترتش-الغذائى', 'الاسترتش الغذائى', 'إن أهم دور يلعبه الاسترتش الغذائى في تغليف المواد الغذائية هو الحماية والحفظ. يمكن أن يمنع الاسترتش الغذائى الطعام من الهلاك ، ويطيل عمره الافتراضي ، ويحافظ على جودة الطعام. يوفر الاسترتش الغذائى بشكل عام الحماية للأغذية من ثلاثة جوانب: المواد الكيميائية (الغازات والرطوبة والضوء) والبيولوجية (الكائنات الحية الدقيقة والحشرات والحيوانات) والفيزيائية (الأضرار الميكانيكية). بالإضافة إلى حماية الأغذية وحفظها ، يمكن للاسترتش الغذائى أيضًا أن يقلل من هدر الطعام ، ويسهل عمليات التوزيع', 'الاسترتش الغذائى يستخدم في تغليف المواد الغذائية بغرض الحماية والحفظ', 'إن أهم دور يلعبه الاسترتش الغذائى في تغليف المواد الغذائية بغرض الحماية والحفظ. يمكن أن يمنع الاسترتش الغذائى الطعام من الهلاك', NULL, NULL),
(26, 19, 'en', 'Cling-Warp', 'Cling Warp', 'The most important role Cling Warp plays in food packaging is protection and preservation. Cling Warp can prevent food from perishing, extend its shelf-life, and maintain the quality of food. Cling Warp generally provides protection for food from three aspects: chemical (gases, moisture, and light), biological (microorganisms, insects and animals), and physical (mechanical damage). In addition to food protection and preservation, Cling Warp can also reduce food waste, tag food information, ease the distribution processes, and increase product visibility and microwavability', 'Cling Warp is used in food packaging for the purpose of protection', 'The most important role Cling Warp plays in food packaging is protection and preservation. Cling Warp can prevent food from perishing', NULL, NULL),
(27, 23, 'ar', 'مستلزمات-الهدايا', 'مستلزمات الهدايا', 'الهدايا هي رمز للسعادة والاحتفال. إنها بمثابة إظهار لمشاعرنا ويمكن أن تكون لفتة ذات مغزى تجاه شخص نقدره.\r\nعتمان جروب تمتلك الخبرة الكافية لكى تكون هى الشركة الاولى فى توفير جميع المستلزمات الخاصة بتغليف الهداية بداية من ورق الهدايا مرورا بشنط الهدايا والكوريشة الخ', 'عتمان جروب قسم منتجات الخاصة بمستلزمات الهدايا', 'عتمان جروب تمتلك الخبرة الكافية لكى تكون هى الشركة الاولى فى توفير جميع المستلزمات الخاصة بتغليف الهداية بداية من ورق الهدايا مرورا بشنط الهدايا والكوريشة الخ', NULL, NULL),
(28, 23, 'en', 'decorative-strips', 'Gift Accessories', 'Gifts are a symbol of happiness and celebration. They act as a demonstration of our feelings and can be a meaningful gesture towards someone that we value. \r\n\r\nEtman Group has sufficient experience to be the first company in providing all the requirements for gift wrapping, starting from gift paper through gift bags and cores, etc.', 'Etman Group Products section for Decorative Strips', 'Etman Group has sufficient experience to be the first company in providing all the requirements for gift wrapping, starting from gift paper through gift bags', NULL, NULL),
(29, 24, 'ar', 'مستلزمات-الهدايا-شرائط-الزينة', 'شرائط الزينة', 'عتمان جروب لديها الجودة التي تبحث عنها. من خلال مجموعة كبيرة من الاختيارات ، يمكنك استكشاف تشكيلتنا من أفضل المنتجات. ابحث عن شرائط الزينة ستجد انها من اهم المنتجات الشائع استخدمها بصورة يومية\r\n\r\nعتمان جروب هي مصنع محترف ومصدر للشريط وتمتلك أكثر من 40 عامًا من الخبرة في مجال صناعة شرائط الزينة . مع توفر العمالة الماهرة والمواد الخام المنتجة ذاتيًا ، سيكون التسليم السريع والجودة المستقرة أمرًا سهلاً في شركتنا.\r\n\r\nلدينا تشكيلة كبيرة من منتجات شرائط الزينة ، يمكن استخدامها لتزيين أي منتج. لحفلات الزفاف ، والكريسماس ، وأعياد الميلاد ، والخطوبة ، وعيد الأم ، والتهاني ، وديكورات المهرجانات ، والحرف اليدوية ، والهدايا ، وإكسسوارات الألعاب ، إلخ.', 'مستلزمات الهدايا | منتجات شرائط الزينة بجميع انواعها ', 'عتمان جروب هي مصنع محترف ومصدر للشريط وتمتلك أكثر من 40 عامًا من الخبرة في مجال صناعة شرائط الزينة . مع توفر العمالة الماهرة والمواد الخام المنتجة ذاتيًا ', NULL, NULL),
(30, 24, 'en', 'Gift-Accessories-Ribbon', 'Ribbon', 'Etman Group has the selection and quality you’re looking for. With a collection that includes ribbons in every material,  you can explore our assortment of top product. Find ribbons you’ll find an excuse to use every day ! \r\n\r\nEtman Group  is a professional factory manufacturer &amp; exporter of ribbon More than 40 years experience in handmade ribbon . With skilled workers and self-produced raw materials, fast delivery and stable quality is easy in our company. \r\n\r\nWe have more than styles of ribbon, It can be used for decoration of any product. For wedding, Christmas, Birthday, Engagement,Mother’s day, Congratulations, and other festival decoration, Handcraft, gift and premiums, packing ornament and toy’s accessories etc.', 'Gift Accessories Decorative ribbon products of all kinds ', 'Etman Group is a professional factory manufacturer & exporter of ribbon More than 40 years experience in handmade ribbon .', NULL, NULL),
(31, 25, 'ar', 'ورق-الهدايا', 'ورق الهدايا', 'ورق الهدايا من المنتجات التى يجب الاحتفاظ به في منزلك لجميع احتياجات تغليف الهدايا - أو لف مجموعة متنوعة من العناصر. تم انتجها من خامات عالية الجدوة ، سميكة ولا يمكن تمزقها بسهولة. يمكن استخدامه لتزيين أي منتج. لحفلات الزفاف ، والكريسماس ، وأعياد الميلاد ، والخطوبة ، وعيد الأم ، والتهاني ، والديكورات الأخرى للمهرجانات ، والحرف اليدوية ، والهدايا والأقساط ، وزخرفة التعبئة ، وإكسسوارات الألعاب ، إلخ.', 'مستلزمات الهدايا | جميع منتجات ورق الهدايا من عتمان جروب ', 'ورق الهدايا من المنتجات التى يجب الاحتفاظ به في منزلك لجميع احتياجات تغليف الهدايا - أو لف مجموعة متنوعة من العناصر. تم انتجها من خامات عالية الجدوة ', NULL, NULL),
(32, 25, 'en', 'Gift-Accessories-Gift-Paper', 'Gift Paper', 'Gift Paper is a must-have to keep in your home for all your gift wrapping needs – use it for gift bags or wrapping a variety of items. Created with high-quality paper materials, thick and not easily tear or rip. Item came with shrink film to prevent wrapping paper from scratches and reduce dust.It can be used for decoration of any product. For wedding, Christmas, Birthday, Engagement,Mother’s day, Congratulations, and other festival decoration, Handcraft, gift and premiums, packing ornament and toy’s accessories etc.', 'Gift Accessories |  All gift paper products from Etman Group', 'Gift Paper is a must-have to keep in your home for all your gift wrapping needs use it for gift bags or wrapping a variety of items. Created with high-quality', NULL, NULL),
(33, 26, 'ar', 'مستلزمات-الهدايا-الكوريشة', 'الكوريشة', 'تستخدم ورق الكوريشة عالي الجودة الخاص بنا لإنشاء باقة زهور جميلة مثالي لحفلات الزفاف والذكرى السنوية واحتفالات أعياد الميلاد وحفلات التخرج وحفلات استقبال المولود الجديد وحفلات الخطوبة والمزيد!', 'مستلزمات الهدايا | جميع انواع منتجات الكوريشة المستوردة ', 'تستخدم ورق الكوريشة عالي الجودة الخاص بنا لإنشاء باقة زهور جميلة مثالي لحفلات الزفاف والذكرى السنوية واحتفالات أعياد الميلاد وحفلات التخرج ', NULL, NULL),
(34, 26, 'en', 'Gift-Accessories-Crepe-Paper', 'Crepe Paper', 'Premium Quality Crepe Paper Rolls,Crepe Paper flowers are a fabulous alternative to fresh flowers! Use our quality Crepe Paper to create a beautiful floral bouquet that will last for years to come. Perfect for weddings, anniversaries, birthday celebrations, graduations, baby showers, engagement parties, and more !', 'Gift Accessories | All type of imported Crepe Paper products ', 'Premium Quality Crepe Paper Rolls,Crepe Paper flowers are a fabulous alternative to fresh flowers! Use our Crepe Paper to create a beautiful floral bouquet ', NULL, NULL),
(35, 36, 'ar', 'الأشرطة-ذاتية-اللصق-ليزير-تيب', 'ليزير تيب', 'ليزير تيب يستخدام فى اعمال التغليف وكذلك فى الديكورات والاعمال الفنية و الحفلات وكذلك الاستخدامات المكتبية يمكننا توفير 6 ألوان مختلفة لتلبية طلب العميل.', 'الأشرطة ذاتية اللصق | ليزير تيب يستخدام فى اعمال التغليف والديكور ', 'ليزير تيب يستخدام فى اعمال التغليف وكذلك فى الديكورات والاعمال الفنية و الحفلات وكذلك الاستخدامات المكتبية يمكننا توفير 6 ألوان مختلفة لتلبية طلب العميل.', NULL, NULL),
(36, 36, 'en', 'Self-Adhesive-Tape-Laser-Tape', 'Laser Tape', 'Laser Tape use for sealing and decorative Use in parties and stationery we can supply 6 different colors to meet client request.', 'Self Adhesive Tape | LASER Tape Use in parties and stationery ', 'Laser Tape use for sealing and decorative Use in parties and stationery we can supply 6 different colors to meet client request.', NULL, NULL),
(37, 37, 'ar', 'جامبو-رول', 'جامبو رول', 'شرائط BOPP الجامبو رول هي منتج نصف نهائى يستخدمه المصنعون للشرائط ذاتية اللصق عن طريق اعادة تقطيعه على الماكينات المجهزة لذلك مع منتجاتنا نضمن افضل جودة تساعدك على تقديم افضل منتج نهائى يستطيع المنافسة فى الاسواق المحلية والعالمية \r\n\r\nيمكننا توريد جميع أنواع الشرائط ذاتية اللصق BOPP بسماكات وألوان مختلفة ، عادي / مطبوع في رولات جامبو من جميع العروض والسمك.', 'الأشرطة ذاتية اللصق | جامبو رول | عتمان جروب', 'شرائط BOPP الجامبو رول هي منتج نصف نهائى يستخدمه المصنعون للشرائط ذاتية اللصق عن طريق اعادة تقطيعه على الماكينات المجهزة لذلك مع منتجاتنا نضمن افضل جودة', NULL, NULL),
(38, 37, 'en', 'Jumbo-Roll', 'Jumbo Roll', 'BOPP jumbo roll tape is Semi-finished product for Semi manufacturers slitting it into smaller rolls on the slitting machine. With our products, You can assure your brand quality stability.\r\n\r\nWe can supply all kinds of BOPP Self adhesive tape in various thicknesses, colors, plain/printed in Jumbo rolls of all widths and thickness.', 'Jumbo Roll | Self Adhesive Tape | Etman Group', 'BOPP jumbo roll tape is Semi-finished product for Semi manufacturers slitting it into smaller rolls on the slitting machine.We can supply all kinds of BOPP', NULL, NULL),
(39, 38, 'ar', 'ادوات-مكتبية', 'ادوات مكتبية', 'ادوات مكتبية', 'ادوات مكتبية', 'ادوات مكتبية', NULL, NULL),
(40, 38, 'en', 'stationary', 'Stationary', 'Stationary', 'Stationary', 'Stationary', NULL, NULL),
(41, 39, 'ar', 'مسدسات-الشمع', 'مسدسات الشمع', 'مسدسات الشمع', 'مسدسات الشمع', 'مسدسات الشمع', NULL, NULL),
(42, 39, 'en', 'glue-gun', 'Glue Gun', 'Glue Gun', 'Glue Gun', 'Glue Gun', NULL, NULL),
(43, 40, 'ar', 'اكواب-ورقيه', 'اكواب ورقيه', 'اكواب ورقيه', 'اكواب ورقيه', 'اكواب ورقيه', NULL, NULL),
(44, 40, 'en', 'paper-cups', 'Paper Cups', 'Paper Cups', 'Paper Cups', 'Paper Cups', NULL, NULL),
(45, 41, 'ar', 'استيك-نقدية', 'استيك نقدية', 'استيك نقدية', 'استيك نقدية', 'استيك نقدية', NULL, NULL),
(46, 41, 'en', 'cash-stick', 'Cash stick', 'Cash stick', 'Cash stick', 'Cash stick', NULL, NULL),
(47, 42, 'ar', 'مستلزمات-أعياد-ميلاد', 'مستلزمات أعياد ميلاد', 'مستلزمات أعياد ميلاد', 'مستلزمات أعياد ميلاد', 'مستلزمات أعياد ميلاد', NULL, NULL),
(48, 42, 'en', 'birthday-supplies', 'Birthday supplies', 'Birthday supplies', 'Birthday supplies', 'Birthday supplies', NULL, NULL),
(49, 43, 'ar', 'ورق-تصوير', 'ورق تصوير', 'ورق تصوير', 'ورق تصوير', 'ورق تصوير', NULL, NULL),
(50, 43, 'en', 'photocopy-paper', 'Photocopy paper', 'Photocopy paper', 'Photocopy paper', 'Photocopy paper', NULL, NULL),
(51, 44, 'ar', 'قطر', 'قطر', 'قطر', 'قطر', 'قطر', NULL, NULL),
(52, 44, 'en', 'cutter', 'Cutter', 'Cutter', 'Cutter', 'Cutter', NULL, NULL),
(53, 45, 'ar', 'اطباق-بلاستيك', 'اطباق بلاستيك', 'اطباق بلاستيك', 'اطباق بلاستيك', 'اطباق بلاستيك', NULL, NULL),
(54, 45, 'en', 'plastic-dishes', 'Plastic dishes', 'Plastic dishes', 'Plastic dishes', 'Plastic dishes', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_def_photos`
--

CREATE TABLE `config_def_photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_def_photos`
--

INSERT INTO `config_def_photos` (`id`, `cat_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `postion`, `created_at`, `updated_at`) VALUES
(1, 'light-logo', 'images/def-photo/light-logo-AJG4FyEGq8.webp', NULL, NULL, 2, '2023-09-03 15:03:13', '2023-09-03 15:04:25'),
(2, 'dark-logo', 'images/def-photo/dark-logo-yHavtqPGm6.webp', NULL, NULL, 1, '2023-09-03 15:04:17', '2023-09-03 15:04:25'),
(3, 'about-1', 'images/def-photo/about-1-yn7io2tGJe.webp', NULL, NULL, 0, '2023-09-04 14:21:50', '2023-09-04 14:21:50'),
(4, 'about-2', 'images/def-photo/about-2-hRbvFjEYBB.webp', NULL, NULL, 0, '2023-09-04 14:22:23', '2023-09-08 14:41:31'),
(5, 'faq-icon', 'images/def-photo/faq-icon-Trcw3x3A7W.webp', 'images/def-photo/faq-icon-Ns5XjqT77R.webp', NULL, 0, '2023-09-04 18:17:24', '2023-09-04 18:24:42'),
(6, 'contact-from', 'images/def-photo/contact-from-taOS5rT9SI.webp', NULL, NULL, 0, '2023-09-06 19:37:35', '2023-09-06 19:37:35'),
(7, 'blog', 'images/def-photo/blog-CDdCixPmfn.webp', 'images/def-photo/blog-EE6OS73peP.webp', NULL, 0, '2023-09-07 11:29:31', '2023-09-07 11:32:49'),
(8, 'categorie', 'images/def-photo/categorie-9HziJATU67.webp', NULL, NULL, 0, '2023-09-07 16:54:20', '2023-09-07 17:40:43'),
(9, 'banner_1', 'images/def-photo/banner-1-VLqPKFQFUX.webp', NULL, NULL, 0, '2023-09-11 09:43:54', '2023-09-11 10:21:22'),
(10, 'whatsapp', 'images/def-photo/whatsapp-rJdy3I8bAn.webp', NULL, NULL, 0, '2023-09-11 10:15:56', '2023-09-11 10:15:56'),
(11, 'direction', 'images/def-photo/direction-HxHKFfw5Qy.webp', NULL, NULL, 0, '2023-09-11 10:36:35', '2023-09-11 10:39:29'),
(12, 'shop_banner', 'images/def-photo/shop-banner-gkb95aTjI6.webp', NULL, NULL, 0, '2023-09-11 10:41:58', '2023-09-11 11:22:05'),
(13, 'offer-1', 'images/def-photo/offer-1-ZEhHpqSHCu.webp', NULL, NULL, 0, '2023-09-11 21:24:36', '2023-09-11 21:28:49');

-- --------------------------------------------------------

--
-- Table structure for table `config_settings`
--

CREATE TABLE `config_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `web_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_status` int(11) NOT NULL DEFAULT 1,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `def_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_api` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `download_app` int(11) NOT NULL DEFAULT 0,
  `top_offer` int(11) NOT NULL DEFAULT 0,
  `apple` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `android` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `windows` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_settings`
--

INSERT INTO `config_settings` (`id`, `web_url`, `web_status`, `logo`, `favicon`, `phone_num`, `whatsapp_num`, `phone_text`, `whatsapp_text`, `facebook`, `youtube`, `twitter`, `instagram`, `linkedin`, `def_url`, `google_api`, `download_app`, `top_offer`, `apple`, `android`, `windows`, `created_at`, `updated_at`) VALUES
(1, '#', 1, '', '', '01006180117', '201006180117', '0100-6180-117', '0100-6180-117', 'https://www.facebook.com/Etman.Group', 'https://www.youtube.com/channel/UC8GkiBf6L9bogsUtx0PEgTg', '#', 'https://www.instagram.com/etmangroup.eg/', 'https://www.linkedin.com/company/etman-group/', 'https://etman-group.com', 'AIzaSyDWuKOMM4hm_uBnQjqQufaLlHSN2QS_4Qo', 1, 1, 'https://www.apple.com/store', 'https://play.google.com/store/apps?hl=en&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;gl=US', 'https://www.microsoft.com/en-eg/store/', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_setting_translations`
--

CREATE TABLE `config_setting_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed_mass` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_setting_translations`
--

INSERT INTO `config_setting_translations` (`id`, `setting_id`, `locale`, `name`, `g_title`, `g_des`, `closed_mass`, `offer`) VALUES
(1, 1, 'ar', 'عتمان جروب', 'عنوان الصفحة يكتب هنا', 'وصف الصفحة يكتب هنا', 'زوار موقعنا الكرام ... تلبية لرغبتكم الكريمة فى تطوير الموقع \r\nوليرتقى للمستوى العالمى فى تقديم كل ما يهمكم \r\nنحن بصدد تطوير الموقع كليا ليتناسب معكم\r\nادارة الموقع', 'شحن مجانى للطلبات اكثر من 2500 جنية داخل الاسكندرية'),
(2, 1, 'en', 'Etman Group', 'The title of the site is written here', 'The description of the site is written here', 'Dear visitors ... In response to your generous desire to develop the site ... and to rise to the international level in providing everything that interests you ... \r\nWe are in the process of developing the website completely to suit you ..\r\nSite Administration', 'Free Ground Shipping Over  2500 LE');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filters`
--

CREATE TABLE `config_upload_filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `convert_state` int(11) NOT NULL DEFAULT 1,
  `quality_val` int(11) NOT NULL DEFAULT 85,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ffffff',
  `greyscale` int(11) NOT NULL DEFAULT 0,
  `flip_state` int(11) NOT NULL DEFAULT 0,
  `flip_v` int(11) NOT NULL DEFAULT 0,
  `blur` int(11) NOT NULL DEFAULT 0,
  `blur_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pixelate` int(11) NOT NULL DEFAULT 0,
  `pixelate_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '5',
  `text_state` int(11) NOT NULL DEFAULT 0,
  `text_print` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_opacity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_state` int(11) NOT NULL DEFAULT 0,
  `watermark_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filters`
--

INSERT INTO `config_upload_filters` (`id`, `name`, `type`, `convert_state`, `quality_val`, `new_w`, `new_h`, `canvas_back`, `greyscale`, `flip_state`, `flip_v`, `blur`, `blur_size`, `pixelate`, `pixelate_size`, `text_state`, `text_print`, `font_size`, `font_path`, `font_color`, `font_opacity`, `text_position`, `watermark_state`, `watermark_img`, `watermark_position`, `state`, `created_at`, `updated_at`) VALUES
(1, 'NoEdit', 1, 1, 85, 100, 100, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(2, 'DefPhoto', 4, 1, 85, 800, 420, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(3, 'FavIcon', 4, 1, 85, 40, 40, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(4, 'صورة المجموعة', 4, 1, 85, 600, 600, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-09 07:44:42'),
(5, 'PhotoGallery', 4, 1, 85, 1024, 768, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(6, 'اخر الاخبار', 4, 1, 85, 450, 237, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-07 11:27:22', '2023-09-07 11:27:22'),
(7, 'بانر', 4, 1, 85, 840, 410, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-11 09:36:55', '2023-09-11 10:03:12'),
(8, 'صورة المنتج', 5, 1, 85, 1000, 1000, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-11 17:01:05', '2023-09-11 17:01:39');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filter_sizes`
--

CREATE TABLE `config_upload_filter_sizes` (
  `id` int(10) UNSIGNED NOT NULL,
  `filter_id` int(10) UNSIGNED NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_more_option` int(11) NOT NULL DEFAULT 0,
  `get_add_text` int(11) NOT NULL DEFAULT 0,
  `get_watermark` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filter_sizes`
--

INSERT INTO `config_upload_filter_sizes` (`id`, `filter_id`, `type`, `new_w`, `new_h`, `canvas_back`, `get_more_option`, `get_add_text`, `get_watermark`) VALUES
(1, 2, 4, 500, 335, NULL, 0, 0, 0),
(2, 4, 4, 400, 400, '#FFFFFF', 0, 0, 0),
(3, 5, 4, 800, 600, '#ffffff', 0, 0, 0),
(4, 5, 4, 320, 240, '#ffffff', 0, 0, 0),
(5, 6, 4, 900, 473, '#FFFFFF', 0, 0, 0),
(6, 7, 4, 420, 205, '#FFFFFF', 0, 0, 0),
(7, 8, 5, 350, 350, '#FFFFFF', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacies`
--

CREATE TABLE `config_web_privacies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacies`
--

INSERT INTO `config_web_privacies` (`id`, `name`, `postion`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'شروط وسياسة الخصوصية', 2, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(3, 'جمع المعلومات واستخدامها', 3, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(4, 'أنواع البيانات المجمعة', 4, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(5, 'بيانات الاستخدام', 5, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(6, 'تتبع و ملفات تعريف الارتباط', 6, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(7, 'استخدام البيانات', 7, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(8, 'نقل البيانات', 8, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(9, 'الكشف عن البيانات', 9, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(10, 'أمن البيانات', 10, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(11, 'مقدمي الخدمة', 11, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(12, 'تحليلات', 12, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(13, 'روابط لمواقع أخرى', 13, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(14, 'خصوصية الأطفال', 14, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(15, 'تغييرات سياسة الخصوصية', 15, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(16, 'اتصل بنا', 16, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57');

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacy_translations`
--

CREATE TABLE `config_web_privacy_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `privacy_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `h2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lists` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacy_translations`
--

INSERT INTO `config_web_privacy_translations` (`id`, `privacy_id`, `locale`, `h1`, `h2`, `des`, `lists`) VALUES
(3, 2, 'ar', 'شروط وسياسة الخصوصية', '', 'تقوم شركة [CompanyName] (\"نحن\" أو \"نحن\" أو \"موقعنا\") بتشغيل [WebSiteName]  (\"الموقع الالكترونى\").\r\nتُعرفك هذه الصفحة بسياساتنا المتعلقة بجمع البيانات الشخصية واستخدامها والكشف عنها عند استخدامك للخدمة والأختيارات المرتبطة بهذه البيانات. \r\nسياسة الخصوصية لشركة [CompanyName]\r\nنستخدم بياناتك لتوفير الخدمة وتحسينها. باستخدام الخدمة، فإنك توافق على جمع واستخدام المعلومات وفقًا لهذه السياسة. ما لم يتم تحديد خلاف ذلك في سياسة الخصوصية، فإن المصطلحات المستخدمة في سياسة الخصوصية لها نفس المعاني كما في الشروط والأحكام الخاصة بنا، والتي يمكن الوصول إليها من [WebSiteName]', ''),
(4, 2, 'en', 'Privacy Policy', '', ' [CompanyName] (\"us\", \"we\", or \"our\") operates the [WebSiteName] website (the \"Service\").\r\nThis page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. Our Privacy Policy for [CompanyName]\r\nWe use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from  [WebSiteName]', ''),
(5, 3, 'ar', 'جمع المعلومات واستخدامها', '', 'نقوم بتجميع أنواع مختلفة من المعلومات لأغراض متنوعة لتوفير وتحسين خدماتنا لك.', ''),
(6, 3, 'en', 'Information Collection And Use', '', 'We collect several different types of information for various purposes to provide and improve our Service to you.', ''),
(7, 4, 'ar', 'أنواع البيانات المجمعة', 'بيانات شخصية', 'أثناء استخدام خدماتنا ، قد نطلب منك تزويدنا بمعلومات تعريف شخصية معينة يمكن استخدامها للاتصال أو التعرف عليك (&quot;البيانات الشخصية&quot;). قد تتضمن معلومات \r\nالتعريف الشخصية ، على سبيل المثال لا الحصر ، ما يلي:', 'عنوان بريد الكتروني\r\nالاسم الأول واسم العائلة\r\nرقم الهاتف\r\nالعنوان ، الولاية ، المقاطعة ، الرمز البريدي / المدينة ، المدينة\r\nملفات تعريف الارتباط وبيانات الاستخدام'),
(8, 4, 'en', 'Types of Data Collected', 'Personal Data', 'While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (&quot;Personal Data&quot;). Personally identifiable information may include, but is not limited to :', 'Email address\r\nFirst name and last name\r\nPhone number\r\nAddress, State, Province, ZIP/Postal code, City\r\nCookies and Usage Data'),
(9, 5, 'ar', 'بيانات الاستخدام', '', 'يجوز لنا أيضًا جمع المعلومات حول كيفية الوصول إلى الخدمة واستخدامها (&quot;بيانات الاستخدام&quot;). قد تتضمن بيانات الاستخدام هذه معلومات مثل عنوان بروتوكول الإنترنت الخاص بجهاز الكمبيوتر (مثل عنوان IP) ، ونوع المتصفح، وإصدار المتصفح، وصفحات الخدمة التي تزورها، ووقت وتاريخ زيارتك، والوقت الذي يقضيه في تلك الصفحات، ومعرفات الجهاز وغيرها من البيانات التشخيصية.', ''),
(10, 5, 'en', 'Usage Data', '', 'We may also collect information how the Service is accessed and used (&quot;Usage Data&quot;). This Usage Data may include information such as your computer\'s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.', ''),
(11, 6, 'ar', 'تتبع و ملفات تعريف الارتباط', '', 'نحن نستخدم ملفات تعريف الارتباط وتقنيات التتبع المماثلة لتتبع النشاط على الخدمة لدينا مع الاحتفاظ بمعلومات معينة.\r\nملفات تعريف الارتباط عبارة عن ملفات تحتوي على كمية صغيرة من البيانات التي قد تتضمن معرفًا فريدًا مجهول الهوية. يتم إرسال ملفات تعريف الارتباط إلى متصفحك من موقع الويب وتخزينها على جهازك. تقنيات التتبع المستخدمة هي منارات وعلامات ونصوص لجمع المعلومات وتتبعها ولتحسين خدمتنا وتحليلها.\r\nيمكنك إرشاد المتصفح الخاص بك لرفض جميع ملفات تعريف الارتباط أو للإشارة إلى إرسال ملف تعريف الارتباط. ومع ذلك، إذا كنت لا تقبل ملفات تعريف الارتباط، فقد لا تتمكن من استخدام بعض أجزاء من خدمتنا.\r\n\r\nأمثلة على ملفات تعريف الارتباط التي نستخدمها:', 'نحن نستخدم ملفات تعريف الارتباط الخاصة بالجلسات لتشغيل الخدمة الخاصة بنا.\r\nنحن نستخدم ملفات تعريف الارتباط التفضيلية لتذكر تفضيلاتك والإعدادات المختلفة.\r\nنحن نستخدم ملفات تعريف الارتباط للأمان لأغراض أمنية.'),
(12, 6, 'en', 'Tracking &amp; Cookies Data', '', 'We use cookies and similar tracking technologies to track the activity on our Service and hold certain information.\r\nCookies are files with small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service.\r\nYou can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.\r\n\r\nExamples of Cookies we use:', 'Session Cookies. We use Session Cookies to operate our Service.\r\nPreference Cookies. We use Preference Cookies to remember your preferences and various settings.\r\nSecurity Cookies. We use Security Cookies for security purposes.'),
(13, 7, 'ar', 'استخدام البيانات', '', 'تستخدم [CompanyName] البيانات التي تم جمعها لأغراض مختلفة :', 'لإعلامك عن تغييرات لخدمتنا.\r\nللسماح لك بالمشاركة في الميزات التفاعلية في خدمتنا عندما تختار القيام بذلك.\r\nلتوفير رعاية العملاء والدعم.\r\nلتقديم تحليل أو معلومات قيمة حتى نتمكن من تحسين الخدمة.\r\nلمراقبة استخدام الخدمة.\r\nللكشف عن المشكلات الفنية ومنعها ومعالجتها.'),
(14, 7, 'en', 'Use of Data', '', '[CompanyName] uses the collected data for various purposes:', 'To provide and maintain the Service.\r\nTo notify you about changes to our Service.\r\nTo allow you to participate in interactive features of our Service when you choose to do so.\r\nTo provide customer care and support.\r\nTo provide analysis or valuable information so that we can improve the Service.\r\nTo monitor the usage of the Service.\r\nTo detect, prevent and address technical issues.'),
(15, 8, 'ar', 'نقل البيانات', '', 'قد يتم نقل معلوماتك - بما في ذلك البيانات الشخصية - إلى أجهزة الكمبيوتر الموجودة خارج الولاية أو المقاطعة أو الدولة أو الولاية الحكومية الأخرى التي قد تختلف فيها قوانين حماية البيانات عن تلك الخاصة باختصاصك القضائي.\r\nإذا كنت متواجدًا خارج مصر واخترت تقديم معلومات لنا، يرجى ملاحظة أننا نقوم بنقل البيانات، بما في ذلك البيانات الشخصية، إلى مصر ومعالجتها هناك.\r\nإن موافقتك على سياسة الخصوصية هذه والتي يتبعها تقديمك لهذه المعلومات تمثل موافقتك على هذا النقل \r\nسوف تتخذ [CompanyName] جميع الخطوات الضرورية بشكل معقول لضمان التعامل مع بياناتك بشكل آمن ووفقًا لسياسة الخصوصية هذه ولن يتم نقل بياناتك الشخصية إلى منظمة أو دولة ما لم تكن هناك ضوابط كافية في مكان بما في ذلك أمن البيانات الخاصة بك وغيرها من المعلومات الشخصية.', ''),
(16, 8, 'en', 'Transfer Of Data', '', 'Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction.\r\nIf you are located outside Egypt and choose to provide information to us, please note that we transfer the data, including Personal Data, to Egypt and process it there.\r\nYour consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.\r\n[CompanyName] will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information.', ''),
(17, 9, 'ar', 'الكشف عن البيانات', 'المتطلبات القانونية', 'يحق لـ [CompanyName] الإفصاح عن بياناتك الشخصية بحسن نية من أن هذا الإجراء ضروري من أجل:', 'للامتثال لالتزام قانوني\r\nلحماية والدفاع عن حقوق أو ملكية [CompanyName]\r\nلمنع أو التحقيق في أي مخالفات محتملة تتعلق بالخدمة.\r\nلحماية السلامة الشخصية لمستخدمي الخدمة أو الجمهور.\r\nللحماية من المسؤولية القانونية.'),
(18, 9, 'en', 'Disclosure Of Data', 'Legal Requirements', '[CompanyName] may disclose your Personal Data in the good faith belief that such action is necessary to:', 'To comply with a legal obligation.\r\nTo protect and defend the rights or property of [CompanyName]\r\nTo prevent or investigate possible wrongdoing in connection with the Service.\r\nTo protect the personal safety of users of the Service or the public.\r\nTo protect against legal liability.'),
(19, 10, 'ar', 'أمن البيانات', '', 'أمان بياناتك مهم بالنسبة لنا، ولكن تذكر أنه لا توجد طريقة للإرسال عبر الإنترنت، أو طريقة التخزين الإلكترونية آمنة ١٠٠٪. بينما نسعى جاهدين لاستخدام وسائل مقبولة تجاريًا لحماية بياناتك الشخصية، لا يمكننا ضمان أمانها المطلق.', ''),
(20, 10, 'en', 'Security Of Data', '', 'The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.', ''),
(21, 11, 'ar', 'مقدمي الخدمة', '', 'يجوز لنا أن نوظف شركات وأفراد من أطراف ثالثة لتسهيل خدمتنا (&quot;مزودي الخدمة&quot;)، أو تقديم الخدمة نيابة عنا، لأداء الخدمات المتعلقة بالخدمة أو لمساعدتنا في تحليل كيفية استخدام خدمتنا.\r\nهذه الأطراف الثالثة لديها حق الوصول إلى بياناتك الشخصية فقط لأداء هذه المهام نيابة عنا وتكون ملزمة بعدم الكشف عنها أو استخدامها لأي غرض آخر.', ''),
(22, 11, 'en', 'Service Providers', '', 'We may employ third party companies and individuals to facilitate our Service (&quot;Service Providers&quot;), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.\r\nThese third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.', ''),
(23, 12, 'ar', 'تحليلات', '', 'قد نستخدم مزودي خدمة من جهات خارجية لمراقبة وتحليل استخدام خدماتنا.', ''),
(24, 12, 'en', 'Analytics', '', 'We may use third-party Service Providers to monitor and analyze the use of our Service.', ''),
(25, 13, 'ar', 'روابط لمواقع أخرى', '', 'قد تحتوي خدمتنا على روابط إلى مواقع أخرى لا يتم تشغيلها من قبلنا. إذا نقرت على رابط جهة خارجية، فسيتم توجيهك إلى موقع الطرف الثالث هذا. ننصحك بشدة بمراجعة سياسة الخصوصية لكل موقع تزوره.\r\n\r\nليس لدينا أي سيطرة ولا نتحمل أي مسؤولية عن المحتوى أو سياسات الخصوصية أو الممارسات الخاصة بأي مواقع أو خدمات خاصة بطرف ثالث.', ''),
(26, 13, 'en', 'Links To Other Sites', '', 'Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party\'s site. We strongly advise you to review the Privacy Policy of every site you visit.\r\n\r\nWe have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.', ''),
(27, 14, 'ar', 'خصوصية الأطفال', '', 'لا تتناول خدمتنا أي شخص دون سن ١٨ عامًا (&quot;الأطفال&quot;).\r\nنحن لا نجمع معلومات التعريف الشخصية من أي شخص دون سن ١٨ عامًا. إذا كنت أحد الوالدين أو الوصي وكنت على علم بأن أطفالك قد زودونا ببيانات شخصية، يرجى الاتصال بنا. إذا علمنا أننا جمعنا بيانات شخصية من الأطفال دون التحقق من موافقة الوالدين، فإننا نتخذ خطوات لإزالة تلك المعلومات من خوادمنا.', ''),
(28, 14, 'en', 'Children\'s Privacy', '', 'Our Service does not address anyone under the age of 18 (&quot;Children&quot;).\r\nWe do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.', ''),
(29, 15, 'ar', 'تغييرات سياسة الخصوصية', '', 'يجوز لنا تحديث سياسة الخصوصية الخاصة بنا من وقت لآخر. سنعلمك بأي تغييرات عن طريق نشر سياسة الخصوصية الجديدة على هذه الصفحة.\r\nسنخبرك عبر البريد الإلكتروني و/ أو بإشعار بارز في خدمتنا، قبل أن يصبح التغيير ساريًا وتحديث &quot;تاريخ الفعالية&quot; في أعلى سياسة الخصوصية هذه.\r\nننصحك بمراجعة سياسة الخصوصية هذه بشكل دوري لأية تغييرات. تسري التغييرات التي تطرأ على سياسة الخصوصية هذه عند نشرها على هذه الصفحة.', ''),
(30, 15, 'en', 'Changes To This Privacy Policy', '', 'We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.\r\n\r\nWe will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the &quot;effective date&quot; at the top of this Privacy Policy.\r\n\r\nYou are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.', ''),
(31, 16, 'ar', 'اتصل بنا', '', 'إذا كان لديك أي أسئلة حول سياسة الخصوصية هذه، يرجى الاتصال بنا:', 'البريد الإلكتروني : info@etman-group.com'),
(32, 16, 'en', 'Contact Us', '', 'If you have any questions about this Privacy Policy, please contact us:', 'Email:info@etman-group.com');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `url_type` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `category_id`, `is_active`, `postion`, `url_type`, `deleted_at`, `created_at`, `updated_at`) VALUES
(5, 3, 1, 3, 0, NULL, '2023-08-27 12:03:26', '2023-08-27 12:06:18'),
(6, 3, 1, 2, 0, NULL, '2023-08-27 12:04:13', '2023-08-27 12:06:18'),
(7, 3, 1, 1, 0, NULL, '2023-08-27 12:04:47', '2023-08-27 12:06:16'),
(8, 4, 1, 0, 0, NULL, '2023-08-27 12:06:06', '2023-08-27 12:06:06');

-- --------------------------------------------------------

--
-- Table structure for table `faq_categories`
--

CREATE TABLE `faq_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faq_categories`
--

INSERT INTO `faq_categories` (`id`, `photo`, `photo_thum_1`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(3, 'images/faq/3/addresses-and-branches-2ogX9Zddyr.webp', 'images/faq/3/addresses-and-branches-zylgbOzqDx.webp', 1, NULL, '2023-08-27 12:01:47', '2023-09-04 17:31:22'),
(4, 'images/faq/4/orders-Z43w16Piaa.webp', 'images/faq/4/orders-InsqX8PYCK.webp', 1, NULL, '2023-08-27 12:02:11', '2023-09-04 17:21:09'),
(5, 'images/faq/5/delivery-services-2l3zVhShyK.webp', 'images/faq/5/delivery-services-myRoBVtBNN.webp', 1, NULL, '2023-08-27 12:02:34', '2023-09-04 17:34:35'),
(6, 'images/faq/6/shipping-services-to-governorates-N1nNSGhs3y.webp', 'images/faq/6/shipping-services-to-governorates-C0V2L8U3x8.webp', 1, NULL, '2023-09-04 17:32:24', '2023-09-04 17:37:38'),
(7, 'images/faq/7/return-policy-RehZSdRBQc.webp', 'images/faq/7/return-policy-T52ZJYpPeG.webp', 1, NULL, '2023-09-04 17:40:47', '2023-09-04 18:00:57'),
(8, 'images/faq/8/special-requests-Q7daV2qDjO.webp', 'images/faq/8/special-requests-SxtYreiw8X.webp', 1, NULL, '2023-09-04 17:42:50', '2023-09-04 17:47:30'),
(9, 'images/faq/9/export-services-0683Y1LNcz.webp', 'images/faq/9/export-services-Kl51UaGbET.webp', 1, NULL, '2023-09-04 17:48:53', '2023-09-04 17:54:44'),
(10, NULL, NULL, 1, NULL, '2023-09-04 18:02:07', '2023-09-04 18:02:07');

-- --------------------------------------------------------

--
-- Table structure for table `faq_category_translations`
--

CREATE TABLE `faq_category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faq_category_translations`
--

INSERT INTO `faq_category_translations` (`id`, `category_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(5, 3, 'ar', 'العناوين-والفروع', 'العناوين والفروع', 'اكتشف مواقع فروعنا في مصر حيث يمكنك تجربة التسوق و استكشاف منتجات فريدة والحصول على مساعدة من طاقمنا الودود. اعثر على تفاصيل العناوين ومعلومات الاتصال لتحديد مواقع فروعنا والوصول إليها بسهولة.', 'العناوين والفروع | اكتشف مواقع فروعنا بمصر', 'اكتشف مواقع فروعنا في مصر حيث يمكنك تجربة التسوق و استكشاف منتجات فريدة والحصول على مساعدة من طاقمنا الودود. اعثر على تفاصيل العناوين ومعلومات الاتصال'),
(6, 3, 'en', 'addresses-and-branches', 'Addresses and branches', 'Discover our physical store locations in egypt. where you can experience personalized shopping, explore unique products, and receive assistance from our friendly staff. Find detailed addresses and contact information to easily locate and reach our branches.', 'Addresses and branches | Discover our locations in egypt.', 'Addresses and branches We provide fast and reliable delivery service to all governorates of Egypt. We provide fast and reliable delivery service to'),
(7, 4, 'ar', 'الطلبات', 'الطلبات', 'في هذه الصفحة يمكنك العثور على إجابات على الأسئلة المتكررة حول تقديم الطلبات وتتبعها. اكتشف المزيد حول طرق الدفع والشحن وأوقات التسليم.', 'الطلبات | العثور على إجابات على الأسئلة المتكررة حول الطلبات', 'في هذه الصفحة يمكنك العثور على إجابات على الأسئلة المتكررة حول تقديم الطلبات وتتبعها. اكتشف المزيد حول طرق الدفع والشحن وأوقات التسليم.'),
(8, 4, 'en', 'orders', 'Orders', 'On this page, you can find answers to frequently asked questions concerning ordering and tracking. Find out about payments, shipping, and delivery times.', 'Orders | find answers to FAQs concerning ordering.', 'On this page, you can find answers to frequently asked questions concerning ordering and tracking. Find out about payments, shipping, and delivery times.'),
(9, 5, 'ar', 'خدمات-التوصيل', 'خدمات التوصيل', 'هنا، ستجد إجابات على الأسئلة الشائعة حول سياسات التوصيل لدينا، بما في ذلك خيارات الشحن، وأوقات التسليم المتوقعة، وتتبع الطلب. نحن نسعى جاهدين لتوفير تجربة توصيل سلسة ​وموثوقة، حيث نعمل مع شركاء موثوقين. إذا كنت بحاجة إلى مساعدة إضافية أو لديك أسئلة، فإن فريق دعم العملاء المخصص مستعد للمساعدة.', 'خدمات التوصيل | إجابات على الأسئلة الشائعة حول التوصيل', 'هنا، ستجد إجابات على الأسئلة الشائعة حول سياسات التوصيل لدينا، بما في ذلك خيارات الشحن، وأوقات التسليم المتوقعة، وتتبع الطلب.'),
(10, 5, 'en', 'delivery-services', 'Delivery Services', 'Here, you\'ll find answers to common questions about our delivery policies, including shipping options, estimated delivery times, and tracking. We strive to provide a smooth and reliable delivery experience, working with trusted partners. If you need further assistance or have questions, our dedicated customer support team is ready to help. Explore this section for all the information you need about our delivery policies.', 'Delivery Services | find answers to FAQs about our delivery', 'Here, you&amp;#039;ll find answers to common questions about our delivery policies, including shipping options, estimated delivery times, and tracking.'),
(11, 6, 'ar', 'خدمات-الشحن-للمحافظات', 'خدمات الشحن للمحافظات', 'اكتشف خدمات الشحن لتجار الجملة في محافظات مصر، اشترِى بالجملة، و انضم إلينا لإيجاد حلول تساعد تجارتك على النمو', 'خدمات الشحن للمحافظات | اكتشف خدمات الشحن لتجار الجملة', 'اكتشف خدمات الشحن لتجار الجملة في محافظات مصر، اشترِى بالجملة، و انضم إلينا لإيجاد حلول تساعد تجارتك على النمو'),
(12, 6, 'en', 'shipping-services-to-governorates', 'Shipping services to governorates', 'Explore our B2B services in Egypt, buy in bulk, and become a national vendor. Join together with us to find solutions to help you business increase its inventory.', 'Shipping services to governorates', 'Explore our B2B services in Egypt buy in bulk, and become a national vendor. Join together with us to find solutions to help you business increase its inventory'),
(13, 7, 'ar', 'سياسية-الاسترجاع', 'سياسية الاسترجاع', 'لضمان الراحة والأمن المالي، يرجى التعرف على سياسة الإرجاع والاسترداد الخاصة بنا لضمان حماية مالك عندما تختار التسوق معنا.', 'سياسية الاسترجاع | التعرف على سياسة الإرجاع والاسترداد', 'لضمان الراحة والأمن المالي، يرجى التعرف على سياسة الإرجاع والاسترداد الخاصة بنا لضمان حماية مالك عندما تختار التسوق معنا.'),
(14, 7, 'en', 'return-policy', 'Return Policy', 'For peace of mind and financial security, kindly familiarize yourself with our return and refund policy, ensuring that your money is protected when you choose to shop with us.', 'Return Policy | familiarize yourself with our return policy.', 'For peace of mind. kindly familiarize yourself with our return and refund policy, ensuring that your money is safe when you choose to shop with us.'),
(15, 8, 'ar', 'طلبات-التصنيع-الخاصة', 'طلبات التصنيع الخاصة', 'يمكن العثور على إجابات على الأسئلة حول طلبات المنتجات المخصصة هنا. يمكننا تحديد مواصفات منتجك وفقا لاحتياجاتك ونحن على استعداد لتنفيذ ذلك بكفاءة', 'طلبات التصنيع الخاص | إجابات حول طلبات المنتجات المخصصة', 'يمكن العثور على إجابات على الأسئلة حول طلبات المنتجات المخصصة هنا. يمكننا تحديد مواصفات منتجك وفقا لاحتياجاتك ونحن على استعداد لتنفيذ ذلك بكفاءة'),
(16, 8, 'en', 'special-requests', 'Special requests', 'Answers to questions about custom product requests can be found here. We can customize your product specifications according to your needs and are ready to execute it efficiently.', 'Special requests | Answers about custom product requests.', 'Answers about product requests can be found here. We can customize your product specifications according to your needs and are ready to execute it efficiently.'),
(17, 9, 'ar', 'خدمات-التصدير', 'خدمات التصدير', 'نحن هنا لمساعدتك في توصيل منتجاتنا إلى موقعك الدولي. يضمن فريقنا ذو الخبرة سهولة عملية التصدير، حيث يتولى التعامل مع الأوراق الجمركية والتغليف وشؤون الشحن.', 'خدمات التصدير | نحن هنا لمساعدتك في توصيل منتجاتنا خارج مصر', 'نحن هنا لمساعدتك في توصيل منتجاتنا إلى موقعك الدولي. يضمن فريقنا ذو الخبرة سهولة عملية التصدير، حيث يتولى التعامل مع الأوراق الجمركية والتغليف وشؤون الشحن.'),
(18, 9, 'en', 'export-services', 'Export services', 'We are here to assist you in delivering our products to your international location. Our experienced team ensures a smooth export process, handling customs documentation, packaging, and shipping logistics.', 'Export services | We are here to help ship our products.', 'We are here to assist you in delivering our products to your international location, handling customs documentation, packaging, and shipping logistics.'),
(19, 10, 'ar', 'مجموعة-فارغة', 'مجموعة فارغة', 'مجموعة فارغة', 'مجموعة فارغة', 'مجموعة فارغة'),
(20, 10, 'en', 'empty-category', 'Empty Category', 'Empty Category', 'Empty Category', 'Empty Category');

-- --------------------------------------------------------

--
-- Table structure for table `faq_translations`
--

CREATE TABLE `faq_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `faq_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_but` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faq_translations`
--

INSERT INTO `faq_translations` (`id`, `faq_id`, `locale`, `name`, `des`, `other`, `url`, `url_but`) VALUES
(9, 5, 'ar', 'السؤال 1', 'الاجابة 1', NULL, NULL, NULL),
(10, 5, 'en', 'Question 1', 'Answer 1', NULL, NULL, NULL),
(11, 6, 'ar', 'السؤال 2', 'الاجابة 2', NULL, NULL, NULL),
(12, 6, 'en', 'Question 2', 'Answer 2', NULL, NULL, NULL),
(13, 7, 'ar', 'السؤال 3', 'الاجابة 3', NULL, NULL, NULL),
(14, 7, 'en', 'Question 3', 'Answer 3', NULL, NULL, NULL),
(15, 8, 'ar', 'السؤال الاول المجموعة 2', 'الاجابة 1 المجموعة 2', NULL, NULL, NULL),
(16, 8, 'en', 'Question 1 for Category 1', 'Answer 1 for Category 1', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(616, '2014_10_12_000000_create_users_table', 1),
(617, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(618, '2014_10_12_100000_create_password_resets_table', 1),
(619, '2019_08_19_000000_create_failed_jobs_table', 1),
(620, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(621, '2023_06_24_105531_create_settings_table', 1),
(622, '2023_06_24_144232_create_setting_translations_table', 1),
(623, '2023_06_29_193744_create_def_photos_table', 1),
(624, '2023_06_29_235416_create_upload_filters_table', 1),
(625, '2023_07_03_115945_create_upload_filter_sizes_table', 1),
(626, '2023_07_12_171931_create_permission_tables', 1),
(627, '2023_07_14_112208_add_names_roles_table', 1),
(628, '2023_07_14_115125_add_names_permissions_table', 1),
(629, '2023_07_16_155230_create_categories_table', 1),
(630, '2023_07_16_155651_create_category_translations_table', 1),
(631, '2023_08_20_170942_create_attribute_tables_table', 1),
(632, '2023_08_20_170949_create_attribute_table_translations_table', 1),
(633, '2023_08_21_093710_create_category_tables_table', 1),
(634, '2023_08_21_093808_create_category_table_translations_table', 1),
(635, '2023_08_23_130011_create_products_table', 1),
(636, '2023_08_23_130057_create_product_translations_table', 1),
(637, '2023_08_23_172346_create_product_photos_table', 1),
(638, '2023_08_24_145512_create_web_privacies_table', 1),
(639, '2023_08_24_145811_create_web_privacy_translations_table', 1),
(640, '2023_08_24_181634_create_our_clients_table', 1),
(641, '2023_08_24_181658_create_our_client_translations_table', 1),
(642, '2023_08_26_094623_create_product_tables_table', 1),
(643, '2023_08_26_094653_create_product_table_translations_table', 1),
(644, '2023_08_26_130550_create_blog_posts_table', 1),
(645, '2023_08_26_130620_create_blog_post_translations_table', 1),
(646, '2023_08_26_150221_create_blog_post_photos_table', 1),
(647, '2023_08_26_171543_create_banner_categories_table', 1),
(648, '2023_08_26_171717_create_banner_category_translations_table', 1),
(649, '2023_08_26_173241_create_banners_table', 1),
(650, '2023_08_26_173311_create_banner_translations_table', 1),
(651, '2023_08_27_120554_create_faq_categories_table', 1),
(652, '2023_08_27_120612_create_faq_category_translations_table', 1),
(653, '2023_08_27_120635_create_faqs_table', 1),
(654, '2023_08_27_120656_create_faq_translations_table', 1),
(655, '2023_08_29_091745_create_pages_table', 1),
(656, '2023_08_29_091812_create_page_translations_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(2, 'App\\Models\\User', 3);

-- --------------------------------------------------------

--
-- Table structure for table `our_clients`
--

CREATE TABLE `our_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `our_clients`
--

INSERT INTO `our_clients` (`id`, `photo`, `photo_thum_1`, `is_active`, `postion`, `created_at`, `updated_at`) VALUES
(4, 'images/client/4/pharco-b-international.webp', 'images/client/4/pharco-b-international_1.webp', 1, 2, '2023-08-24 15:39:37', '2023-09-08 15:44:19'),
(5, 'images/client/5/nile-linen-group.webp', 'images/client/5/nile-linen-group_1.webp', 1, 3, '2023-08-24 15:39:37', '2023-09-08 15:44:19'),
(6, 'images/client/6/pharmaplast.webp', 'images/client/6/pharmaplast_1.webp', 1, 4, '2023-08-24 15:39:37', '2023-09-08 15:44:17'),
(7, 'images/client/7/alexandria-company-for-pharmaceuticals-industries.webp', 'images/client/7/alexandria-company-for-pharmaceuticals-industries_1.webp', 1, 5, '2023-08-24 15:39:37', '2023-09-08 15:44:17'),
(8, 'images/client/8/pharo-pharma-for-pharmaceuticals.webp', 'images/client/8/pharo-pharma-for-pharmaceuticals_1.webp', 1, 6, '2023-08-24 15:39:37', '2023-09-08 15:44:17'),
(9, 'images/client/9/abo-el-hol-company-for-oils-and-detergents.webp', 'images/client/9/abo-el-hol-company-for-oils-and-detergents_1.webp', 1, 7, '2023-08-24 15:39:37', '2023-09-08 15:44:17'),
(10, 'images/client/10/senyorita-food-industries.webp', 'images/client/10/senyorita-food-industries_1.webp', 1, 8, '2023-08-24 15:39:38', '2023-09-08 15:44:17'),
(11, 'images/client/11/sun-nile-co-family-market.webp', 'images/client/11/sun-nile-co-family-market_1.webp', 1, 9, '2023-08-24 15:39:38', '2023-09-08 15:44:17'),
(12, 'images/client/12/alexandria-company-for-consumer-complexes.webp', 'images/client/12/alexandria-company-for-consumer-complexes_1.webp', 1, 10, '2023-08-24 15:39:38', '2023-09-08 15:44:17'),
(13, 'images/client/13/egyptian-airports-company.webp', 'images/client/13/egyptian-airports-company_1.webp', 1, 1, '2023-08-24 15:39:38', '2023-09-08 15:44:19');

-- --------------------------------------------------------

--
-- Table structure for table `our_client_translations`
--

CREATE TABLE `our_client_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `our_client_translations`
--

INSERT INTO `our_client_translations` (`id`, `client_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 4, 'ar', NULL, ' فاركو ب العالمية ', NULL, NULL, NULL),
(2, 4, 'en', NULL, 'Pharco B International', NULL, NULL, NULL),
(3, 5, 'ar', NULL, 'مجموعة نايل لينين', NULL, NULL, NULL),
(4, 5, 'en', NULL, 'Nile Linen Group', NULL, NULL, NULL),
(5, 6, 'ar', NULL, 'شركة فارما المنتجات الطبية', NULL, NULL, NULL),
(6, 6, 'en', NULL, 'Pharmaplast', NULL, NULL, NULL),
(7, 7, 'ar', NULL, 'الاسكندرية للادوية والصناعات الكيماوية', NULL, NULL, NULL),
(8, 7, 'en', NULL, 'Alexandria company for pharmaceuticals industries', NULL, NULL, NULL),
(9, 8, 'ar', NULL, 'الفرعونية للادوية فاروفارما', NULL, NULL, NULL),
(10, 8, 'en', NULL, 'Pharo Pharma For Pharmaceuticals', NULL, NULL, NULL),
(11, 9, 'ar', NULL, 'أبو الهول المصرية للزيوت والمنظفات ', NULL, NULL, NULL),
(12, 9, 'en', NULL, 'Abo El Hol Company For oils and detergents', NULL, NULL, NULL),
(13, 10, 'ar', NULL, 'سنيوريتا للصناعات الغذائية', NULL, NULL, NULL),
(14, 10, 'en', NULL, 'Senyorita Food Industries ', NULL, NULL, NULL),
(15, 11, 'ar', NULL, 'شركة النيل للمجمعات الاستهلاكية', NULL, NULL, NULL),
(16, 11, 'en', NULL, 'Sun Nile Co.(Family Market)', NULL, NULL, NULL),
(17, 12, 'ar', NULL, 'شركة الإسكندرية للمجمعات الإستهلاكية', NULL, NULL, NULL),
(18, 12, 'en', NULL, 'Alexandria Company for consumer complexes', NULL, NULL, NULL),
(19, 13, 'ar', NULL, 'المصرية للمطارات', NULL, NULL, NULL),
(20, 13, 'en', NULL, 'Egyptian Airports Company', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner_id` int(11) DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `menu_main` tinyint(1) NOT NULL DEFAULT 0,
  `menu_footer` tinyint(1) NOT NULL DEFAULT 0,
  `postion` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `cat_id`, `view_name`, `banner_id`, `photo`, `photo_thum_1`, `is_active`, `menu_main`, `menu_footer`, `postion`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'HomePage', NULL, 4, NULL, NULL, 1, 1, 1, 1, NULL, '2023-08-29 06:41:34', '2023-09-11 09:39:37'),
(2, 'OurClient', NULL, NULL, NULL, NULL, 1, 1, 1, 3, NULL, '2023-08-29 06:41:34', '2023-09-08 12:56:32'),
(3, 'LatestNews', NULL, NULL, NULL, NULL, 1, 1, 1, 4, NULL, '2023-08-29 06:41:34', '2023-09-03 09:21:59'),
(4, 'ErrorPage', NULL, NULL, NULL, NULL, 1, 0, 0, 8, NULL, '2023-08-29 06:41:34', '2023-09-03 07:25:20'),
(5, 'FaqList', NULL, NULL, NULL, NULL, 1, 1, 1, 5, NULL, '2023-08-29 06:41:34', '2023-09-03 07:44:55'),
(6, 'TermsConditions', NULL, NULL, NULL, NULL, 1, 0, 1, 6, NULL, '2023-08-29 06:41:34', '2023-09-03 07:45:03'),
(7, 'ContactUs', NULL, NULL, NULL, NULL, 1, 1, 1, 7, NULL, '2023-08-29 06:41:34', '2023-09-03 07:45:14'),
(8, 'AboutUs', NULL, NULL, NULL, NULL, 1, 1, 1, 2, NULL, '2023-08-29 06:41:34', '2023-09-03 07:44:30'),
(9, 'MainCategory', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-08 13:19:30', '2023-09-08 13:19:51'),
(10, 'Shop_HomePage', NULL, 1, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-11 12:37:49', '2023-09-11 12:37:49'),
(11, 'Shop_BestDeals', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-11 21:09:15', '2023-09-11 21:09:15');

-- --------------------------------------------------------

--
-- Table structure for table `page_translations`
--

CREATE TABLE `page_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `breadcrumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_translations`
--

INSERT INTO `page_translations` (`id`, `page_id`, `locale`, `slug`, `name`, `g_title`, `g_des`, `body_h1`, `breadcrumb`) VALUES
(1, 1, 'ar', 'home', 'الصفحة الرئيسية', 'عتمان جروب فخر الصناعة المصرية | خدمة العملاء 01006180117', 'عتمان جروب فخر الصناعة المصرية متخصصون فى تصنيع الاشرطة ذاتية اللصق وشرائط الزينة و جميع مستلزمات التعبئة والتغليف بمصر الاسكندرية خدمة العملاء 01006180117', 'عتمان جروب', 'عتمان جروب'),
(2, 1, 'en', 'home', 'Home Page', 'Etman Group is the pride of the Egyptian industry Hotline 01006180117', 'Etman Group,the pride of the Egyptian industry, specialized in the manufacture of self-adhesive tapes, PP Ribbon and all packaging Products Hotline 01006180117', 'Etman Group', 'Etman Group'),
(3, 2, 'ar', 'عملائنا', 'عملائنا', 'عتمان جروب | قائمة بعملائنا', 'بعد اكثر من 40 عام من العمل فى السوق المصرى نتشرف بخدمة عملائنا التى تشرفنا بخدمتهم على مدار السنوات السابقة', 'عملائنا', 'عملائنا'),
(4, 2, 'en', 'our-client', 'Our Client', 'Etman Group | Our Client', 'After more than 40 years of working in the Egyptian market, we are honored to serve our customers, which we were honored to serve over the past years', 'Our Client', 'Our Client'),
(5, 3, 'ar', 'أخر-الأخبار', 'أخر الأخبار', 'عتمان جروب | أخر الاخبار | احدث العروض | الوظائف المتاحة', 'تابع اخر اخبار شركة عتمان جروب وكن دائما على علم باحداث العروض والخصومات التى نقدمه دائما والوظائف المتوفرة حاليا', 'أخر الأخبار', 'أخر الأخبار'),
(6, 3, 'en', 'latest-news', 'Latest news', 'Etman Group | Latest news | Latest Offers | Available jobs', 'Follow latest news of the Etman Group and always be aware of the latest offers and discounts that we always offer and the jobs that are currently available', 'Latest news', 'Latest news'),
(7, 4, 'ar', 'page-not-found', '404', 'عذرا !! الصفحة غير موجودة', 'عذرا !! الصفحة غير موجودة', NULL, NULL),
(8, 4, 'en', 'page-not-found', '404', 'Sorry !! Page not found', 'Sorry !! Page not found', NULL, NULL),
(9, 5, 'ar', 'الأسئلة-المتكررة', 'الأسئلة المتكررة', 'الأسئلة المتكررة | عتمان جروب | الاسكندرية 01006180117', 'تساعدك الأسئلة المتكررة على الرد لجميع الاستفسارت الخاصة بالمنتجات والعروض وطرق الشحن وطرق الدفع المتاحة لدى عتمان جروب', 'الأسئلة المتكررة', 'الأسئلة المتكررة'),
(10, 5, 'en', 'frequently-asked-questions', 'FAQ', 'Frequently Asked Questions | Etman Group | 01006180117', 'Frequently asked questions help you answer all inquiries about products, offers, shipping methods and payment methods available at Etman Group', 'Frequently Asked Questions', 'Frequently Asked Questions'),
(11, 6, 'ar', 'سياسية-الاستخدام', 'سياسية الاستخدم', 'عتمان جروب | شروط وسياسة الخصوصية', 'شروط وسياسة الخصوصية تعرفك هذه الصفحة بسياساتنا المتعلقة بجمع البيانات الشخصية واستخدامها والكشف عنها عند استخدامك للخدمة والأختيارات المرتبطة بهذه البيانات.', 'سياسية الاستخدم', NULL),
(12, 6, 'en', 'terms-conditions', 'Privacy Policy', 'Etman Group | Our Privacy Policy', 'Terms and Privacy Policy This page informs you of our policies regarding the collection, use and disclosure of personal data when you use the Service', 'Terms & Conditions', NULL),
(13, 7, 'ar', 'اتصل-بنا', 'اتصل بنا', 'عتمان جروب | اتصل بنا | الاسكندرية 01006180117', 'عتمان جروب المقر الرئيسي 14 ش خليل بك متفرع من اسماعيل صبري - أمام بنك مصر - الجمرك الاسكندرية - مصر / هاتف 01006180117', 'اتصل بنا', NULL),
(14, 7, 'en', 'contact-us', 'Contact Us', 'Etman Group | Contact Us | Alexandria 0100-6180-117', 'Etman Group Headquarters 14 Khalil Bey St., off Ismail Sabry - in front of Banque Misr - Customs, Alexandria - Egypt  Phone : 01006180117', 'Contact Us', NULL),
(15, 8, 'ar', 'من-نحن', 'من نحن', 'عتمان جروب هي شركة محلية منذ عام 1967 | الاسكندرية 01006180117', 'عتمان جروب هي شركة محلية أسسها السيد حسن عتمان منذ عام 1967. بدأت رحلة السيد عتمان نحو النجاح بفضل تطور شركته من خلال إنتاج شرائط البولي بروبلين وشرائط الزينة', 'من نحن', 'من نحن'),
(16, 8, 'en', 'about-us', 'About Us', 'Etman Group is a local company since 1967 | Alexandria 01006180117', 'Etman Group is a local company founded and operated by Mr Hassan Etman in 1967. Mr Etman’s journey to success started due to the development of his company by', 'About Us', 'About Us'),
(17, 9, 'ar', 'قائمة-المنتجات', 'قائمة المنتجات', 'قائمة المنتجات', 'قائمة المنتجات', 'قائمة المنتجات', 'قائمة المنتجات'),
(18, 9, 'en', 'category-list', 'Category List', 'Category List', 'Category List', 'Category List', 'Category List'),
(19, 10, 'ar', 'تسوق-الان-مع-عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان'),
(20, 10, 'en', 'shop-now', 'Shop Now', 'Shop Now', 'Shop Now', 'Shop Now', 'Shop Now'),
(21, 11, 'ar', 'عروض-تجار-الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة'),
(22, 11, 'en', 'عروض-تجار-الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `cat_id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'users_view', 'عرض', 'View', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(2, 1, 'users_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(3, 1, 'users_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(4, 1, 'users_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(5, 2, 'roles_view', 'عرض', 'View', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(6, 2, 'roles_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(7, 2, 'roles_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(8, 2, 'roles_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(9, 2, 'roles_update_permissions', 'تعديل صلاحيات المجموعة', 'Roles Update Permissions', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(10, 3, 'permissions_view', 'عرض', 'View', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(11, 3, 'permissions_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(12, 3, 'permissions_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(13, 3, 'permissions_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:15', '2023-09-07 15:41:15'),
(14, 4, 'webPrivacy_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(15, 4, 'webPrivacy_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(16, 4, 'webPrivacy_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(17, 4, 'webPrivacy_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(18, 5, 'adminlang_view', 'عرض ملفات لغة التحكم', 'View Admin Lang', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(19, 5, 'adminlang_edit', 'تعديل ملفات لغة التحكم', 'Edit Admin Lang', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(20, 5, 'weblang_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(21, 5, 'weblang_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(22, 6, 'config_section', 'عرض الاعدادات', 'Setting View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(23, 6, 'website_config', 'اعدادات الموقع', 'Web Site Setting', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(24, 7, 'defPhoto_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(25, 7, 'defPhoto_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(26, 7, 'defPhoto_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(27, 7, 'defPhoto_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(28, 8, 'upFilter_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(29, 8, 'upFilter_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(30, 8, 'upFilter_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(31, 8, 'upFilter_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(32, 9, 'Pages_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(33, 9, 'Pages_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(34, 9, 'Pages_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(35, 9, 'Pages_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(36, 9, 'Pages_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(37, 10, 'category_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(38, 10, 'category_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(39, 10, 'category_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(40, 10, 'category_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(41, 10, 'category_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(42, 11, 'product_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(43, 11, 'product_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(44, 11, 'product_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(45, 11, 'product_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(46, 12, 'OurClient_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(47, 12, 'OurClient_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(48, 12, 'OurClient_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(49, 12, 'OurClient_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(50, 13, 'BlogPost_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(51, 13, 'BlogPost_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(52, 13, 'BlogPost_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(53, 13, 'BlogPost_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(54, 13, 'BlogPost_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(55, 14, 'Banner_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(56, 14, 'Banner_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(57, 14, 'Banner_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(58, 14, 'Banner_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(59, 14, 'Banner_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(60, 15, 'Faq_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(61, 15, 'Faq_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(62, 15, 'Faq_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(63, 15, 'Faq_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(64, 15, 'Faq_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(65, 16, 'meta_view', 'عرض', 'View', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(66, 16, 'meta_add', 'اضافة', 'Add', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(67, 16, 'meta_edit', 'تعديل', 'Edit', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(68, 16, 'meta_delete', 'حذف', 'Delete', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(69, 16, 'meta_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `photo`, `photo_thum_1`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 3, 'images/product/1/packaging-tape-nar-tape.webp', 'images/product/1/packaging-tape-nar-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(2, 3, 'images/product/2/packaging-tape-the-best-tape.webp', 'images/product/2/packaging-tape-the-best-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(3, 3, 'images/product/3/packaging-tape-crystal-tape.webp', 'images/product/3/packaging-tape-crystal-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(4, 3, 'images/product/4/packaging-tape-green-tape.webp', 'images/product/4/packaging-tape-green-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(7, 6, 'images/product/7/stationary-tape-the-best.webp', 'images/product/7/stationary-tape-the-best_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(9, 7, 'images/product/9/self-adhesive-tape-green-masking-tape.webp', 'images/product/9/self-adhesive-tape-green-masking-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(10, 7, 'images/product/10/self-adhesive-tape-et-masking-tape.webp', 'images/product/10/self-adhesive-tape-et-masking-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(12, 14, 'images/product/12/printed-self-adhesive-tape-fresh.webp', 'images/product/12/printed-self-adhesive-tape-fresh_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(13, 14, 'images/product/13/fragile-printed-tape.webp', 'images/product/13/fragile-printed-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(14, 10, 'images/product/14/self-adhesive-tape-electrical-insulating-tape.webp', 'images/product/14/self-adhesive-tape-electrical-insulating-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:07'),
(15, 17, 'images/product/15/aluminium-foil-mr-foil-50gm.webp', 'images/product/15/aluminium-foil-mr-foil-50gm_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:08'),
(16, 24, 'images/product/16/gift-accessories-05-cm-pp-ribbon.webp', 'images/product/16/gift-accessories-05-cm-pp-ribbon_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:08'),
(17, 24, 'images/product/17/gift-accessories-5-cm-pp-ribbon.webp', 'images/product/17/gift-accessories-5-cm-pp-ribbon_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:08'),
(18, 24, 'images/product/18/gift-accessories-metallic-pp-ribbon.webp', 'images/product/18/gift-accessories-metallic-pp-ribbon_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:08'),
(19, 25, 'images/product/19/gift-accessories-metallic-paper.webp', 'images/product/19/gift-accessories-metallic-paper_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:08'),
(21, 26, 'images/product/21/crepe-paper-normal-color.webp', 'images/product/21/crepe-paper-normal-color_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:09'),
(22, 26, 'images/product/22/crepe-paper-metallic-color.webp', 'images/product/22/crepe-paper-metallic-color_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:09'),
(37, 3, 'images/product/37/packaging-tape-apple-tape.webp', 'images/product/37/packaging-tape-apple-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:09'),
(38, 3, 'images/product/38/packaging-tape-fire-tape.webp', 'images/product/38/packaging-tape-fire-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:09'),
(40, 13, 'images/product/40/self-adhesive-color-tape-hot.webp', 'images/product/40/self-adhesive-color-tape-hot_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:09'),
(41, 36, 'images/product/41/self-adhesive-tape-green-laser-tape.webp', 'images/product/41/self-adhesive-tape-green-laser-tape_1.webp', 1, '2023-08-23 10:35:05', '2023-08-23 12:07:09'),
(42, 6, 'images/product/42/stationary-tape-piton-tape.webp', 'images/product/42/stationary-tape-piton-tape_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:09'),
(43, 6, 'images/product/43/stationary-tape-color-tape.webp', 'images/product/43/stationary-tape-color-tape_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:09'),
(44, 6, 'images/product/44/stationary-tape-laser-tape.webp', 'images/product/44/stationary-tape-laser-tape_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:10'),
(45, 19, 'images/product/45/cling-warp-highmax-wrap.webp', 'images/product/45/cling-warp-highmax-wrap_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:10'),
(46, 19, 'images/product/46/cling-warp-komex.webp', 'images/product/46/cling-warp-komex_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:10'),
(48, 19, 'images/product/48/cling-warp-star-maximum.webp', 'images/product/48/cling-warp-star-maximum_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:10'),
(49, 19, 'images/product/49/cling-warp-highmax-wrap-2.webp', 'images/product/49/cling-warp-highmax-wrap-2_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:10'),
(50, 16, 'images/product/50/mr-foil-hookah-aluminum-foil.webp', 'images/product/50/mr-foil-hookah-aluminum-foil_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:10'),
(51, 16, 'images/product/51/mr-foil-oven-2.webp', 'images/product/51/mr-foil-oven-2_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:11'),
(52, 16, 'images/product/52/mr-foil-oven.webp', 'images/product/52/mr-foil-oven_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:11'),
(53, 17, 'images/product/53/aluminium-foil-king.webp', 'images/product/53/aluminium-foil-king_1.webp', 1, '2023-08-23 10:35:06', '2023-08-23 12:07:11'),
(55, 37, '', '', 1, '2023-08-23 10:35:06', '2023-08-23 10:35:06'),
(56, 39, 'images/product/56/مسدس-شمع-بسلك-كهرباء-من-يوني-تي-موديل-eh430-27KFKArcIK.webp', 'images/product/56/مسدس-شمع-بسلك-كهرباء-من-يوني-تي-موديل-eh430-2PI1TFWSZe.webp', 1, '2023-09-11 17:04:54', '2023-09-11 17:09:56'),
(57, 39, 'images/product/57/مسدس-شمع-st-03-20w-حجم-صغير-ازرق-RIJhHKr9RU.webp', 'images/product/57/مسدس-شمع-st-03-20w-حجم-صغير-ازرق-0BiTOSAKTw.webp', 1, '2023-09-11 17:11:43', '2023-09-11 17:11:44'),
(58, 39, 'images/product/58/مسدس-شمع-برو-جلو-من-ستانلي-gr100-1RhDP71AO3.webp', 'images/product/58/مسدس-شمع-برو-جلو-من-ستانلي-gr100-WGykuxK7pV.webp', 1, '2023-09-11 17:13:31', '2023-09-11 17:13:31'),
(59, 39, 'images/product/59/مسدس-شمع-من-عتمان-جروب-متعدد-الألوان-tRbKwi2gQE.webp', 'images/product/59/مسدس-شمع-من-عتمان-جروب-متعدد-الألوان-ttXSIKzJjo.webp', 1, '2023-09-11 17:14:46', '2023-09-11 17:14:47'),
(60, 39, 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-PrHOfI9xQ1.webp', 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-PHcLFwh2p0.webp', 1, '2023-09-11 17:18:06', '2023-09-11 18:55:43');

-- --------------------------------------------------------

--
-- Table structure for table `product_photos`
--

CREATE TABLE `product_photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `file_h` int(11) DEFAULT NULL,
  `file_w` int(11) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `is_default` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_photos`
--

INSERT INTO `product_photos` (`id`, `product_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `file_extension`, `file_size`, `file_h`, `file_w`, `position`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 1, 'images/product/1/packaging-tape-nar-tape_2.webp', 'images/product/1/packaging-tape-nar-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:15'),
(2, 1, 'images/product/1/packaging-tape-nar-tape_4.webp', 'images/product/1/packaging-tape-nar-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:15'),
(3, 1, 'images/product/1/packaging-tape-nar-tape_6.webp', 'images/product/1/packaging-tape-nar-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:15'),
(4, 2, 'images/product/2/packaging-tape-the-best-tape_2.webp', 'images/product/2/packaging-tape-the-best-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:16'),
(5, 2, 'images/product/2/packaging-tape-the-best-tape_4.webp', 'images/product/2/packaging-tape-the-best-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:16'),
(6, 2, 'images/product/2/packaging-tape-the-best-tape_6.webp', 'images/product/2/packaging-tape-the-best-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:17'),
(7, 3, 'images/product/3/packaging-tape-crystal-tape_2.webp', 'images/product/3/packaging-tape-crystal-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:17'),
(8, 3, 'images/product/3/packaging-tape-crystal-tape_4.webp', 'images/product/3/packaging-tape-crystal-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:18'),
(9, 3, 'images/product/3/packaging-tape-crystal-tape_6.webp', 'images/product/3/packaging-tape-crystal-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:18'),
(10, 4, 'images/product/4/packaging-tape-green-tape_2.webp', 'images/product/4/packaging-tape-green-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:18'),
(11, 4, 'images/product/4/packaging-tape-green-tape_4.webp', 'images/product/4/packaging-tape-green-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:19'),
(12, 4, 'images/product/4/packaging-tape-green-tape_6.webp', 'images/product/4/packaging-tape-green-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:19'),
(13, 37, 'images/product/37/packaging-tape-apple-tape_2.webp', 'images/product/37/packaging-tape-apple-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:20'),
(14, 37, 'images/product/37/packaging-tape-apple-tape_4.webp', 'images/product/37/packaging-tape-apple-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:20'),
(15, 37, 'images/product/37/packaging-tape-apple-tape_6.webp', 'images/product/37/packaging-tape-apple-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:20'),
(16, 38, 'images/product/38/packaging-tape-fire-tape_2.webp', 'images/product/38/packaging-tape-fire-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:21'),
(17, 38, 'images/product/38/packaging-tape-fire-tape_4.webp', 'images/product/38/packaging-tape-fire-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:21'),
(18, 38, 'images/product/38/packaging-tape-fire-tape_6.webp', 'images/product/38/packaging-tape-fire-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:22'),
(22, 40, 'images/product/40/self-adhesive-color-tape-hot_2.webp', 'images/product/40/self-adhesive-color-tape-hot_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:22'),
(23, 40, 'images/product/40/self-adhesive-color-tape-hot_4.webp', 'images/product/40/self-adhesive-color-tape-hot_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:22'),
(24, 40, 'images/product/40/self-adhesive-color-tape-hot_6.webp', 'images/product/40/self-adhesive-color-tape-hot_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:23'),
(25, 12, 'images/product/12/printed-self-adhesive-tape-fresh_2.webp', 'images/product/12/printed-self-adhesive-tape-fresh_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:23'),
(26, 12, 'images/product/12/printed-self-adhesive-tape-fresh_4.webp', 'images/product/12/printed-self-adhesive-tape-fresh_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:24'),
(27, 13, 'images/product/13/fragile-printed-tape_2.webp', 'images/product/13/fragile-printed-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:24'),
(28, 13, 'images/product/13/fragile-printed-tape_4.webp', 'images/product/13/fragile-printed-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:24'),
(29, 13, 'images/product/13/fragile-printed-tape_6.webp', 'images/product/13/fragile-printed-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:25'),
(30, 13, 'images/product/13/fragile-printed-tape_8.webp', 'images/product/13/fragile-printed-tape_9.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:26'),
(31, 41, 'images/product/41/self-adhesive-tape-green-laser-tape_2.webp', 'images/product/41/self-adhesive-tape-green-laser-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:26'),
(32, 41, 'images/product/41/self-adhesive-tape-green-laser-tape_4.webp', 'images/product/41/self-adhesive-tape-green-laser-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:26'),
(33, 41, 'images/product/41/self-adhesive-tape-green-laser-tape_6.webp', 'images/product/41/self-adhesive-tape-green-laser-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:27'),
(34, 9, 'images/product/9/self-adhesive-tape-green-masking-tape_2.webp', 'images/product/9/self-adhesive-tape-green-masking-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:27'),
(35, 9, 'images/product/9/self-adhesive-tape-green-masking-tape_4.webp', 'images/product/9/self-adhesive-tape-green-masking-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:28'),
(36, 9, 'images/product/9/self-adhesive-tape-green-masking-tape_6.webp', 'images/product/9/self-adhesive-tape-green-masking-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:28'),
(37, 10, 'images/product/10/self-adhesive-tape-et-masking-tape_2.webp', 'images/product/10/self-adhesive-tape-et-masking-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:29'),
(38, 10, 'images/product/10/self-adhesive-tape-et-masking-tape_4.webp', 'images/product/10/self-adhesive-tape-et-masking-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:29'),
(39, 10, 'images/product/10/self-adhesive-tape-et-masking-tape_6.webp', 'images/product/10/self-adhesive-tape-et-masking-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:30'),
(40, 14, 'images/product/14/self-adhesive-tape-electrical-insulating-tape_2.webp', 'images/product/14/self-adhesive-tape-electrical-insulating-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:30'),
(41, 14, 'images/product/14/self-adhesive-tape-electrical-insulating-tape_4.webp', 'images/product/14/self-adhesive-tape-electrical-insulating-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:31'),
(42, 14, 'images/product/14/self-adhesive-tape-electrical-insulating-tape_6.webp', 'images/product/14/self-adhesive-tape-electrical-insulating-tape_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:31'),
(47, 7, 'images/product/7/stationary-tape-the-best_2.webp', 'images/product/7/stationary-tape-the-best_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:31'),
(48, 7, 'images/product/7/stationary-tape-the-best_4.webp', 'images/product/7/stationary-tape-the-best_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:32'),
(49, 42, 'images/product/42/stationary-tape-piton-tape_2.webp', 'images/product/42/stationary-tape-piton-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:11', '2023-08-23 16:47:32'),
(50, 42, 'images/product/42/stationary-tape-piton-tape_4.webp', 'images/product/42/stationary-tape-piton-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:33'),
(51, 43, 'images/product/43/stationary-tape-color-tape_2.webp', 'images/product/43/stationary-tape-color-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:33'),
(52, 43, 'images/product/43/stationary-tape-color-tape_4.webp', 'images/product/43/stationary-tape-color-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:33'),
(53, 44, 'images/product/44/stationary-tape-laser-tape_2.webp', 'images/product/44/stationary-tape-laser-tape_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:34'),
(54, 44, 'images/product/44/stationary-tape-laser-tape_4.webp', 'images/product/44/stationary-tape-laser-tape_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:34'),
(55, 45, 'images/product/45/cling-warp-highmax-wrap_2.webp', 'images/product/45/cling-warp-highmax-wrap_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:35'),
(56, 45, 'images/product/45/cling-warp-highmax-wrap_4.webp', 'images/product/45/cling-warp-highmax-wrap_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:35'),
(57, 45, 'images/product/45/cling-warp-highmax-wrap_6.webp', 'images/product/45/cling-warp-highmax-wrap_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:35'),
(58, 45, 'images/product/45/cling-warp-highmax-wrap_8.webp', 'images/product/45/cling-warp-highmax-wrap_9.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:36'),
(59, 45, 'images/product/45/cling-warp-highmax-wrap_10.webp', 'images/product/45/cling-warp-highmax-wrap_11.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:36'),
(60, 45, 'images/product/45/cling-warp-highmax-wrap_12.webp', 'images/product/45/cling-warp-highmax-wrap_13.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:37'),
(61, 45, 'images/product/45/cling-warp-highmax-wrap_14.webp', 'images/product/45/cling-warp-highmax-wrap_15.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:37'),
(62, 46, 'images/product/46/cling-warp-komex_2.webp', 'images/product/46/cling-warp-komex_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:38'),
(63, 46, 'images/product/46/cling-warp-komex_4.webp', 'images/product/46/cling-warp-komex_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:38'),
(64, 46, 'images/product/46/cling-warp-komex_6.webp', 'images/product/46/cling-warp-komex_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:38'),
(68, 48, 'images/product/48/cling-warp-star-maximum_2.webp', 'images/product/48/cling-warp-star-maximum_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:39'),
(69, 48, 'images/product/48/cling-warp-star-maximum_4.webp', 'images/product/48/cling-warp-star-maximum_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:39'),
(70, 49, 'images/product/49/cling-warp-highmax-wrap-2_2.webp', 'images/product/49/cling-warp-highmax-wrap-2_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:40'),
(71, 49, 'images/product/49/cling-warp-highmax-wrap-2_4.webp', 'images/product/49/cling-warp-highmax-wrap-2_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:40'),
(72, 49, 'images/product/49/cling-warp-highmax-wrap-2_6.webp', 'images/product/49/cling-warp-highmax-wrap-2_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:40'),
(73, 50, 'images/product/50/mr-foil-hookah-aluminum-foil_2.webp', 'images/product/50/mr-foil-hookah-aluminum-foil_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:41'),
(74, 50, 'images/product/50/mr-foil-hookah-aluminum-foil_4.webp', 'images/product/50/mr-foil-hookah-aluminum-foil_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:41'),
(75, 51, 'images/product/51/mr-foil-oven-2_2.webp', 'images/product/51/mr-foil-oven-2_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:42'),
(76, 51, 'images/product/51/mr-foil-oven-2_4.webp', 'images/product/51/mr-foil-oven-2_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:42'),
(77, 51, 'images/product/51/mr-foil-oven-2_6.webp', 'images/product/51/mr-foil-oven-2_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:43'),
(78, 52, 'images/product/52/mr-foil-oven_2.webp', 'images/product/52/mr-foil-oven_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:43'),
(79, 52, 'images/product/52/mr-foil-oven_4.webp', 'images/product/52/mr-foil-oven_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:43'),
(80, 52, 'images/product/52/mr-foil-oven_6.webp', 'images/product/52/mr-foil-oven_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:44'),
(81, 52, 'images/product/52/mr-foil-oven_8.webp', 'images/product/52/mr-foil-oven_9.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:44'),
(82, 52, 'images/product/52/mr-foil-oven_10.webp', 'images/product/52/mr-foil-oven_11.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:44'),
(83, 15, 'images/product/15/aluminium-foil-mr-foil-50gm_2.webp', 'images/product/15/aluminium-foil-mr-foil-50gm_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:45'),
(84, 15, 'images/product/15/aluminium-foil-mr-foil-50gm_4.webp', 'images/product/15/aluminium-foil-mr-foil-50gm_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:45'),
(85, 15, 'images/product/15/aluminium-foil-mr-foil-50gm_6.webp', 'images/product/15/aluminium-foil-mr-foil-50gm_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:46'),
(86, 15, 'images/product/15/aluminium-foil-mr-foil-50gm_8.webp', 'images/product/15/aluminium-foil-mr-foil-50gm_9.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:46'),
(87, 15, 'images/product/15/aluminium-foil-mr-foil-50gm_10.webp', 'images/product/15/aluminium-foil-mr-foil-50gm_11.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:46'),
(88, 15, 'images/product/15/aluminium-foil-mr-foil-50gm_12.webp', 'images/product/15/aluminium-foil-mr-foil-50gm_13.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:47'),
(89, 53, 'images/product/53/aluminium-foil-king_2.webp', 'images/product/53/aluminium-foil-king_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:48'),
(90, 53, 'images/product/53/aluminium-foil-king_4.webp', 'images/product/53/aluminium-foil-king_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:48'),
(91, 53, 'images/product/53/aluminium-foil-king_6.webp', 'images/product/53/aluminium-foil-king_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:49'),
(92, 21, 'images/product/21/crepe-paper-normal-color_2.webp', 'images/product/21/crepe-paper-normal-color_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:49'),
(93, 21, 'images/product/21/crepe-paper-normal-color_4.webp', 'images/product/21/crepe-paper-normal-color_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:50'),
(94, 21, 'images/product/21/crepe-paper-normal-color_6.webp', 'images/product/21/crepe-paper-normal-color_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:50'),
(95, 21, 'images/product/21/crepe-paper-normal-color_8.webp', 'images/product/21/crepe-paper-normal-color_9.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:51'),
(96, 21, 'images/product/21/crepe-paper-normal-color_10.webp', 'images/product/21/crepe-paper-normal-color_11.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:51'),
(97, 21, 'images/product/21/crepe-paper-normal-color_12.webp', 'images/product/21/crepe-paper-normal-color_13.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:51'),
(98, 21, 'images/product/21/crepe-paper-normal-color_14.webp', 'images/product/21/crepe-paper-normal-color_15.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:52'),
(99, 16, 'images/product/16/gift-accessories-05-cm-pp-ribbon_2.webp', 'images/product/16/gift-accessories-05-cm-pp-ribbon_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:52'),
(100, 16, 'images/product/16/gift-accessories-05-cm-pp-ribbon_4.webp', 'images/product/16/gift-accessories-05-cm-pp-ribbon_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:53'),
(101, 16, 'images/product/16/gift-accessories-05-cm-pp-ribbon_6.webp', 'images/product/16/gift-accessories-05-cm-pp-ribbon_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:53'),
(102, 17, 'images/product/17/gift-accessories-5-cm-pp-ribbon_2.webp', 'images/product/17/gift-accessories-5-cm-pp-ribbon_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:53'),
(103, 17, 'images/product/17/gift-accessories-5-cm-pp-ribbon_4.webp', 'images/product/17/gift-accessories-5-cm-pp-ribbon_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:54'),
(104, 17, 'images/product/17/gift-accessories-5-cm-pp-ribbon_6.webp', 'images/product/17/gift-accessories-5-cm-pp-ribbon_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:54'),
(105, 18, 'images/product/18/gift-accessories-metallic-pp-ribbon_2.webp', 'images/product/18/gift-accessories-metallic-pp-ribbon_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:55'),
(106, 18, 'images/product/18/gift-accessories-metallic-pp-ribbon_4.webp', 'images/product/18/gift-accessories-metallic-pp-ribbon_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:55'),
(107, 18, 'images/product/18/gift-accessories-metallic-pp-ribbon_6.webp', 'images/product/18/gift-accessories-metallic-pp-ribbon_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:55'),
(108, 19, 'images/product/19/gift-accessories-metallic-paper_2.webp', 'images/product/19/gift-accessories-metallic-paper_3.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:56'),
(109, 19, 'images/product/19/gift-accessories-metallic-paper_4.webp', 'images/product/19/gift-accessories-metallic-paper_5.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:56'),
(110, 19, 'images/product/19/gift-accessories-metallic-paper_6.webp', 'images/product/19/gift-accessories-metallic-paper_7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-08-23 15:48:12', '2023-08-23 16:47:57'),
(111, 60, 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-Ug0rtMuM0K.webp', 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-oWfEZ7pSHs.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-09-11 18:39:32', '2023-09-11 18:39:32'),
(112, 60, 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-ebXBwXIB80.webp', 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-cLdWjkMrUi.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-09-11 18:39:32', '2023-09-11 18:39:32'),
(113, 60, 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-W0gbOwdt50.webp', 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-ZUSacY0tn7.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-09-11 18:39:32', '2023-09-11 18:39:32'),
(114, 60, 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-vqscq3MCxq.webp', 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-GfZfc2duJg.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-09-11 18:39:32', '2023-09-11 18:39:32'),
(115, 60, 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-IWsw70hgkv.webp', 'images/product/60/مسدس-غراء-احترافي-220-وات-من-توتال-tt301116-XAfMawrsM2.webp', NULL, NULL, NULL, NULL, NULL, 0, 0, '2023-09-11 18:39:32', '2023-09-11 18:39:32');

-- --------------------------------------------------------

--
-- Table structure for table `product_tables`
--

CREATE TABLE `product_tables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_tables`
--

INSERT INTO `product_tables` (`id`, `product_id`, `attribute_id`, `is_active`, `postion`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 0, NULL, '2023-08-26 08:07:56', '2023-08-26 08:07:56'),
(2, 1, 2, 1, 0, NULL, '2023-08-26 08:08:05', '2023-08-26 08:08:05'),
(3, 1, 3, 1, 0, NULL, '2023-08-26 08:08:17', '2023-08-26 08:08:17'),
(4, 1, 4, 1, 0, NULL, '2023-08-26 08:08:38', '2023-08-26 08:08:38'),
(5, 1, 5, 1, 0, NULL, '2023-08-26 08:08:54', '2023-08-26 08:08:54'),
(6, 2, 1, 1, 0, NULL, '2023-08-26 08:18:47', '2023-08-26 08:18:47'),
(7, 2, 2, 1, 0, NULL, '2023-08-26 08:19:00', '2023-08-26 08:19:00'),
(8, 2, 3, 1, 0, NULL, '2023-08-26 08:19:09', '2023-08-26 08:19:09'),
(9, 2, 4, 1, 0, NULL, '2023-08-26 08:19:19', '2023-08-26 08:19:19'),
(10, 2, 5, 1, 0, NULL, '2023-08-26 08:19:37', '2023-08-26 08:19:37'),
(11, 3, 1, 1, 0, NULL, '2023-08-26 08:20:04', '2023-08-26 08:20:04'),
(12, 3, 2, 1, 0, NULL, '2023-08-26 08:20:12', '2023-08-26 08:20:12'),
(13, 3, 3, 1, 0, NULL, '2023-08-26 08:20:29', '2023-08-26 08:20:29'),
(14, 3, 4, 1, 0, NULL, '2023-08-26 08:20:46', '2023-08-26 08:20:46'),
(15, 3, 5, 1, 0, NULL, '2023-08-26 08:20:55', '2023-08-26 08:20:55'),
(16, 4, 1, 1, 0, NULL, '2023-08-26 08:21:30', '2023-08-26 08:21:30'),
(17, 4, 2, 1, 0, NULL, '2023-08-26 08:21:37', '2023-08-26 08:21:37'),
(18, 4, 3, 1, 0, NULL, '2023-08-26 08:21:47', '2023-08-26 08:21:47'),
(19, 4, 4, 1, 0, NULL, '2023-08-26 08:21:56', '2023-08-26 08:21:56'),
(20, 4, 5, 1, 0, NULL, '2023-08-26 08:22:03', '2023-08-26 08:22:03'),
(21, 7, 1, 1, 0, NULL, '2023-08-26 08:22:53', '2023-08-26 08:22:53'),
(22, 7, 2, 1, 0, NULL, '2023-08-26 08:23:04', '2023-08-26 08:23:04'),
(23, 7, 3, 1, 0, NULL, '2023-08-26 08:23:17', '2023-08-26 08:23:17'),
(24, 7, 4, 1, 0, NULL, '2023-08-26 08:23:26', '2023-08-26 08:23:26'),
(25, 7, 5, 1, 0, NULL, '2023-08-26 08:23:41', '2023-08-26 08:23:41'),
(26, 9, 1, 1, 0, NULL, '2023-08-26 08:24:27', '2023-08-26 08:24:27'),
(27, 9, 2, 1, 0, NULL, '2023-08-26 08:24:36', '2023-08-26 08:24:36'),
(28, 9, 3, 1, 0, NULL, '2023-08-26 08:24:46', '2023-08-26 08:24:46'),
(29, 9, 4, 1, 0, NULL, '2023-08-26 08:24:55', '2023-08-26 08:24:55'),
(30, 9, 5, 1, 0, NULL, '2023-08-26 08:25:04', '2023-08-26 08:25:04'),
(31, 10, 1, 1, 0, NULL, '2023-08-26 08:25:35', '2023-08-26 08:25:35'),
(32, 10, 2, 1, 0, NULL, '2023-08-26 08:25:44', '2023-08-26 08:25:44'),
(33, 10, 3, 1, 0, NULL, '2023-08-26 08:25:53', '2023-08-26 08:25:53'),
(34, 10, 4, 1, 0, NULL, '2023-08-26 08:26:04', '2023-08-26 08:26:04'),
(35, 10, 5, 1, 0, NULL, '2023-08-26 08:26:14', '2023-08-26 08:26:14'),
(36, 12, 1, 1, 0, NULL, '2023-08-26 08:26:52', '2023-08-26 08:26:52'),
(37, 12, 2, 1, 0, NULL, '2023-08-26 08:27:24', '2023-08-26 08:27:24'),
(38, 12, 3, 1, 0, NULL, '2023-08-26 08:27:34', '2023-08-26 08:27:34'),
(39, 12, 4, 1, 0, NULL, '2023-08-26 08:27:46', '2023-08-26 08:27:46'),
(40, 12, 5, 1, 0, NULL, '2023-08-26 08:27:55', '2023-08-26 08:27:55'),
(41, 13, 1, 1, 0, NULL, '2023-08-26 08:28:39', '2023-08-26 08:28:39'),
(42, 13, 2, 1, 0, NULL, '2023-08-26 08:28:47', '2023-08-26 08:28:47'),
(43, 13, 3, 1, 0, NULL, '2023-08-26 08:28:53', '2023-08-26 08:28:53'),
(44, 13, 4, 1, 0, NULL, '2023-08-26 08:29:02', '2023-08-26 08:29:02'),
(45, 13, 5, 1, 0, NULL, '2023-08-26 08:29:09', '2023-08-26 08:29:09'),
(46, 14, 1, 1, 0, NULL, '2023-08-26 08:29:43', '2023-08-26 08:29:43'),
(47, 14, 2, 1, 0, NULL, '2023-08-26 08:29:52', '2023-08-26 08:29:52'),
(48, 14, 3, 1, 0, NULL, '2023-08-26 08:30:00', '2023-08-26 08:30:00'),
(49, 14, 4, 1, 0, NULL, '2023-08-26 08:30:08', '2023-08-26 08:30:08'),
(50, 14, 6, 1, 0, NULL, '2023-08-26 08:30:24', '2023-08-26 08:30:24'),
(51, 15, 5, 1, 0, NULL, '2023-08-26 08:31:19', '2023-08-26 08:31:19'),
(52, 15, 8, 1, 0, NULL, '2023-08-26 08:31:34', '2023-08-26 08:31:34'),
(53, 15, 9, 1, 0, NULL, '2023-08-26 08:31:48', '2023-08-26 08:31:48'),
(54, 15, 10, 1, 0, NULL, '2023-08-26 08:31:59', '2023-08-26 08:31:59'),
(55, 16, 11, 1, 0, NULL, '2023-08-26 08:33:36', '2023-08-26 08:33:36'),
(56, 16, 12, 1, 0, NULL, '2023-08-26 08:33:45', '2023-08-26 08:33:45'),
(57, 16, 3, 1, 0, NULL, '2023-08-26 08:33:56', '2023-08-26 08:33:56'),
(58, 16, 4, 1, 0, NULL, '2023-08-26 08:34:08', '2023-08-26 08:34:08'),
(59, 16, 6, 1, 0, NULL, '2023-08-26 08:34:18', '2023-08-26 08:34:18'),
(60, 17, 11, 1, 0, NULL, '2023-08-26 08:34:57', '2023-08-26 08:34:57'),
(61, 17, 12, 1, 0, NULL, '2023-08-26 08:35:08', '2023-08-26 08:35:08'),
(62, 17, 3, 1, 0, NULL, '2023-08-26 08:35:18', '2023-08-26 08:35:18'),
(63, 21, 12, 1, 0, NULL, '2023-08-26 08:36:04', '2023-08-26 08:36:04'),
(64, 21, 13, 1, 0, NULL, '2023-08-26 08:36:52', '2023-08-26 08:36:52'),
(65, 21, 6, 1, 0, NULL, '2023-08-26 08:37:02', '2023-08-26 08:37:02'),
(66, 22, 12, 1, 0, NULL, '2023-08-26 08:37:46', '2023-08-26 08:37:46'),
(67, 22, 13, 1, 0, NULL, '2023-08-26 08:37:55', '2023-08-26 08:37:55'),
(68, 22, 6, 1, 0, NULL, '2023-08-26 08:38:11', '2023-08-26 08:38:11'),
(69, 37, 1, 1, 0, NULL, '2023-08-26 08:38:43', '2023-08-26 08:38:43'),
(70, 37, 2, 1, 0, NULL, '2023-08-26 08:38:51', '2023-08-26 08:38:51'),
(71, 37, 3, 1, 0, NULL, '2023-08-26 08:39:00', '2023-08-26 08:39:00'),
(72, 37, 4, 1, 0, NULL, '2023-08-26 08:39:09', '2023-08-26 08:39:09'),
(73, 37, 5, 1, 0, NULL, '2023-08-26 08:39:19', '2023-08-26 08:39:19'),
(74, 38, 1, 1, 0, NULL, '2023-08-26 08:40:02', '2023-08-26 08:40:02'),
(75, 38, 2, 1, 0, NULL, '2023-08-26 08:40:11', '2023-08-26 08:40:11'),
(76, 38, 3, 1, 0, NULL, '2023-08-26 08:40:18', '2023-08-26 08:40:18'),
(77, 38, 4, 1, 0, NULL, '2023-08-26 08:40:26', '2023-08-26 08:40:26'),
(78, 38, 5, 1, 0, NULL, '2023-08-26 08:40:38', '2023-08-26 08:40:38'),
(79, 41, 1, 1, 0, NULL, '2023-08-26 08:41:18', '2023-08-26 08:41:18'),
(80, 41, 2, 1, 0, NULL, '2023-08-26 08:41:43', '2023-08-26 08:41:43'),
(81, 41, 3, 1, 0, NULL, '2023-08-26 08:41:55', '2023-08-26 08:41:55'),
(82, 41, 4, 1, 0, NULL, '2023-08-26 08:42:04', '2023-08-26 08:42:04'),
(83, 41, 5, 1, 0, NULL, '2023-08-26 08:42:14', '2023-08-26 08:42:14'),
(84, 42, 1, 1, 0, NULL, '2023-08-26 08:43:06', '2023-08-26 08:43:06'),
(85, 42, 2, 1, 0, NULL, '2023-08-26 08:43:14', '2023-08-26 08:43:14'),
(86, 42, 3, 1, 0, NULL, '2023-08-26 08:43:22', '2023-08-26 08:43:22'),
(87, 42, 4, 1, 0, NULL, '2023-08-26 08:43:31', '2023-08-26 08:43:31'),
(88, 42, 5, 1, 0, NULL, '2023-08-26 08:43:43', '2023-08-26 08:43:43'),
(89, 44, 1, 1, 0, NULL, '2023-08-26 08:44:16', '2023-08-26 08:44:16'),
(90, 44, 2, 1, 0, NULL, '2023-08-26 08:44:25', '2023-08-26 08:44:25'),
(91, 44, 3, 1, 0, NULL, '2023-08-26 08:44:35', '2023-08-26 08:44:35'),
(92, 44, 4, 1, 0, NULL, '2023-08-26 08:44:48', '2023-08-26 08:44:48'),
(93, 44, 5, 1, 0, NULL, '2023-08-26 08:44:58', '2023-08-26 08:44:58'),
(94, 44, 7, 1, 0, NULL, '2023-08-26 08:45:45', '2023-08-26 08:45:45'),
(95, 53, 5, 1, 0, NULL, '2023-08-26 08:46:18', '2023-08-26 08:46:18'),
(96, 53, 8, 1, 0, NULL, '2023-08-26 08:46:32', '2023-08-26 08:46:32'),
(97, 53, 9, 1, 0, NULL, '2023-08-26 08:46:46', '2023-08-26 08:46:46'),
(98, 53, 10, 1, 0, NULL, '2023-08-26 08:47:01', '2023-08-26 08:47:01'),
(99, 18, 11, 1, 0, NULL, '2023-08-26 08:47:37', '2023-08-26 08:47:37'),
(100, 18, 12, 1, 0, NULL, '2023-08-26 08:47:47', '2023-08-26 08:47:47'),
(101, 18, 3, 1, 0, NULL, '2023-08-26 08:48:00', '2023-08-26 08:48:00'),
(102, 19, 5, 1, 0, NULL, '2023-08-26 08:48:36', '2023-08-26 08:48:36'),
(103, 19, 4, 1, 0, NULL, '2023-08-26 08:48:48', '2023-08-26 08:48:48'),
(104, 19, 3, 1, 0, NULL, '2023-08-26 08:48:59', '2023-08-26 08:48:59');

-- --------------------------------------------------------

--
-- Table structure for table `product_table_translations`
--

CREATE TABLE `product_table_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_table_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_table_translations`
--

INSERT INTO `product_table_translations` (`id`, `product_table_id`, `locale`, `des`) VALUES
(1, 1, 'ar', 'مادة لاصقة ذات أساس مذيب طبيعي'),
(2, 1, 'en', 'Natural solvent based adhesive'),
(3, 2, 'ar', 'شفاف وقاطم'),
(4, 2, 'en', 'clear and tan'),
(5, 3, 'ar', '4.8 سم'),
(6, 3, 'en', '4.8 cm'),
(7, 4, 'ar', '60 متر'),
(8, 4, 'en', '60 m'),
(9, 5, 'ar', '43 ميكرون'),
(10, 5, 'en', '43 mic'),
(11, 6, 'ar', 'مادة لاصقة مائية مطلية بغشاء BOPP'),
(12, 6, 'en', 'Water based acrylic adhesive'),
(13, 7, 'ar', 'فيلم الكريستال'),
(14, 7, 'en', 'crystal film'),
(15, 8, 'ar', '4.5 سم'),
(16, 8, 'en', '4.5 cm'),
(17, 9, 'ar', '60,100 يارده'),
(18, 9, 'en', '60,100 yard'),
(19, 10, 'ar', '40 ميكرون'),
(20, 10, 'en', '40 mic'),
(21, 11, 'ar', 'مادة لاصقة ذات أساس مائي'),
(22, 11, 'en', 'Water based acrylic adhesive'),
(23, 12, 'ar', 'فيلم الكريستال'),
(24, 12, 'en', 'crystal film'),
(25, 13, 'ar', '4.5 , 4.8 سم'),
(26, 13, 'en', '4.5 cm - 4.8 cm'),
(27, 14, 'ar', '60, 80, 100, 150 ياردة'),
(28, 14, 'en', '60, 80, 100, 150 yard'),
(29, 15, 'ar', '45 ميكرون'),
(30, 15, 'en', '45 mic'),
(31, 16, 'ar', 'مادة لاصقة ذات أساس مائي'),
(32, 16, 'en', 'Water based acrylic adhesive'),
(33, 17, 'ar', 'كريستال'),
(34, 17, 'en', 'crystal film'),
(35, 18, 'ar', '4.5 سم'),
(36, 18, 'en', '4.5 cm'),
(37, 19, 'ar', '100 يارده'),
(38, 19, 'en', '100 yard'),
(39, 20, 'ar', '45 ميكرون'),
(40, 20, 'en', '45 mic'),
(41, 21, 'ar', 'لاصق أكريليك ذو أساس مائي'),
(42, 21, 'en', 'Water based acrylic adhesive'),
(43, 22, 'ar', 'كريستال'),
(44, 22, 'en', 'crystal film'),
(45, 23, 'ar', '12مم ,18مم,24مم'),
(46, 23, 'en', '12mm,18mm,24mm'),
(47, 24, 'ar', '25 متر'),
(48, 24, 'en', '25 meter'),
(49, 25, 'ar', '40 ميكرون'),
(50, 25, 'en', '40 mic'),
(51, 26, 'ar', 'لاصق مطاطى'),
(52, 26, 'en', 'rubber adhesive'),
(53, 27, 'ar', 'ورقى'),
(54, 27, 'en', 'crepe paper'),
(55, 28, 'ar', '2.4 , 4.5 سم'),
(56, 28, 'en', '2.4 , 4.5 CM'),
(57, 29, 'ar', '27 متر'),
(58, 29, 'en', '27M'),
(59, 30, 'ar', '140 & 145 جرام'),
(60, 30, 'en', '140 & 145 gram'),
(61, 31, 'ar', 'لاصق مطاطى'),
(62, 31, 'en', 'rubber adhesive'),
(63, 32, 'ar', 'ورقى'),
(64, 32, 'en', 'crepe paper'),
(65, 33, 'ar', '2.4 , 4.5 سم'),
(66, 33, 'en', '2.4 , 4.5 CM'),
(67, 34, 'ar', '15 متر'),
(68, 34, 'en', '15 M'),
(69, 35, 'ar', '140 & 145 جرام'),
(70, 35, 'en', '140 & 145 gram'),
(71, 36, 'ar', 'مادة لاصقة ذات أساس مائي'),
(72, 36, 'en', 'water based adhesive'),
(73, 37, 'ar', 'أبيض'),
(74, 37, 'en', 'white based'),
(75, 38, 'ar', '4.8 سم'),
(76, 38, 'en', '4.8 cm'),
(77, 39, 'ar', '100 يارده'),
(78, 39, 'en', '100 Yard'),
(79, 40, 'ar', '50 ميكرون'),
(80, 40, 'en', '50 Micron'),
(81, 41, 'ar', 'مادة لاصقة ذات أساس مائي'),
(82, 41, 'en', 'water based adhesive'),
(83, 42, 'ar', 'أبيض'),
(84, 42, 'en', 'white based'),
(85, 43, 'ar', '5 سم'),
(86, 43, 'en', '5 cm'),
(87, 44, 'ar', '100 يارده'),
(88, 44, 'en', '100 y'),
(89, 45, 'ar', '48 ميكرون'),
(90, 45, 'en', '48 Micron'),
(91, 46, 'ar', 'لاصق مطاطى'),
(92, 46, 'en', 'rubber adhesive'),
(93, 47, 'ar', 'شريط عازل'),
(94, 47, 'en', 'insulating tape'),
(95, 48, 'ar', '18 مم'),
(96, 48, 'en', '18 mm'),
(97, 49, 'ar', '5,7,10,15,20 يارده'),
(98, 49, 'en', '5y, 7y, 10y, 15y, 20y'),
(99, 50, 'ar', '50 عبوة بالكرتونة'),
(100, 50, 'en', '50 shrink/CTN'),
(101, 51, 'ar', '0.011 مم'),
(102, 51, 'en', '0.011 Mm'),
(103, 52, 'ar', '8011/O'),
(104, 52, 'en', '8011/O'),
(105, 53, 'ar', 'جانب واحد لامع ، والاخر غير لامع'),
(106, 53, 'en', 'One Side Bright, One Side Matte'),
(107, 54, 'ar', 'رول'),
(108, 54, 'en', 'ROLL'),
(109, 55, 'ar', 'البولي بروبلين'),
(110, 55, 'en', 'Polypropylene'),
(111, 56, 'ar', 'أحمر ,أخضر , أصفر ,أبيض , أزرق , روز'),
(112, 56, 'en', 'Red / Green / Yellow / White / Blue / Rose'),
(113, 57, 'ar', '½ سم'),
(114, 57, 'en', '½ cm'),
(115, 58, 'ar', 'حتى 500 يارده'),
(116, 58, 'en', 'Till 500 Yards'),
(117, 59, 'ar', 'العبوة 50 بكرة'),
(118, 59, 'en', '50 Rolls'),
(119, 60, 'ar', 'البولي بروبلين'),
(120, 60, 'en', 'Polypropylene'),
(121, 61, 'ar', 'أحمر ,أخضر , أصفر ,أبيض , أزرق , روز'),
(122, 61, 'en', 'Red / Green / Yellow / White / Blue / Rose'),
(123, 62, 'ar', '5 سم'),
(124, 62, 'en', '5 cm'),
(125, 63, 'ar', 'يتوفر العديد من الألوان'),
(126, 63, 'en', 'Many color Available'),
(127, 64, 'ar', '180 جرام / 140 جرام'),
(128, 64, 'en', '180 gram / 140 gram'),
(129, 65, 'ar', '60 رول / 70 رول'),
(130, 65, 'en', '60 rolls / 70 rolls'),
(131, 66, 'ar', 'يتوفر العديد من الألوان ميتاليك'),
(132, 66, 'en', 'Many color Available (Metallic colors)'),
(133, 67, 'ar', '180 جرام / 140 جرام'),
(134, 67, 'en', '180 gram / 140 gram'),
(135, 68, 'ar', '60 رول / 70 رول'),
(136, 68, 'en', '60 rolls / 70 rolls'),
(137, 69, 'ar', 'مادة لاصقة ذات أساس مائي'),
(138, 69, 'en', 'water based adhesive'),
(139, 70, 'ar', 'كريستال'),
(140, 70, 'en', 'Cyrastal'),
(141, 71, 'ar', '4.5 سم'),
(142, 71, 'en', '4.5 cm'),
(143, 72, 'ar', 'متاح حسب الطلب'),
(144, 72, 'en', 'as per request'),
(145, 73, 'ar', '40 ميكرون'),
(146, 73, 'en', '40 mic'),
(147, 74, 'ar', 'مادة لاصقة ذات أساس مائي'),
(148, 74, 'en', 'water based adhesive'),
(149, 75, 'ar', 'كريستال'),
(150, 75, 'en', 'Cyrastal'),
(151, 76, 'ar', '4.5 سم'),
(152, 76, 'en', '4.5 cm'),
(153, 77, 'ar', 'متاح حسب الطلب'),
(154, 77, 'en', 'as per request'),
(155, 78, 'ar', '40 ميكرون'),
(156, 78, 'en', '40 mic'),
(157, 79, 'ar', 'لاصق أكريليك ذو أساس مائي'),
(158, 79, 'en', 'water based adhesive'),
(159, 80, 'ar', 'ليزير'),
(160, 80, 'en', 'Laser'),
(161, 81, 'ar', '4.5 سم'),
(162, 81, 'en', '4.5 cm'),
(163, 82, 'ar', 'متاح حسب الطلب'),
(164, 82, 'en', 'as per request'),
(165, 83, 'ar', '40 ميكرون'),
(166, 83, 'en', '40 mic'),
(167, 84, 'ar', 'لاصق أكريليك ذو أساس مائي'),
(168, 84, 'en', 'Water based acrylic adhesive'),
(169, 85, 'ar', 'كريستال'),
(170, 85, 'en', 'crystal film'),
(171, 86, 'ar', '12مم,18مم,24مم'),
(172, 86, 'en', '12mm,18mm,24mm'),
(173, 87, 'ar', '25 متر'),
(174, 87, 'en', '25 M'),
(175, 88, 'ar', '38 ميكرون'),
(176, 88, 'en', '38 MIC'),
(177, 89, 'ar', 'لاصق أكريليك ذو أساس مائي'),
(178, 89, 'en', 'water based adhesive'),
(179, 90, 'ar', 'ليزير'),
(180, 90, 'en', 'Laser'),
(181, 91, 'ar', '12مم,18مم'),
(182, 91, 'en', '12mm,18mm'),
(183, 92, 'ar', '10 متر'),
(184, 92, 'en', '10 M'),
(185, 93, 'ar', '40 ميكرون'),
(186, 93, 'en', '40 mic'),
(187, 94, 'ar', 'Plastic core'),
(188, 94, 'en', 'Plastic core'),
(189, 95, 'ar', '0.011 مم'),
(190, 95, 'en', '0.011 Mm'),
(191, 96, 'ar', '8011/O'),
(192, 96, 'en', '8011/O'),
(193, 97, 'ar', 'جانب واحد لامع ، والاخر غير لامع'),
(194, 97, 'en', 'One Side Bright, One Side Matte'),
(195, 98, 'ar', 'رول'),
(196, 98, 'en', 'ROLL'),
(197, 99, 'ar', 'البولي بروبلين'),
(198, 99, 'en', 'Polypropylene'),
(199, 100, 'ar', 'أحمر ,أخضر , أصفر ,أبيض , أزرق , روز'),
(200, 100, 'en', 'Red / Green / Yellow / White / Blue / Rose'),
(201, 101, 'ar', '5 سم'),
(202, 101, 'en', '5 cm'),
(203, 102, 'ar', '20 ميكرون'),
(204, 102, 'en', '20 micron'),
(205, 103, 'ar', '70 سم'),
(206, 103, 'en', '70 cm'),
(207, 104, 'ar', '100 سم'),
(208, 104, 'en', '100 cm');

-- --------------------------------------------------------

--
-- Table structure for table `product_translations`
--

CREATE TABLE `product_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_translations`
--

INSERT INTO `product_translations` (`id`, `product_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 1, 'ar', 'شرائط-التعبئة-والتغليف-نار-تيب', 'نار تيب', 'نار تيب شرائط ذاتية اللصق مصنوع من مادة لاصقة ذات أساس مذيب مطلية على فيلم BOPP ، وهي متوفرة في فيلم شفاف ويمكن أيضًا توفيره في فيلم قاطم . هذا النوع يلبي متطلبات العميل من تغليف الكرتون التى يمكن وضعه في الثلاجات والافران. وهو مصنوع لدعم الظروف الخاصة بدرجة حرارة منخفضة أو عالية. ', 'الأشرطة ذاتية اللصق | شرائط التعبئة والتغليف | نار تيب', 'نار تيب شرائط ذاتية اللصق مصنوع من مادة لاصقة ذات أساس مذيب مطلية على فيلم BOPP ، وهي متوفرة في فيلم شفاف ويمكن أيضًا توفيره في فيلم قاطم .'),
(2, 1, 'en', 'Packaging-Tape-Nar-Tape', 'Nar Tape', 'The Nar Tape is made from solvent based adhesive coated on BOPP film .It provide in clear film and also can supply in tan film .This type to meet client\'s requirement of packing carton which can go in fridge and oven .It made to support special circumstances as low or high temperature .', 'Self Adhesive Tape | Packaging Tape | Nar Tape', 'The Nar Tape is made from solvent based adhesive coated on BOPP film .It provide in clear film and also can supply in tan film .This type to meet client\'s '),
(3, 2, 'ar', 'شرائط-التعبئة-والتغليف-ذا-بيست-تيب', 'ذا بيست تيب', 'ذا بيست تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي ، وهذا النوع يلبي متطلبات العميل من تعبئة الكراتين بأسلوب يدعم الوزن العالي للكرتون.', 'الأشرطة ذاتية اللصق | شرائط التعبئة والتغليف | ذا بيست تيب', 'ذا بيست تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي '),
(4, 2, 'en', 'Packaging-Tape-The-Best-Tape', 'The Best Tape', 'The Best Tape is made from water based adhesive coated on BOPP film .\r\nIt provide in crystal clear film.This type to meet client\'s requirement of packing cartons with style and it support high weight of cartons .', 'Self Adhesive Tape | Packaging Tape | The Best Tape', 'The Best Tape is made from water based adhesive coated on BOPP film. It provide in crystal clear film.This type to meet client\'s requirement of packing '),
(5, 3, 'ar', 'شرائط-التعبئة-والتغليف-كريستال-تيب', 'كريستال تيب', 'كريستال تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي ، وهذا النوع يلبي متطلبات العميل من تعبئة الكراتين بأسلوب يدعم الوزن العالي للكرتون.', 'الأشرطة ذاتية اللصق | شرائط التعبئة والتغليف | كريستال تيب', 'كريستال تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي'),
(6, 3, 'en', 'Packaging-Tape-Crystal-Tape', 'Crystal Tape ', 'The Crystal Tape  is made from water based adhesive coated on BOPP film .\r\nIt provide in crystal clear film.This type to meet client\'s requirement of packing cartons with style and it support high weight of cartons .', 'Self Adhesive Tape | Packaging Tape | Crystal Tape ', 'The Crystal Tape  is made from water based adhesive coated on BOPP film .It provide in crystal clear film.This type to meet client\'s requirement of packing'),
(7, 4, 'ar', 'شرائط-التعبئة-والتغليف-جرين-تيب', 'جرين تيب', 'جرين تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي ، وهذا النوع يلبي متطلبات العميل من تعبئة الكراتين بأسلوب يدعم الوزن العالي للكرتون.', 'الأشرطة ذاتية اللصق | شرائط التعبئة والتغليف | جرين تيب', 'جرين تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي ، وهذا النوع يلبي متطلبات العميل من تعبئة '),
(8, 4, 'en', 'Packaging-Tape-Green-Tape', 'Green Tape', 'The Green Tape is made from water based adhesive coated on BOPP film .\r\nIt provide in crystal clear film.This type to meet client\'s requirement of packing cartons with style and it support high weight of cartons .', 'Self Adhesive Tape | Packaging Tape | Green Tape', 'The Green Tape is made from water based adhesive coated on BOPP film .It provide in crystal clear film.This type to meet client\'s requirement'),
(9, 7, 'ar', 'السوليتب-المكتبى-ذا-بيست', 'ذا بيست', 'سوليتب مكتبى ذا بيست مصنوع من مادة لاصقة أكريليك مائيّة مطلية بأفلام BOOP وهي متوفرة بأحجام وعرض مختلفة. الاستعمال: تغليف الهدايا ، التعبئة الخفيفة ، الأعمال الفنية ، التطبيقات المكتبية ، إصلاح الورق وتقوية المستندات. ', 'الأشرطة ذاتية اللصق | السوليتب المكتبى | ذا بيست', 'سوليتب مكتبى ذا بيست مصنوع من مادة لاصقة أكريليك مائيّة مطلية بأفلام BOOP وهي متوفرة بأحجام وعرض مختلفة. الاستعمال: تغليف الهدايا ، التعبئة الخفيفة '),
(10, 7, 'en', 'Stationary-Tape-The-Best', 'The Best', 'The Best Stationary tape is made with water based acrylic adhesive coated on BOOP films It available with different sizes and widths. Usage : gift wrapping , light packing , art craft , office application , paper mending and reinforcing documents .', 'Self Adhesive Tape | Stationary Tape | The Best', 'The Best Stationary tape is made with water based acrylic adhesive coated on BOOP films It available with different sizes and widths. Usage gift wrapping '),
(11, 9, 'ar', 'الأشرطة-ذاتية-اللصق-جرين-ماسك-تيب', 'جرين ماسك تيب', 'جرين ماسك تيب مصنوع من خامات ورقية مغطى بمادة لاصقة مطاطية يمكن استخدامها في تطبيقات الحماية والتثبيت والأغراض العامة. إنه متوفر بأحجام مختلفة لتلبية متطلبات العميل الخاصة. تستخدم بدرجات حرارة مختلفة للدهان السيارات. وتغطية الأسطح أثناء الرش أو الطلاء. وكذلك حماية الأسطح المعدنية والبلاستيكية والزجاجية.', 'الأشرطة ذاتية اللصق | جرين ماسك تيب', 'جرين ماسك تيب مصنوع من خامات ورقية مغطى بمادة لاصقة مطاطية يمكن استخدامها في تطبيقات الحماية والتثبيت والأغراض العامة. إنه متوفر بأحجام مختلفة'),
(12, 9, 'en', 'Self-Adhesive-Tape-Green-Masking-Tape', 'Green Masking Tape', 'Green Masking Tape is made of crepe paper that coated with rubber adhesive that could use for sealing , holding and general purpose applications. It’s available in different sizes , widths and designs to meet client’s special requirements. It used in different temperature degrees for painting and car’s spray. and Covering surfaces during spraying or painting. and also Protection of metal , plastic and glasses surfaces .', 'Self Adhesive Tape | Green Masking Tape', 'Green Masking Tape is made of crepe paper that coated with rubber adhesive that could use for sealing , holding and general purpose applications.'),
(13, 10, 'ar', 'الأشرطة-ذاتية-اللصق-اى-تى-ماسك-تيب', 'اى تى ماسك تيب', 'اى تى ماسك تيب مصنوع من خامات ورقية مغطى بمادة لاصقة مطاطية يمكن استخدامها في تطبيقات الحماية والتثبيت والأغراض العامة. إنه متوفر بأحجام مختلفة لتلبية متطلبات العميل الخاصة. تستخدم بدرجات حرارة مختلفة للدهان السيارات. وتغطية الأسطح أثناء الرش أو الطلاء. وكذلك حماية الأسطح المعدنية والبلاستيكية والزجاجية.', 'الأشرطة ذاتية اللصق | اى تى ماسك تيب', 'اى تى ماسك تيب مصنوع من خامات ورقية مغطى بمادة لاصقة مطاطية يمكن استخدامها في تطبيقات الحماية والتثبيت والأغراض العامة. إنه متوفر بأحجام مختلفة'),
(14, 10, 'en', 'Self-Adhesive-Tape-ET-Masking-Tape', 'ET Masking Tape', 'ET Masking Tape is made of crepe paper that coated with rubber adhesive that could use for sealing , holding and general purpose applications. It’s available in different sizes , widths and designs to meet client’s special requirements. It used in different temperature degrees for painting and car’s spray. and Covering surfaces during spraying or painting. and also Protection of metal , plastic and glasses surfaces .', 'Self Adhesive Tape | ET Masking Tape', 'ET Masking Tape is made of crepe paper that coated with rubber adhesive that could use for sealing , holding and general purpose applications. It’s available'),
(15, 12, 'ar', 'الاشرطة-ذاتية-اللصق-المطبوعة-فريش', 'فريش ', 'فريش شريط لاصق مطبوع مصنوع من مادة لاصقة أكريليك مائية مطلية بأفلام BOPP .إنه مصنوع من أفضل المواد والخامات لتلبية متطلبات المستخدمين النهائيين. يمكن استخدامه في تغليف المنتجات التي توضح الأصل المصري للمحتوى. ', 'الأشرطة ذاتية اللصق | الاشرطة ذاتية اللصق المطبوعة | فريش', 'فريش المطبوع مصنوع من مادة لاصقة أكريليك مائية مطلية بأفلام BOPP .إنه مصنوع من أفضل المواد والخامات لتلبية متطلبات المستخدمين النهائيين.'),
(16, 12, 'en', 'Printed-Self-Adhesive-Tape-Fresh', 'Fresh printed tape', 'Fresh printed tape is made with water based acrylic adhesive coated on BOPP films its made for best materials to meet end users requirements . it can use in sealing some thing showing the Egyptian origin of the content .', 'Self Adhesive Tape | Printed Self Adhesive Tape | Fresh', 'Fresh printed tape is made with water based acrylic adhesive coated on BOPP films its made for best materials to meet end users requirements'),
(17, 13, 'ar', 'الاشرطة-ذاتية-اللصق-المطبوعة-قابل-للكسر', 'قابل للكسر', 'قابل للكسر شريط لاصق مطبوع مصنوع من مادة لاصقة أكريليك مائية مطلية بأفلام BOPP .إنه مصنوع من أفضل المواد والخامات لتلبية متطلبات المستخدمين النهائيين.يمكن استخدامه في تغليف المنتجات القابلة للكسر للحفاظ على سلامة اثناء عمليات التخزين والنقل ', 'الأشرطة ذاتية اللصق | الاشرطة ذاتية اللصق المطبوعة | قابل للكسر', 'قابل للكسر شريط لاصق مطبوع مصنوع من مادة لاصقة أكريليك مائية مطلية بأفلام BOPP .إنه مصنوع من أفضل المواد والخامات لتلبية متطلبات المستخدمين '),
(18, 13, 'en', 'Fragile-printed-tape', 'Fragile printed tape ', 'Fragile printed tape its made for best materials to meet end users requirements . \r\nit can use in sealing some thing to be caution to avoid any misunderstanding to save products .', 'Self Adhesive Tape | Printed Self Adhesive Tape | Fragile tape ', 'Fragile printed tape its made for best materials to meet end users requirements\r\nit can use in sealing some thing to be caution to avoid any misunderstanding'),
(19, 14, 'ar', 'الأشرطة-ذاتية-اللصق-شريط-العزل-الكهربائي-ET', 'شرائط العزل الكهربائي ET', 'شرائط العزل الكهربائي PVC مصنوعة من البولي فينيل كلوريد (spvc) المطلي بمادة لاصقة حساسة للضغط، كما أنه يعتبر مقاومًا جيدًا لدرجات الحرارة والرطوبة والجهد العالي وتطبيقات الحماية. متوفر بأحجام مختلفة. يستخدم فى تطبيقات الاعمال الكهربائية', 'الأشرطة ذاتية اللصق | شريط العزل الكهربائي ET', 'شرائط العزل الكهربائي PVC مصنوعة من افضل خامات تايوان ذات الأداء العالي والجودة في استخدام التطبيق. '),
(20, 14, 'en', 'Self-Adhesive-Tape-Electrical-Insulating-Tape', 'PVC Electrical Tape - ET', 'Electrical Insulating Tape PVC insulating tape is made from soft polyvinyl chloride (spvc) which is coated with rubber pressure -sensitive adhesive , it’s also considered good resistant to temperature , moisture , high voltage and protection applications .\r\nPVC electrical tape made from the best TAIWAN materials with high performance and quality can feel in application use .\r\nIt’s available in different sizes .Usage in Strong tensile strength use in electric work application .\r\n\r\n', 'Self Adhesive Tape | Electrical Insulating Tape', 'PVC electrical tape made from the best TAIWAN materials with high performance and quality can feel in application use .'),
(21, 15, 'ar', 'الومنيوم-فويل-مستر-فويل-50-جرام', 'الومنيوم فويل مستر فويل 50 جرام', 'العلامة التجارية رقم 1 لرقائق الألمنيوم المصنوعة في مصر ، مستر فويل بالقوة والجودة الموثوق بها التي يمكنك الاعتماد عليها لطهي وجبات لذيذة مع سهولة التنظيف\r\nسميكة جدًا للطبخ في الفرن أو على الشواية أو على النار ؛ يسمح للطهي لفترة أطول من أجل شواء اللحوم بشكل أفضل.يساعدك صندوق الورق المقوى المزود بقاطع معدني على تمزيق ورق القصدير بشكل أكثر كفاءة وراحة. ', 'الومنيوم فويل استخدام منزلى | الومنيوم فويل مستر فويل 50 جرام', 'العلامة التجارية رقم 1 لرقائق الألمنيوم المصنوعة في مصر ، مستر فويل بالقوة والجودة الموثوق بها التي يمكنك الاعتماد عليها لطهي وجبات'),
(22, 15, 'en', 'Aluminium-foil-MR-FOIL-50gm', 'Aluminium foil MR. FOIL  ', 'The number 1 brand of aluminum foil made in the Egypt, MR. FOIL has the trusted strength and quality you can count on for cooking delicious meals with easy cleanup \r\nExtra thickened for cooking in the oven, on the grill or over a fire; allows for longer cooking limiting to better broil the meats.\r\nPaper board box with metal cutter help you to tear off the foil paper more efficiently and conveniently.', 'Aluminium foil for House Hold | Aluminium foil MR. FOIL 50gm', 'The number 1 brand of aluminum foil made in the Egypt, MR. FOIL has the trusted strength and quality you can count on for cooking delicious meals'),
(23, 16, 'ar', 'مستلزمات-الهدايا-شرائط-الزينة-نصف-سم', 'شرائط الزينة ½ سم', 'شرائط الزينة ½ سم مصنوع من مادة البولي بروبيلين عالية الجودة ومتوفر بعدة ألوان. يمكن استخدامها لتزيين أي منتج. لحفلات الزفاف ، والكريسماس ، وأعياد الميلاد ، والخطوبة ، وعيد الأم ، والتهاني ، وديكورات المهرجانات ، والحرف اليدوية ، والهدايا ، وإكسسوارات الألعاب ، إلخ.', 'مستلزمات الهدايا | شرائط الزينة | شرائط الزينة ½ سم', 'شرائط الزينة ½ سم مصنوع من مادة البولي بروبيلين عالية الجودة ومتوفر بعدة ألوان. يمكن استخدامها لتزيين أي منتج. لحفلات الزفاف ، والكريسماس ، وأعياد الميلاد '),
(24, 16, 'en', 'Gift-Accessories-05-cm-PP-ribbon', '½ Cm PP Ribbon', '½ cm PP ribbon It is made of quality polypropylene material and is available in several colors. It can be used for decoration of any product. For wedding, Christmas, Birthday, Engagement,Mother’s day, Congratulations, and other festival decoration, Handcraft, gift and premiums, packing ornament and toy’s accessories etc.', 'Gift Accessories | Ribbon | ½ cm PP ribbon', '½ cm PP ribbon It is made of quality polypropylene material and is available in several colors. It can be used for decoration of any product. For wedding'),
(25, 17, 'ar', 'مستلزمات-الهدايا-شرائط-الزينة-5-سم', 'شرائط الزينة 5 سم', 'شرائط الزينة 5 سم مصنوع من مادة البولي بروبيلين عالية الجودة ومتوفر بعدة ألوان. يمكن استخدامها لتزيين أي منتج. لحفلات الزفاف ، والكريسماس ، وأعياد الميلاد ، والخطوبة ، وعيد الأم ، والتهاني ، وديكورات المهرجانات ، والحرف اليدوية ، والهدايا ، وإكسسوارات الألعاب ، إلخ.', 'مستلزمات الهدايا | شرائط الزينة | شرائط الزينة 5 سم', 'شرائط الزينة 5 سم مصنوع من مادة البولي بروبيلين عالية الجودة ومتوفر بعدة ألوان. يمكن استخدامها لتزيين أي منتج. لحفلات الزفاف ، والكريسماس ، وأعياد الميلاد '),
(26, 17, 'en', 'Gift-Accessories-5-cm-PP-ribbon', '5 Cm PP Ribbon', '5 Cm PP Ribbon It is made of quality polypropylene material and is available in several colors. It can be used for decoration of any product. For wedding, Christmas, Birthday, Engagement,Mother’s day, Congratulations, and other festival decoration, Handcraft, gift and premiums, packing ornament and toy’s accessories etc.', 'Gift Accessories | Ribbon | 5 cm PP ribbon', '5 cm PP ribbon It is made of quality polypropylene material and is available in several colors. It can be used for decoration of any product. For wedding'),
(27, 18, 'ar', 'مستلزمات-الهدايا-شرائط-الزينة-الميتاليكا', 'شرائط الزينة الميتاليكا ', 'شرائط الزينة الميتاليكا مصنوع من مادة البولي بروبيلين عالية الجودة ومتوفر بعدة ألوان. يمكن استخدامها لتزيين أي منتج. لحفلات الزفاف ، والكريسماس ، وأعياد الميلاد ، والخطوبة ، وعيد الأم ، والتهاني ، وديكورات المهرجانات ، والحرف اليدوية ، والهدايا ، وإكسسوارات الألعاب ، إلخ.', 'مستلزمات الهدايا | شرائط الزينة | شرائط الزينة الميتاليكا ', 'شرائط الزينة الميتاليكا مصنوع من مادة البولي بروبيلين عالية الجودة ومتوفر بعدة ألوان. يمكن استخدامها لتزيين أي منتج. لحفلات الزفاف ، والكريسماس , أعياد الميلاد'),
(28, 18, 'en', 'Gift-Accessories-Metallic-PP-ribbon', 'Metallic PP Ribbon', 'Metallic PP ribbon It is made of quality polypropylene material and is available in several colors. It can be used for decoration of any product. For wedding, Christmas, Birthday, Engagement,Mother’s day, Congratulations, and other festival decoration, Handcraft, gift and premiums, packing ornament and toy’s accessories etc.', 'Gift Accessories | Ribbon | Metallic PP ribbon', 'Metallic PP ribbon It is made of quality polypropylene material and is available in several colors. It can be used for decoration of any product. For wedding'),
(29, 19, 'ar', 'مستلزمات-الهدايا-ورق-لف-الهدايا-الميتلك', 'ورق لف الهدايا الميتلك', 'يأتي ورق لف الهدايا بمجموعة كبيرة من التصميمات الابداعية ، ورق تغليف الهدايا المعدني المطبوع هو عنصر مثالي لتغليف الهدايا بمجموعة كبيرة من التصاميم والأنماط التي تغطي اذواق الأطفال والبنات والأولاد والاذواق العالمية و أعيد الميلاد وتضفي لمسة نهائية رائعة على هداياك. ', 'مستلزمات الهدايا | ورق لف الهدايا | ورق لف الهدايا الميتلك ', 'ورق لف الهدايا الميتلك يأتي بمجموعة كبيرة من التصميمات الابداعية ، ورق تغليف الهدايا المعدني المطبوع هو عنصر مثالي لتغليف الهدايا بمجموعة كبيرة'),
(30, 19, 'en', 'Gift-Accessories-Metallic-paper', 'Metallic Paper', 'Metallic Paper come with Creative designs printed metallized gift wrap is prefect item to wrap gifts. Large ranges of designs and patterns covering baby, girls, boys, universal patterns and Christmas for your selection and give incredible finish to your gifts. ', 'Gift Accessories | Gift Paper | Metallic paper', 'Metallic Paper come with Creative designs printed metallized gift wrap is prefect item to wrap gifts. Large ranges of designs and patterns covering baby, girls'),
(31, 21, 'ar', 'مستلزمات-الهدايا-ورق-كوريشة', 'ورق كوريشة ', 'تستخدم ورق الكوريشة عالي الجودة الخاص بنا لإنشاء باقة زهور جميلة مثالي لحفلات الزفاف والذكرى السنوية واحتفالات أعياد الميلاد وحفلات التخرج وحفلات استقبال المولود الجديد وحفلات الخطوبة والمزيد!', 'مستلزمات الهدايا | ورق الكوريشة | ورق كوريشة ', 'تستخدم ورق الكوريشة عالي الجودة الخاص بنا لإنشاء باقة زهور جميلة مثالي لحفلات الزفاف والذكرى السنوية واحتفالات أعياد الميلاد وحفلات التخرج '),
(32, 21, 'en', 'Crepe-Paper-Normal-Color', 'Normal Color', 'Crepe Paper Normal Color are a fabulous alternative to fresh flowers! Use our quality Crepe Paper to create a beautiful floral bouquet that will last for years to come. Perfect for weddings, anniversaries, birthday celebrations, graduations, baby showers, engagement parties, and more ', 'Gift Accessories | Crepe Paper Normal Color', 'Crepe Paper Normal Color are a fabulous alternative to fresh flowers! Use our quality Crepe Paper to create a beautiful floral bouquet'),
(33, 22, 'ar', 'مستلزمات-الهدايا-ورق-كوريشة-ميتاليك', 'ورق كوريشة ميتاليك', 'تستخدم ورق الكوريشة الميتاليك عالي الجودة الخاص بنا لإنشاء باقة زهور جميلة مثالي لحفلات الزفاف والذكرى السنوية واحتفالات أعياد الميلاد وحفلات التخرج وحفلات استقبال المولود الجديد وحفلات الخطوبة والمزيد!', 'مستلزمات الهدايا | ورق كوريشة | ورق كوريشة ميتاليك ', 'تستخدم ورق الكوريشة الميتاليك عالي الجودة الخاص بنا لإنشاء باقة زهور جميلة مثالي لحفلات الزفاف والذكرى السنوية واحتفالات أعياد الميلاد وحفلات التخرج '),
(34, 22, 'en', 'Crepe-Paper-Metallic-color', 'Metallic Color', 'Crepe Paper Metallic Color are a fabulous alternative to fresh flowers! Use our quality Crepe Paper to create a beautiful floral bouquet that will last for years to come. Perfect for weddings, anniversaries, birthday celebrations, graduations, baby showers, engagement parties, and more ', 'Gift Accessories | Crepe Paper Metallic color', 'Crepe Paper Metallic Color are a fabulous alternative to fresh flowers! Use our quality Crepe Paper to create a beautiful floral bouquet'),
(35, 37, 'ar', 'شرائط-التعبئة-والتغليف-ابل-تيب', 'ابل تيب', 'ابل تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي ، وهذا النوع يلبي متطلبات العميل من تعبئة الكراتين بأسلوب يدعم الوزن العالي للكرتون.', 'الأشرطة ذاتية اللصق | شرائط التعبئة والتغليف | ابل تيب', 'ابل تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي وهذا النوع يلبي متطلبات العميل '),
(36, 37, 'en', 'Packaging-Tape-Apple-Tape', 'Apple Tape', 'The Apple Tape is made from water based adhesive coated on BOPP film .\r\nIt provide in crystal clear film.This type to meet client\'s requirement of packing cartons with style and it support high weight of cartons .', 'Self Adhesive Tape | Packaging Tape | Apple Tape', 'The Apple Tape is made from water based adhesive coated on BOPP film.It provide in crystal clear film.This type to meet client\'s requirement of packing  '),
(37, 38, 'ar', 'شرائط-التعبئة-والتغليف-فاير-تيب', 'فاير تيب', 'فاير تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي ، وهذا النوع يلبي متطلبات العميل من تعبئة الكراتين بأسلوب يدعم الوزن العالي للكرتون.', 'الأشرطة ذاتية اللصق | شرائط التعبئة والتغليف | فاير تيب', 'فاير تيب شرائط ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بفيلم BOPP ، وهي متوفرة في فيلم شفاف كريستالي ، وهذا النوع يلبي متطلبات العميل من تعبئة '),
(38, 38, 'en', 'Packaging-Tape-Fire-Tape', 'Fire Tape', 'The Frie tape is made from water based adhesive coated on BOPP film .\r\nIt provide in crystal clear film.This type to meet client\'s requirement of packing cartons with style and it support high weight of cartons .', 'Self Adhesive Tape | Packaging Tape | Fire Tape', 'The Frie tape is made from water based adhesive coated on BOPP film .It provide in crystal clear film.This type to meet client\'s requirement of packing carton'),
(39, 40, 'ar', 'شرائط-ذاتية-اللصق-ملونه-هوت-تيب', 'هوت تيب', 'الشرائط ذاتية اللصق الملونه هوت مصنوعه من أغشية BOPP اللاصقة المائية المصنوعة من الأكريليك ، ويمكن توفيره بألوان عديدة لمساعدة العملاء في عمليات تنظيم وفرز المنتجات اثناء التخزين او النقل متوفر بأحجام وعرض مختلفة لتلبية جميع احتياجات و متطلبات العملاء الخاصة', 'الأشرطة ذاتية اللصق | شرائط ذاتية اللصق ملونه | هوت تيب', 'الشرائط ذاتية اللصق الملونه هوت مصنوعه من أغشية BOPP اللاصقة المائية المصنوعة من الأكريليك ، ويمكن توفيره بألوان عديدة لمساعدة العملاء في عمليات تنظيم وفرز '),
(40, 40, 'en', 'Self-Adhesive-Color-Tape-Hot', 'Hot', 'HOT Self Adhesive Color Tape is made coated with water based acrylic adhesive BOPP films , its can provided in many colors to help customers in a well-organized operations , also in sorting products in the warehouse .\r\nIt’s available in different sizes & width to meet client’s special requirements .', 'Self Adhesive Tape | Self Adhesive Color Tape | Hot Tape', 'HOT Self Adhesive Color Tape made coated with water based acrylic adhesive BOPP films , its can provided in many colors to help customers in a well-organized'),
(41, 41, 'ar', 'الأشرطة-ذاتية-اللصق-جرين-ليزير-تيب', 'جرين تيب', 'جرين ليزير تيب يستخدام فى اعمال التغليف وكذلك فى الديكورات والاعمال الفنية و الحفلات وكذلك الاستخدامات المكتبية يمكننا توفير 6 ألوان مختلفة لتلبية طلب العميل.', 'الأشرطة ذاتية اللصق | جرين ليزير تيب', 'جرين ليزير تيب يستخدام فى اعمال التغليف وكذلك فى الديكورات والاعمال الفنية و الحفلات وكذلك الاستخدامات المكتبية يمكننا توفير 6 ألوان مختلفة لتلبية طلب العميل.'),
(42, 41, 'en', 'Self-Adhesive-Tape-Green-Laser-Tape', 'Green Tape', 'Green Laser Tape use for sealing and decorative Use in parties and stationery we can supply 6 different colors to meet client request.', 'Self Adhesive Tape | Green Laser Tape', 'Green Laser Tape use for sealing and decorative Use in parties and stationery we can supply 6 different colors to meet client request.'),
(43, 42, 'ar', 'السوليتب-المكتبى-بيتون-تيب', 'بيتون تيب', 'سوليتب مكتبى بيتون تيب مصنوع من مادة لاصقة أكريليك مائيّة مطلية بأفلام BOOP وهي متوفرة بأحجام وعرض مختلفة. الاستعمال: تغليف الهدايا ، التعبئة الخفيفة ، الأعمال الفنية ، التطبيقات المكتبية ، إصلاح الورق وتقوية المستندات. ', 'الأشرطة ذاتية اللصق | السوليتب المكتبى | بيتون تيب', 'سوليتب مكتبى بيتون تيب مصنوع من مادة لاصقة أكريليك مائيّة مطلية بأفلام BOOP وهي متوفرة بأحجام وعرض مختلفة. الاستعمال: تغليف الهدايا '),
(44, 42, 'en', 'Stationary-Tape-PITON-tape', 'PITON', 'The PITON Stationary tape is made with water based acrylic adhesive coated on BOOP films It available with different sizes and widths. Usage : gift wrapping , light packing , art craft , office application , paper mending and reinforcing documents .', 'Self Adhesive Tape | Stationary Tape | PITON Tape', 'The PITON Stationary tape is made with water based acrylic adhesive coated on BOOP films It available with different sizes and widths. Usage : gift wrapping '),
(45, 43, 'ar', 'السوليتب-المكتبى-سوليتب-مكتبى-ملون', 'سوليتب مكتبى ملون', 'السوليتب المكتبى الملون مصنوع من مادة لاصقة أكريليك مائيّة مطلية بأفلام BOOP وهي متوفرة بأحجام وعرض مختلفة. الاستعمال: تغليف الهدايا ، التعبئة الخفيفة ، الأعمال الفنية ، التطبيقات المكتبية ، إصلاح الورق وتقوية المستندات. ', 'الأشرطة ذاتية اللصق | السوليتب المكتبى | سوليتب مكتبى ملون', 'السوليتب المكتبى الملون مصنوع من مادة لاصقة أكريليك مائيّة مطلية بأفلام BOOP وهي متوفرة بأحجام وعرض مختلفة. الاستعمال: تغليف الهدايا '),
(46, 43, 'en', 'Stationary-Tape-Color-Tape', 'Color Tape', 'Stationary Color tape is made with water based acrylic adhesive coated on BOOP films It available with different sizes and widths. Usage : gift wrapping , light packing , art craft , office application , paper mending and reinforcing documents .\r\n ', 'Self Adhesive Tape | Stationary tape | Color Tape', 'Stationary Color tape is made with water based acrylic adhesive coated on BOOP films It available with different sizes and widths. Usage : gift wrapping'),
(47, 44, 'ar', 'السوليتب-المكتبى-ليزير-تيب', 'ليزير تيب', 'السوليتب المكتبى ليزير تيب مصنوع من مادة لاصقة أكريليك مائيّة مطلية بأفلام BOOP وهي متوفرة بأحجام وعرض مختلفة. الاستعمال: تغليف الهدايا ، التعبئة الخفيفة ، الأعمال الفنية ، التطبيقات المكتبية ، إصلاح الورق وتقوية المستندات. ', 'الأشرطة ذاتية اللصق | السوليتب المكتبى | ليزير تيب ', 'السوليتب المكتبى ليزير تيب مصنوع من مادة لاصقة أكريليك مائيّة مطلية بأفلام BOOP وهي متوفرة بأحجام وعرض مختلفة. الاستعمال: تغليف الهدايا'),
(48, 44, 'en', 'Stationary-Tape-Laser-Tape', 'Laser Tape', 'Stationary Laser tape is made with water based acrylic adhesive coated on BOOP films It available with different sizes and widths. Usage : gift wrapping , light packing , art craft , office application , paper mending and reinforcing documents .', 'Self Adhesive Tape | Stationary Tape | Laser Tape', 'Stationary Laser tape is made with water based acrylic adhesive coated on BOOP films It available with different sizes and widths. Usage : gift wrapping '),
(49, 45, 'ar', 'الاسترتش-الغذائى-هاى-ماكس', 'هاى ماكس', 'الاسترتش الغذائى هاى ماكس يستخدم في العديد من الاستخدامات فى تعبئة وتغليف الاطعامة وينشىء عازلا محكما يحافظ على نضارة ونكهة الاطعمة والمساعدة على التخلص من الروائح الكريهه فى الثلاجة \r\n\r\nمنتجنا الصديق للبيئة متعدد الاستخدامات وآمن ومناسب لجميع تغليف المواد الغذائية. من الممكن حتى في الثلاجة وفرن الميكروويف. يمكنه حماية الطعام الذي تريد حمايته بسرعة وتلبية متطلبات جميع احتياجات منزلك والمطبخ. ', 'الاسترتش الغذائى هاى ماكس يستخدم لتعبئة وتغليف الاطعامة', 'هاى ماكس يستخدم في العديد من الاستخدامات فى تعبئة وتغليف الاطعامة وينشىء عازلا محكما يحافظ على نضارة ونكهة الاطعمة والمساعدة على التخلص من الروائح الكريهه '),
(50, 45, 'en', 'Cling-Warp-Highmax-Wrap', 'Highmax Wrap', 'Highmax Wrap is used in many actives for creates an airtight seal, locking in freshness and flavor while eliminating food odors in your refrigerator.\r\n\r\nOur environmentally friendly wrap are versatile and safe and suitable for all food packaging. It is feasible even in the refrigerator and microwave oven. It can quickly protect the food you want to protect and meet the requirements of all your home and kitchen needs. ', 'Cling Warp Higmax Wrap used in many actives for creates an airtight  ', 'Highmax Wrap is used in many actives for creates an airtight seal, locking in freshness and flavor while eliminating food odors in your refrigerator'),
(51, 46, 'ar', 'الاسترتش-الغذائى-كومكس', 'كومكس', 'الاسترتش الغذائى كومكس يستخدم في العديد من الاستخدامات فى تعبئة وتغليف الاطعامة وينشىء عازلا محكما يحافظ على نضارة ونكهة الاطعمة والمساعدة على التخلص من الروائح الكريهه فى الثلاجة \r\n\r\nمنتجنا الصديق للبيئة متعدد الاستخدامات وآمن ومناسب لجميع تغليف المواد الغذائية. من الممكن حتى في الثلاجة وفرن الميكروويف. يمكنه حماية الطعام الذي تريد حمايته بسرعة وتلبية متطلبات جميع احتياجات منزلك والمطبخ. ', 'الاسترتش الغذائى كومكس يستخدم لتعبئة وتغليف الاطعامة', 'كومكس يستخدم في العديد من الاستخدامات فى تعبئة وتغليف الاطعامة وينشىء عازلا محكما يحافظ على نضارة ونكهة الاطعمة والمساعدة على التخلص من الروائح الكريهه '),
(52, 46, 'en', 'Cling-Warp-Komex', 'Komex', 'Komex Wrap is used in many actives for creates an airtight seal, locking in freshness and flavor while eliminating food odors in your refrigerator.\r\n\r\nOur environmentally friendly wrap are versatile and safe and suitable for all food packaging. It is feasible even in the refrigerator and microwave oven. It can quickly protect the food you want to protect and meet the requirements of all your home and kitchen needs. ', 'Cling Warp Komex used in many actives for creates an airtight seal', 'Komex Wrap is used in many actives for creates an airtight seal, locking in freshness and flavor while eliminating food odors in your refrigerator'),
(53, 48, 'ar', 'الاسترتش-الغذائى-ستار-ماكسمم', 'ستار ماكسمم', 'ستار ماكسمم يستخدم في العديد من الاستخدامات فى تعبئة وتغليف الاطعامة وينشىء عازلا محكما يحافظ على نضارة ونكهة الاطعمة والمساعدة على التخلص من الروائح الكريهه فى الثلاجة \r\n\r\nمنتجنا الصديق للبيئة متعدد الاستخدامات وآمن ومناسب لجميع تغليف المواد الغذائية. من الممكن حتى في الثلاجة وفرن الميكروويف. يمكنه حماية الطعام الذي تريد حمايته بسرعة وتلبية متطلبات جميع احتياجات منزلك والمطبخ. ', 'الاسترتش الغذائى | ستار ماكسمم يستخدم لتعبئة وتغليف الاطعامة', 'ستار ماكسمم يستخدم في العديد من الاستخدامات فى تعبئة وتغليف الاطعامة وينشىء عازلا محكما يحافظ على نضارة ونكهة الاطعمة والمساعدة على التخلص من الروائح الكريهه '),
(54, 48, 'en', 'Cling-Warp-Star-Maximum', 'Star Maximum ', 'Star Maximum Wrap is used in many actives for creates an airtight seal, locking in freshness and flavor while eliminating food odors in your refrigerator.\r\n\r\nOur environmentally friendly wrap are versatile and safe and suitable for all food packaging. It is feasible even in the refrigerator and microwave oven. It can quickly protect the food you want to protect and meet the requirements of all your home and kitchen needs. ', 'Cling Warp Star Maximum used in many actives for creates an airtight ', 'Star Maximum Wrap is used in many actives for creates an airtight seal, locking in freshness and flavor while eliminating food odors in your refrigerator'),
(55, 49, 'ar', 'الاسترتش-الغذائى-هاى-ماكس-2', 'هاى ماكس', 'الاسترتش الغذائى هاى ماكس يستخدم في العديد من الاستخدامات فى تعبئة وتغليف الاطعامة وينشىء عازلا محكما يحافظ على نضارة ونكهة الاطعمة والمساعدة على التخلص من الروائح الكريهه فى الثلاجة \r\n\r\nمنتجنا الصديق للبيئة متعدد الاستخدامات وآمن ومناسب لجميع تغليف المواد الغذائية. من الممكن حتى في الثلاجة وفرن الميكروويف. يمكنه حماية الطعام الذي تريد حمايته بسرعة وتلبية متطلبات جميع احتياجات منزلك والمطبخ. ', 'الاسترتش الغذائى | هاى ماكس يستخدم لتعبئة وتغليف الاطعامة', 'هاى ماكس يستخدم في العديد من الاستخدامات فى تعبئة وتغليف الاطعامة وينشىء عازلا محكما يحافظ على نضارة ونكهة الاطعمة والمساعدة على التخلص من الروائح الكريهه '),
(56, 49, 'en', 'Cling-Warp-Highmax-Wrap-2', 'Highmax Wrap', 'Highmax Wrap is used in many actives for creates an airtight seal, locking in freshness and flavor while eliminating food odors in your refrigerator.\r\n\r\nOur environmentally friendly wrap are versatile and safe and suitable for all food packaging. It is feasible even in the refrigerator and microwave oven. It can quickly protect the food you want to protect and meet the requirements of all your home and kitchen needs. ', 'Cling Warp | Higmax Wrap used in many actives for creates an airtight', 'Highmax Wrap is used in many actives for creates an airtight seal, locking in freshness and flavor while eliminating food odors in your refrigerator'),
(57, 50, 'ar', 'مستر-فويل-للارجيلة', 'مستر فويل للارجيلة ', 'رقائق الألومنيوم عالية الجودة للشيشة سيغطي معظم أوعية الشيشة الصغيرة والمتوسطة والكبيرة الحجم ، مما يمنحك تجربة استخدام لطيفة وممتعة. تعبئة مستقلة ، سهلة الحمل ، مناسبة للسفر ، الحفلات ، إلخ. ', 'الومنيوم فويل للاستخدام الصناعى | مستر فويل للارجيلة ', 'رقائق الألومنيوم عالية الجودة للشيشة سيغطي معظم أوعية الشيشة الصغيرة والمتوسطة والكبيرة الحجم ، مما يمنحك تجربة استخدام لطيفة وممتعة. تعبئة مستقلة '),
(58, 50, 'en', 'Mr-Foil-hookah-aluminum-foil', 'Mr Foil hookah aluminum foil', 'High quality hookah aluminum foil Role will cover most small and medium and large sized hookah bowls, giving you a nice and pleasant using experience. Independent packing, easy to carry, suitable for travel, party, etc. ', ' Aluminium foil for Industry Use | Mr Foil hookah aluminum foil', 'High quality hookah aluminum foil Role will cover most small and medium and large sized hookah bowls, giving you a nice and pleasant using experience.'),
(59, 51, 'ar', 'غطاء-بوتاجز-مستر-فويل2', 'غطاء بوتاجز مستر فويل', 'غطاء بوتاجز مستر فويل عالي الجودة: مصنوعة من رقائق الألومنيوم عالية الجودة ، هذه العبوة من أغطية الموقد الفضية موصلة للحرارة بدرجة عالية ومتينة للغاية لتحقيق أقصى استخدام.\r\n\r\nتجنب متاعب تنظيف الحرق أو بقايا الطعام من سطح الفرن. لن تضطر أبدًا إلى القلق بشأن تنظيف الشعلات مرة أخرى! ', 'الومنيوم فويل للاستخدام الصناعى | غطاء بوتاجز مستر فويل', 'غطاء بوتاجز مستر فويل عالي الجودة: مصنوعة من رقائق الألومنيوم عالية الجودة ، هذه العبوة من أغطية الموقد الفضية موصلة للحرارة بدرجة عالية ومتينة للغاية لتحقيق'),
(60, 51, 'en', 'Mr-Foil-Oven-2', 'Mr Foil Oven', 'Disposable Burner Covers For Gas Stoves Superior Quality Aluminum Foil: Made of high quality aluminum foil, this pack of silver burner covers are highly heat conducive and extra durable for maximum usage. \r\n\r\nAvoid the hassle of scrubbing out burn or food residue from your oven surface. you’ll never have to stress about cleaning your burners again!', ' Aluminium foil for Industry Use | Mr Foil Oven', 'Disposable Burner Covers For Gas Stoves Superior Quality Aluminum Foil: Made of high quality aluminum foil, this pack of silver burner covers are highly heat '),
(61, 52, 'ar', 'غطاء-بوتاجز-مستر-فويل', 'غطاء بوتاجز مستر فويل', 'غطاء بوتاجز مستر فويل عالي الجودة: مصنوعة من رقائق الألومنيوم عالية الجودة ، هذه العبوة من أغطية الموقد الفضية موصلة للحرارة بدرجة عالية ومتينة للغاية لتحقيق أقصى استخدام.\r\n\r\nتجنب متاعب تنظيف الحرق أو بقايا الطعام من سطح الفرن. لن تضطر أبدًا إلى القلق بشأن تنظيف الشعلات مرة أخرى! ', 'الومنيوم فويل للاستخدام الصناعى | غطاء بوتاجز مستر فويل', 'غطاء بوتاجز مستر فويل عالي الجودة: مصنوعة من رقائق الألومنيوم عالية الجودة ، هذه العبوة من أغطية الموقد الفضية موصلة للحرارة بدرجة عالية ومتينة للغاية لتحقيق '),
(62, 52, 'en', 'Mr-Foil-Oven', 'Mr Foil Oven', 'Disposable Burner Covers For Gas Stoves Superior Quality Aluminum Foil: Made of high quality aluminum foil, this pack of silver burner covers are highly heat conducive and extra durable for maximum usage. \r\n\r\nAvoid the hassle of scrubbing out burn or food residue from your oven surface. you’ll never have to stress about cleaning your burners again!', 'Aluminium foil for Industry Use | Mr Foil Oven', 'Disposable Burner Covers For Gas Stoves Superior Quality Aluminum Foil: Made of high quality aluminum foil, this pack of silver burner covers are highly heat '),
(63, 53, 'ar', 'الومنيوم-فويل-كينك', 'الومنيوم فويل كينك', 'العلامة التجارية رقم 1 لرقائق الألمنيوم المصنوعة في مصر ، الومنيوم فويل كينك بالقوة والجودة الموثوق بها التي يمكنك الاعتماد عليها لطهي وجبات لذيذة مع سهولة التنظيف\r\nسميكة جدًا للطبخ في الفرن أو على الشواية أو على النار ؛ يسمح للطهي لفترة أطول من أجل شواء اللحوم بشكل أفضل.يساعدك صندوق الورق المقوى المزود بقاطع معدني على تمزيق ورق القصدير بشكل أكثر كفاءة وراحة. ', 'الومنيوم فويل استخدام منزلى | الومنيوم فويل كينك', 'العلامة التجارية رقم 1 لرقائق الألمنيوم المصنوعة في مصر ، الومنيوم فويل كينك بالقوة والجودة الموثوق بها التي يمكنك الاعتماد عليها لطهي وجبات لذيذة مع سهولة '),
(64, 53, 'en', 'Aluminium-foil-King', 'Aluminium foil King', 'The number 1 brand of aluminum foil made in the Egypt, MR. FOIL has the trusted strength and quality you can count on for cooking delicious meals with easy cleanup \r\nExtra thickened for cooking in the oven, on the grill or over a fire; allows for longer cooking limiting to better broil the meats.\r\nPaper board box with metal cutter help you to tear off the foil paper more efficiently and conveniently.', 'Aluminium foil for House Hold | Aluminium foil King', 'The number 1 brand of aluminum foil made in the Egypt, King has the trusted strength and quality you can count on for cooking delicious meals'),
(65, 55, 'ar', 'جامبو-رول', 'جامبو رول ', 'جامبو رول ', 'جامبو رول ', 'جامبو رول '),
(66, 55, 'en', 'Jumbo-Roll', ' Jumbo Roll', 'جامبو رول ', ' Jumbo Roll', 'جامبو رول '),
(67, 56, 'ar', 'مسدس-شمع-بسلك-كهرباء-من-يوني-تي-موديل-eh430', 'مسدس شمع بسلك كهرباء من يوني-تي موديل EH430', 'العلامة التجارية: يوني-تي\r\nمصدر الطاقة: سلك كهربائي\r\nنوع المنتج: مسدس شمع\r\nرقم الموديل: EH430\r\nهل يعمل المنتج بالبطارية أم المنتج بطارية: لا\r\nهل يعتبر هذا المنتج خطر أو مصنوع من خامة أو مادة خطيرة ولكن يصلح للنقل أو التخزين و/أو التخلص منه؟: لا', '350', NULL),
(68, 56, 'en', 'مسدس-شمع-بسلك-كهرباء-من-يوني-تي-موديل-eh430', 'مسدس شمع بسلك كهرباء من يوني-تي موديل EH430', NULL, NULL, NULL),
(69, 57, 'ar', 'مسدس-شمع-st-03-20w-حجم-صغير-ازرق', 'مسدس شمع ST-03 20W، حجم صغير - ازرق', NULL, '221', NULL),
(70, 57, 'en', 'مسدس-شمع-st-03-20w-حجم-صغير-ازرق', 'مسدس شمع ST-03 20W، حجم صغير - ازرق', NULL, NULL, NULL),
(71, 58, 'ar', 'مسدس-شمع-برو-جلو-من-ستانلي-gr100', 'مسدس شمع برو جلو من ستانلي GR100', NULL, '475', NULL),
(72, 58, 'en', 'مسدس-شمع-برو-جلو-من-ستانلي-gr100', 'مسدس شمع برو جلو من ستانلي GR100', NULL, NULL, NULL),
(73, 59, 'ar', 'مسدس-شمع-من-عتمان-جروب-متعدد-الألوان', 'مسدس شمع من عتمان جروب، متعدد الألوان', NULL, '138', NULL),
(74, 59, 'en', 'مسدس-شمع-من-عتمان-جروب-متعدد-الألوان', 'مسدس شمع من عتمان جروب، متعدد الألوان', NULL, NULL, NULL),
(75, 60, 'ar', 'مسدس-غراء-احترافي-220-وات-من-توتال-tt301116', 'مسدس غراء احترافي 220 وات من توتال TT301116', 'اللون 	أزرق/أحمر/أبيض\r\nاسم العلامة التجارية 	توتال تولز\r\nالنمط 	زناد\r\nأبعاد السلعة 	34,5 x 24 x 6 سم\r\nمصدر الطاقة 	سلك كهربائي\r\nالقوة الكهربائية 	220 واط\r\nأبعاد المنتج الطول × العرض × الارتفاع 	35,4L x 6W x 24H سم', '334', NULL),
(76, 60, 'en', 'مسدس-غراء-احترافي-220-وات-من-توتال-tt301116', 'مسدس غراء احترافي 220 وات من توتال TT301116', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'ادمن كامل الصلاحيات', 'Full Admin Permission ', 'web', '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(2, 'editor', 'محرر', 'editor', 'web', '2023-09-07 15:41:17', '2023-09-07 15:41:17');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `photo`, `photo_thum_1`, `roles_name`, `status`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Hany Darwish ', 'test@test.com', NULL, NULL, NULL, '[\"admin\"]', 1, NULL, '$2y$10$GPEWsYQiyMFPW/cmWkhKYOTQhA51JgO2.ZvrZD7Jl4H9y//cqdeIC', NULL, '2023-09-07 15:41:16', '2023-09-07 15:41:16'),
(2, 'Sub Admin  ', 'subadmin@test.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$iN5Vf9aOqP5CLUjLDvwo9uzZEIZCn9WKDH15znxovuU35CIyFDwg.', NULL, '2023-09-07 15:41:17', '2023-09-07 15:41:17'),
(3, 'Editor', 'editor@test.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$fkHmcDRUF5EcU46wTK0ojulpv9qrGh12tTGiz28NV./Enl0hPBBf6', NULL, '2023-09-07 15:41:17', '2023-09-07 15:41:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attribute_tables`
--
ALTER TABLE `attribute_tables`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attribute_table_translations`
--
ALTER TABLE `attribute_table_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `attribute_table_translations_attribute_id_locale_unique` (`attribute_id`,`locale`),
  ADD KEY `attribute_table_translations_locale_index` (`locale`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `banners_category_id_foreign` (`category_id`);

--
-- Indexes for table `banner_categories`
--
ALTER TABLE `banner_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner_category_translations`
--
ALTER TABLE `banner_category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `banner_category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD KEY `banner_category_translations_locale_index` (`locale`);

--
-- Indexes for table `banner_translations`
--
ALTER TABLE `banner_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `banner_translations_banner_id_locale_unique` (`banner_id`,`locale`),
  ADD KEY `banner_translations_locale_index` (`locale`);

--
-- Indexes for table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_post_photos`
--
ALTER TABLE `blog_post_photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_post_photos_blog_id_foreign` (`blog_id`);

--
-- Indexes for table `blog_post_translations`
--
ALTER TABLE `blog_post_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blog_post_translations_blog_id_locale_unique` (`blog_id`,`locale`),
  ADD UNIQUE KEY `blog_post_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `blog_post_translations_locale_index` (`locale`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `category_tables`
--
ALTER TABLE `category_tables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_tables_category_id_foreign` (`category_id`),
  ADD KEY `category_tables_attribute_id_foreign` (`attribute_id`);

--
-- Indexes for table `category_table_translations`
--
ALTER TABLE `category_table_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_table_translations_category_table_id_locale_unique` (`category_table_id`,`locale`),
  ADD KEY `category_table_translations_locale_index` (`locale`);

--
-- Indexes for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD UNIQUE KEY `category_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `category_translations_locale_index` (`locale`);

--
-- Indexes for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_settings`
--
ALTER TABLE `config_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_setting_translations_setting_id_locale_unique` (`setting_id`,`locale`),
  ADD KEY `config_setting_translations_locale_index` (`locale`);

--
-- Indexes for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `config_upload_filter_sizes_filter_id_foreign` (`filter_id`);

--
-- Indexes for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_web_privacy_translations_privacy_id_locale_unique` (`privacy_id`,`locale`),
  ADD KEY `config_web_privacy_translations_locale_index` (`locale`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `faqs_category_id_foreign` (`category_id`);

--
-- Indexes for table `faq_categories`
--
ALTER TABLE `faq_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq_category_translations`
--
ALTER TABLE `faq_category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `faq_category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD UNIQUE KEY `faq_category_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `faq_category_translations_locale_index` (`locale`);

--
-- Indexes for table `faq_translations`
--
ALTER TABLE `faq_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `faq_translations_faq_id_locale_unique` (`faq_id`,`locale`),
  ADD KEY `faq_translations_locale_index` (`locale`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `our_clients`
--
ALTER TABLE `our_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `our_client_translations`
--
ALTER TABLE `our_client_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `our_client_translations_client_id_locale_unique` (`client_id`,`locale`),
  ADD UNIQUE KEY `our_client_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `our_client_translations_locale_index` (`locale`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_cat_id_unique` (`cat_id`);

--
-- Indexes for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_translations_page_id_locale_unique` (`page_id`,`locale`),
  ADD UNIQUE KEY `page_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `page_translations_locale_index` (`locale`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `product_photos`
--
ALTER TABLE `product_photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_photos_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_tables`
--
ALTER TABLE `product_tables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_tables_product_id_foreign` (`product_id`),
  ADD KEY `product_tables_attribute_id_foreign` (`attribute_id`);

--
-- Indexes for table `product_table_translations`
--
ALTER TABLE `product_table_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_table_translations_product_table_id_locale_unique` (`product_table_id`,`locale`),
  ADD KEY `product_table_translations_locale_index` (`locale`);

--
-- Indexes for table `product_translations`
--
ALTER TABLE `product_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_translations_product_id_locale_unique` (`product_id`,`locale`),
  ADD UNIQUE KEY `product_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `product_translations_locale_index` (`locale`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attribute_tables`
--
ALTER TABLE `attribute_tables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `attribute_table_translations`
--
ALTER TABLE `attribute_table_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `banner_categories`
--
ALTER TABLE `banner_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `banner_category_translations`
--
ALTER TABLE `banner_category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `banner_translations`
--
ALTER TABLE `banner_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `blog_posts`
--
ALTER TABLE `blog_posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `blog_post_photos`
--
ALTER TABLE `blog_post_photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_post_translations`
--
ALTER TABLE `blog_post_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `category_tables`
--
ALTER TABLE `category_tables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `category_table_translations`
--
ALTER TABLE `category_table_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `category_translations`
--
ALTER TABLE `category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `config_settings`
--
ALTER TABLE `config_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `faq_categories`
--
ALTER TABLE `faq_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `faq_category_translations`
--
ALTER TABLE `faq_category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `faq_translations`
--
ALTER TABLE `faq_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=657;

--
-- AUTO_INCREMENT for table `our_clients`
--
ALTER TABLE `our_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `our_client_translations`
--
ALTER TABLE `our_client_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `page_translations`
--
ALTER TABLE `page_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `product_photos`
--
ALTER TABLE `product_photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `product_tables`
--
ALTER TABLE `product_tables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `product_table_translations`
--
ALTER TABLE `product_table_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;

--
-- AUTO_INCREMENT for table `product_translations`
--
ALTER TABLE `product_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attribute_table_translations`
--
ALTER TABLE `attribute_table_translations`
  ADD CONSTRAINT `attribute_table_translations_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attribute_tables` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `banners`
--
ALTER TABLE `banners`
  ADD CONSTRAINT `banners_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `banner_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `banner_category_translations`
--
ALTER TABLE `banner_category_translations`
  ADD CONSTRAINT `banner_category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `banner_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `banner_translations`
--
ALTER TABLE `banner_translations`
  ADD CONSTRAINT `banner_translations_banner_id_foreign` FOREIGN KEY (`banner_id`) REFERENCES `banners` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_post_photos`
--
ALTER TABLE `blog_post_photos`
  ADD CONSTRAINT `blog_post_photos_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blog_posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_post_translations`
--
ALTER TABLE `blog_post_translations`
  ADD CONSTRAINT `blog_post_translations_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blog_posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `category_tables`
--
ALTER TABLE `category_tables`
  ADD CONSTRAINT `category_tables_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attribute_tables` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_tables_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `category_table_translations`
--
ALTER TABLE `category_table_translations`
  ADD CONSTRAINT `category_table_translations_category_table_id_foreign` FOREIGN KEY (`category_table_id`) REFERENCES `category_tables` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD CONSTRAINT `category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD CONSTRAINT `config_setting_translations_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `config_settings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD CONSTRAINT `config_upload_filter_sizes_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `config_upload_filters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD CONSTRAINT `config_web_privacy_translations_privacy_id_foreign` FOREIGN KEY (`privacy_id`) REFERENCES `config_web_privacies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faqs`
--
ALTER TABLE `faqs`
  ADD CONSTRAINT `faqs_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `faq_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faq_category_translations`
--
ALTER TABLE `faq_category_translations`
  ADD CONSTRAINT `faq_category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `faq_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faq_translations`
--
ALTER TABLE `faq_translations`
  ADD CONSTRAINT `faq_translations_faq_id_foreign` FOREIGN KEY (`faq_id`) REFERENCES `faqs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `our_client_translations`
--
ALTER TABLE `our_client_translations`
  ADD CONSTRAINT `our_client_translations_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `our_clients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD CONSTRAINT `page_translations_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `product_photos`
--
ALTER TABLE `product_photos`
  ADD CONSTRAINT `product_photos_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_tables`
--
ALTER TABLE `product_tables`
  ADD CONSTRAINT `product_tables_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attribute_tables` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_tables_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_table_translations`
--
ALTER TABLE `product_table_translations`
  ADD CONSTRAINT `product_table_translations_product_table_id_foreign` FOREIGN KEY (`product_table_id`) REFERENCES `product_tables` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_translations`
--
ALTER TABLE `product_translations`
  ADD CONSTRAINT `product_translations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
